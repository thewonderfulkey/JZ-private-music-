# 分析方法与证据

## 样本身份

本次直接使用用户上传的三个 APK，原文件没有修改。完整 SHA256 和 Manifest 版本在 `evidence.json`。
工具：JADX 1.5.5；ZIP/DEX/ELF 解析；Python、Capstone、pyelftools；FFmpeg/ffprobe 媒体核验。
参考 reverse-skill 的 APK 分析及证据化方法，但没有执行其安装脚本、注册 MCP 或宣称完成其完整 bootstrap/case-review 流程。
JADX 反编译存在部分代码错误，成功输出不代表 Java 中所有方法都已恢复。

## 聆听音乐：JavaScript 层

包内 `assets/musicApi.html` 加载 `assets/dist/app.native.js`，将 `window.musicApi` 下的方法注册到 DSBridge。
可读化后的相对位置（这些行号属于本次 pretty 输出，不是原始单行文件）：

- 第 5397 行附近：网易云 `searchSong`，POST `/weapi/cloudsearch/get/web`。
- 第 5530 行附近：网易云 `getSongUrl`，POST `/weapi/song/enhance/player/url`，对象 `ids/br/csrf_token`。
- 第 6223 行附近：QQ `searchSong`，GET `/soso/fcgi-bin/client_search_cp`。
- 第 6354 行附近：QQ `getSongUrl`，GET `/cgi-bin/musicu.fcg`，包含 GetCdnDispatch、CgiGetVkey。
- 第 13147 行附近：QQ 旧 API baseURL `https://c.y.qq.com`，newApi 切换 `https://u.y.qq.com`。
- 第 13400 行附近：网易云 baseURL `https://music.163.com`；WEAPI 请求拦截器生成 `params/encSecKey`。

这里只提取网络结构，不把 APK 内预置登录 Cookie 当作用户授权账户使用。

## 聆听音乐：native 虚拟机层

多个 `com.yfoo.listenx.api.*` 方法在 Java 中是 native，绑定 `NativeUtil.classes2Init0`，主要逻辑位于 `lib/arm64-v8a/libnmmp.so`，解释器位于 `libnmmvm.so`。
对照公开 NMMP 的数据结构与生成器，再以本样本实际 ARM64 指令核对，恢复了本版本字符串池、引用表、方法注册、指令数组及所需请求构造函数。
公开参考：<https://github.com/maoabc/nmmp>。没有执行其保护程序。

关键静态定位（为 ELF 虚拟地址/文件内静态位置，不是运行时 ASLR 地址）：

| 位置 | 含义 |
| --- | --- |
| libnmmvm.so `vmInterpret` 0x1c13c | 解释器入口 |
| libnmmvm.so 0x520b8 | 本版本 opcode handler 表 |
| libnmmp.so 0x35e4 | 对应字符串池起点 |
| libnmmp.so 0x14120 | 字符串偏移表 |
| libnmmp.so 0x1cf08 | const-string 索引表 |
| libnmmp.so 0x184d8 | 方法引用表 |
| libnmmp.so 0x31af4 | `MusicApi.getUrl` native wrapper |
| libnmmp.so 0x1f6bc | `getUrl` 20 个指令单元 |
| libnmmp.so 0x31bcc | `MusicApi.postData` native wrapper |
| libnmmp.so 0x1f6e4 | `postData` 34 个指令单元 |

`getUrl` 把 Base64 常量解码成：

```text
http://api-music.1fooai.com/api/musicApi.php?app=listenx
```

`postData` 创建 JSONObject，分别写入 `musicType` 和 `apiParam`，再 `toString`。
`getDataKt` 调用 `OkHttpUtil.postFormatJson`；Java 实现证实 HTTP POST、Content-Type application/json。

还原到的请求路由：

| musicType | apiParam | 定位 |
| --- | --- | --- |
| wy | `/song/url/v1?id=ID&level=LEVEL` | `ApiManage.getNetEasePlayUrl` 0x2bd40 |
| kw | `/kuwo/url?mid=RID&type=music&br=BR` | `ApiManage.getKuWoPlayUrl` 0x2c060 |
| kw | `/kuwoPlay/url?rid=RID` | `KuWoAPIKt...getKuWoPlayUrl` 0x36c6c |
| qq | `/song/url?id=ID` | `QQMusicApiV2.getMusicUrlHighSoundQuality` 0x2cc18 |
| kg | `/song/urls?hash=HASH` | 酷狗高音质方法 0x30a74 |
| kw | `/song/urls?rid=RID` | 酷我高音质方法 0x36b44 |

`getDataKt$lambda$3` wrapper 0x31720 调用 `SecurityJNI.nativeDecrypt`；`OneHttpUtil.init` 又调用 nativeInit。
测试网关返回密文，与客户端存在解密链路一致。本轮没有恢复这套安全库的完整初始化及响应解密逻辑，不能提供“复制网关 URL 就得到明文音乐”的结论。

### 酷我直连分支为何可以确认来自 APK

`ApiManage.getKuwoMusicSongList$lambda$0` wrapper 0x2c460，其指令数组位于 0x1dac8。
在指令偏移 0x0066（按 16-bit code unit 计数）读取常量：

```text
https://antiserver.kuwo.cn/anti.s?type=convert_url3&rid=
```

后续附加歌曲 ID，在 0x006e 读取并附加：

```text
&format=mp3&response=url
```

构造出的 URL 进入音频对象。这是确认的调用位置，不只是一次没有上下文的字符串扫描。
本轮对构造请求实际得到 JSON `url`，然后成功下载音频并全文件解码。

## 海心音乐与天天悦听

| 检查项 | 海心音乐 | 天天悦听 |
| --- | --- | --- |
| DEX 文件数 | 1 | 1 |
| DEX class_defs_size | 4 | 4 |
| DEX string_ids_size | 387 | 339 |
| DEX 文件字节数 | 11,220,796 | 4,574,876 |
| DEX map_off | 17,316 | 15,968 |
| Application | com.stub.StubApp | com.stub.StubApp |
| 加固文件 | assets/libjiagu_a64.so | 多架构 libjiagu |

可解析 DEX 的四个类是 StubApp 与加载辅助类；业务部分没有作为可解析常规类暴露。
JADX 还会生成 R 类或 SDK 辅助输出，不能把总输出文件数误当作恢复的业务类数。
对资产、原始 DEX、解码资源的 URL 检索没有找到能归属这两个应用音乐业务的确认接口；存在广告/资源相关文本不构成音乐 API 证据。
进一步应在已授权 Android 运行环境中观察加载后的业务 DEX 或实际网络请求。本次没有这种环境，结论止于“未提取成功”，不是“应用没有 API”。

## 网络验证范围

- QQ 搜索：HTTP 200，含歌曲 ID、标题、歌手。
- QQ vkey：顶层 code=0，但样本 songmid=0039MnYb0qxYhV 的 purl 为空、result=104003；不能拿 req 中的保活/测试文件当作目标歌曲。
- 酷我直连：HTTP 200，返回音频 URL，整份文件下载和解码通过。
- 独立网关 wy 请求：HTTP 200 密文；kw 请求一次超时。
- `app.kzti.top:1030/client/cgi-bin/api.fcg` 的无参数 GET：HTTP 503。方法/二进制 gcsp/stream 协议尚未完整复现，这不能判定其所有正确调用必然失效。
- `api.1foo.com/chao/tx/link.php` 无参数探测超时；未证实其完整请求参数，不列为可用接口。
- `listen.8yy.app` 根页面返回 Site Unavailable HTML，不能当作音乐 JSON 服务。

只对 APK 指向的候选服务做了少量普通请求，没有端口扫描、账号登录或动态运行原 APK。
