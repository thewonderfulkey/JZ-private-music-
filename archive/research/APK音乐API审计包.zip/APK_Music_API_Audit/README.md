# 三个 APK 的音乐接口分析结果

**本轮确认可返回音乐并实际下载整份音频的是聆听音乐中引用的酷我直连分支。海心音乐和天天悦听的业务代码受加固保护，未提取出已确认的音乐 API。**
聆听音乐的独立音乐网关也已还原，但测试返回加密响应，尚未完成 native 解密复现。

## 1. 可以直接请求的音频解析接口

```text
GET https://antiserver.kuwo.cn/anti.s?type=convert_url3&rid=51685512&format=mp3&response=url
```

- `rid`：酷我歌曲 ID，不能混用 QQ songmid 或网易云 ID。
- `format=mp3`：请求 MP3。
- `response=url`：是 APK 中的原始参数，但本轮实际返回 JSON；音频地址在 `url` 字段。
- 音频地址属于临时 CDN 链接，过期后重新请求。

测试歌曲 ID 51685512 的搜索结果标注为《晴天（KTV版伴奏）》，不是已确认的原唱版本；本次没有做声纹或曲目身份鉴定。

本轮实际下载结果：

| 检查 | 结果 |
| --- | --- |
| HTTP | 200 |
| 文件格式 | MP3，128 kbps |
| 文件大小 | 4,318,872 字节，与 Content-Length 一致 |
| 文件时长 | 269.897143 秒 |
| ffmpeg 全文件解码 | 退出码 0 |
| SHA256 | c127a1e0e5be97f2d713c788e48e2caf1066b359be6eb7e227381c5261009d0b |

这是完整传输且能全文件解码的音频；不代表该接口对全部歌曲、原唱和音质都可用。

## 2. 本地下载

需要 Python 3.9+ 和 FFmpeg，主程序仅使用 Python 标准库。

```powershell
ffprobe -version
ffmpeg -version
py download_kuwo.py --rid 51685512
py download_kuwo.py --rid 51685512 --output .\downloads\sample.mp3 --expected-duration 269
```

FFmpeg 下载入口：<https://ffmpeg.org/download.html>。其 `bin` 文件夹需要在 PATH 中。
下载前检查文件长度、可读音频格式、全文件解码；指定 `--expected-duration` 后还会检查与预期时长是否一致，失败不保存成最终文件。
只检查解码不能区分一首完整歌曲与一个能正常解码的试听片段，因此其他歌曲建议传入已知的真实时长。

## 3. 聆听音乐自己的网关

```text
POST http://api-music.1fooai.com/api/musicApi.php?app=listenx
Content-Type: application/json
```

网易云请求 body：

```json
{"musicType":"wy","apiParam":"/song/url/v1?id=2652820720&level=standard"}
```

酷我请求 body：

```json
{"musicType":"kw","apiParam":"/kuwoPlay/url?rid=51685512"}
```

Windows 复现网易云请求：

```powershell
curl.exe --request POST --header "Content-Type: application/json" --data-binary "@request_wy.json" "http://api-music.1fooai.com/api/musicApi.php?app=listenx"
```

本轮网易云请求返回 HTTP 200 **密文**，不是音频 URL。APK 随后调用 `SecurityJNI.nativeDecrypt`，还依赖 `OneHttpUtil.init` 初始化。
因此这里只提供已还原的真实地址和请求格式，不把它列为可独立返回明文 URL 的完成品。
酷我网关请求一次超时。没有使用 APK 中的预置个人登录 Cookie。

## 4. 其他已确认结构

| 类别 | 地址/结构 | 实测状态 |
| --- | --- | --- |
| QQ 搜索 | `GET https://c.y.qq.com/soso/fcgi-bin/client_search_cp`，参数 `w/p/n/ct/remoteplace/aggr/cr/lossless` | 返回歌曲列表 |
| QQ 播放查询 | `GET https://u.y.qq.com/cgi-bin/musicu.fcg?data=JSON`，`CDN.SrfCdnDispatchServer.GetCdnDispatch` + `vkey.GetVkeyServer.CgiGetVkey` | 原唱《晴天》样本 `purl` 为空、单曲 result=104003，未取得音乐 |
| 网易云搜索 | `POST https://music.163.com/weapi/cloudsearch/get/web` | 源码确认；需要 WEAPI 请求编码，本轮未重测 |
| 网易云播放 | `POST https://music.163.com/weapi/song/enhance/player/url` | 源码确认；不能用普通明文 JSON 直接调用 |

不要把广告、统计域名或只存在于二进制字符串中的旧服务器，直接当成音乐 API。

## 5. 海心音乐 / 天天悦听为何还没有业务接口

| APK | Manifest 包名 | 证据 |
| --- | --- | --- |
| 海心音乐 1.3.2 | `com.haixin.music.app` | `com.stub.StubApp`、`libjiagu_a64.so`，可解析 DEX 仅 4 个类 |
| 天天悦听 3.2.7 | `com.damao.music` | `com.stub.StubApp`、多架构 libjiagu，DEX 仅 4 个类 |

JADX 当前输出主要是壳、资源和 R 类。对 DEX、assets、资源 URL 检索没有找到能确认属于业务请求的音乐接口。
当前环境没有连接 Android 设备，也没有 Android 模拟器；无法取得运行时加载的业务 DEX 或抓取实际搜索/播放请求。
不能用聆听的接口冒充这两个应用的接口，也不能把这种静态限制写成“它们没有 API”。

如果继续这两个 APK，需要其运行时加载后的 DEX 或脱敏的搜索、播放、下载流量；不需要发送账号密码或完整 Cookie。
包内附有可选的 `capture_endpoints.js`，适合在你有权分析的 Android 设备/模拟器上使用 Frida 观察 URL 与请求字段；它不关闭证书校验，不修改账户权限。
该脚本未在当前无设备环境中运行，因此不是已完成的动态抓包证据。

## 文件说明

- `ANALYSIS.md`：方法、源码位置、native 地址及限制。
- `api_catalog.json`：端点、请求参数、状态。
- `evidence.json`：APK、关键内部文件哈希，壳证据。
- `native_request_evidence.json`：仅包含与请求构造有关的还原指令，未导出完整常量表或预置 Cookie。
- `verification.json`：实际音频验证与请求结果摘要。
- `download_kuwo.py`：可独立执行的解析和下载脚本。

这里没有把上一轮的 GD Studio 接口充作这三个 APK 中提取的新结果。
