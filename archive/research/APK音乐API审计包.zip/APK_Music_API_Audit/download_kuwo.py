#!/usr/bin/env python3
"""Reproduce the direct Kuwo endpoint found in the supplied Lingting APK."""
import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path


def resolve(rid):
    if not re.fullmatch(r'[0-9]{1,20}', rid):
        raise ValueError('rid must be a numeric Kuwo song ID, not a QQ/NetEase ID')
    url = 'https://antiserver.kuwo.cn/anti.s?' + urllib.parse.urlencode({
        'type': 'convert_url3', 'rid': rid, 'format': 'mp3', 'response': 'url'})
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=20) as response:
        raw = response.read(100000).decode().strip()
    # The tested endpoint returns JSON despite response=url; older variants may return a URL.
    if raw.startswith('{'):
        data = json.loads(raw)
        target = data.get('url')
    else:
        data, target = {}, raw
    if not target or urllib.parse.urlsplit(target).scheme not in ('http', 'https'):
        raise RuntimeError('No audio URL returned: ' + json.dumps(data, ensure_ascii=False)[:300])
    return {'rid': rid, 'endpoint': url, 'audio_url': target}


def download(info, destination, expected_duration=None):
    if not shutil.which('ffprobe') or not shutil.which('ffmpeg'):
        raise RuntimeError('Install FFmpeg and add its bin directory to PATH; ffprobe and ffmpeg are required')
    path = Path(destination)
    if path.exists():
        raise FileExistsError('Output already exists; choose another filename')
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.kuwo-', suffix='.mp3', dir=path.parent)
    os.close(fd)
    temporary = Path(name)
    try:
        request = urllib.request.Request(info['audio_url'], headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://www.kuwo.cn/'})
        size = 0
        digest = hashlib.sha256()
        with urllib.request.urlopen(request, timeout=30) as response, temporary.open('wb') as stream:
            if response.status != 200:
                raise RuntimeError('Expected a complete HTTP 200 response')
            content_type = response.headers.get('Content-Type', '').lower()
            if 'json' in content_type or 'html' in content_type:
                raise RuntimeError('Server returned an error document instead of audio')
            length = response.headers.get('Content-Length')
            for chunk in iter(lambda: response.read(131072), b''):
                size += len(chunk)
                if size > 128 * 1024 * 1024:
                    raise RuntimeError('Download exceeds the 128 MiB limit')
                stream.write(chunk)
                digest.update(chunk)
        if not size or length and int(length) != size:
            raise RuntimeError('Incomplete file transfer')
        probe = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration,format_name:stream=codec_name,bit_rate', '-of', 'json', str(temporary)], capture_output=True, text=True, timeout=30)
        if probe.returncode:
            raise RuntimeError('The downloaded file is not readable audio')
        details = json.loads(probe.stdout)
        duration = float(details.get('format', {}).get('duration') or 0)
        if not math.isfinite(duration) or duration <= 0:
            raise RuntimeError('Invalid audio duration')
        if expected_duration is not None and abs(duration - expected_duration) > max(3, expected_duration * 0.02):
            raise RuntimeError(f'Duration mismatch: expected {expected_duration}s, got {duration}s; refusing to save')
        decoder = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(temporary), '-f', 'null', '-'], capture_output=True, text=True, timeout=60)
        if decoder.returncode:
            raise RuntimeError('Full audio decode failed')
        os.replace(temporary, path)
        return {**info, 'file': str(path.resolve()), 'bytes': size, 'duration': duration,
                'sha256': digest.hexdigest(), 'full_decode_passed': True,
                'duration_matches_expected': expected_duration is not None,
                'note': 'A complete decodable file is not by itself proof of a full original recording; compare the expected duration and version.'}
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rid', required=True)
    parser.add_argument('--output', help='If omitted, only resolve the current audio URL')
    parser.add_argument('--expected-duration', type=float)
    args = parser.parse_args()
    if args.expected_duration is not None and (not math.isfinite(args.expected_duration) or args.expected_duration <= 0):
        parser.error('--expected-duration must be a positive number of seconds')
    result = resolve(args.rid)
    if args.output:
        result = download(result, args.output, args.expected_duration)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
