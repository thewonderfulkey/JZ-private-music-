/* Optional observation helper; NOT executed or device-tested in this analysis.
 * Examples on your own prepared Android device:
 * frida -U -f com.haixin.music.app -l capture_endpoints.js
 * frida -U -f com.damao.music -l capture_endpoints.js
 * Only observes URL/method and JSON field names. Does not change TLS or permissions.
 * Headers and raw request bodies are deliberately not logged.
 */
'use strict';

function safeUrl(value) {
  var parts = String(value).split('?');
  if (parts.length < 2) return parts[0];
  var allowed = /^(id|rid|mid|songmid|hash|keyword|w|q|type|source|level|br|format|response|page|p|n|limit|offset|app)$/i;
  return parts[0] + '?' + parts.slice(1).join('?').split('&').map(function (item) {
    var pair = item.split('=');
    var key;
    try { key = decodeURIComponent(pair[0]); } catch (_) { key = pair[0]; }
    return pair[0] + '=' + (allowed.test(key) ? pair.slice(1).join('=') : '[REDACTED]');
  }).join('&');
}

Java.perform(function () {
  var installed = false;
  try {
    var Builder = Java.use('okhttp3.Request$Builder');
    var Buffer = Java.use('okio.Buffer');
    var build = Builder.build.overload();
    build.implementation = function () {
      var request = build.call(this);
      var event = { kind: 'okhttp', method: String(request.method()), url: safeUrl(request.url().toString()) };
      try {
        var body = request.body();
        if (body && String(body.contentType()).indexOf('application/json') >= 0 && body.contentLength() <= 65536 && body.contentLength() >= 0) {
          var buffer = Buffer.$new();
          body.writeTo(buffer);
          var parsed = JSON.parse(String(buffer.readUtf8()));
          event.json_keys = Object.keys(parsed);
        }
      } catch (_) { }
      send(event);
      return request;
    };
    installed = true;
    send({ kind: 'status', message: 'OkHttp request observer installed' });
  } catch (error) {
    send({ kind: 'status', message: 'OkHttp class not yet available: ' + String(error) });
  }
  try {
    var URL = Java.use('java.net.URL');
    var open = URL.openConnection.overload();
    open.implementation = function () {
      send({ kind: 'urlconnection', url: safeUrl(this.toString()) });
      return open.call(this);
    };
    installed = true;
    send({ kind: 'status', message: 'URLConnection observer installed' });
  } catch (error) {
    send({ kind: 'status', message: 'URLConnection hook unavailable: ' + String(error) });
  }
  if (!installed) send({ kind: 'status', message: 'No hook installed; runtime-loaded or native networking needs separate inspection' });
});
