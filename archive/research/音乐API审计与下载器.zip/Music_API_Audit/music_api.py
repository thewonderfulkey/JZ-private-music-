#!/usr/bin/env python3
"""Local search, resolution and verified audio download. Python 3.9+."""
import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

GD = 'https://music-api.gdstudio.xyz/api.php'
LAST_GD = 0.0
GD_LOCK = threading.Lock()
MAX_BYTES = 256 * 1024 * 1024


def get_json(url, params=None, headers=None):
    if params:
        url += ('&' if '?' in url else '?') + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', **(headers or {})})
    with urllib.request.urlopen(req, timeout=20) as r:
        body = r.read(4 * 1024 * 1024 + 1)
    if len(body) > 4 * 1024 * 1024:
        raise RuntimeError('Metadata response too large')
    return json.loads(body)


def gd(params):
    global LAST_GD
    # Conservative local throttling; this is not a claimed upstream quota.
    with GD_LOCK:
        time.sleep(max(0, 3 - (time.monotonic() - LAST_GD)))
        LAST_GD = time.monotonic()
        return get_json(GD, params)


def validate_id(provider, track_id):
    pattern = r'[0-9]{1,20}' if provider in ('gd', 'qobuz') else r'[A-Za-z0-9_-]{1,50}'
    if provider not in ('gd', 'audius', 'qobuz') or not re.fullmatch(pattern, track_id):
        raise ValueError('provider must be gd/audius/qobuz with a valid track ID')


def search(provider, keyword, limit):
    if not keyword.strip() or len(keyword) > 200 or not 1 <= limit <= 20:
        raise ValueError('Use a nonempty query up to 200 characters and limit 1–20')
    if provider == 'gd':
        data = gd({'types': 'search', 'source': 'netease', 'name': keyword, 'count': limit, 'pages': 1})
        if not isinstance(data, list):
            raise RuntimeError('Resolver did not return a song list')
        return [{'id': str(s['id']), 'title': s['name'], 'artists': s.get('artist'),
                 'album': s.get('album'), 'provider': 'gd', 'source': 'netease'} for s in data]
    if provider == 'audius':
        data = get_json('https://api.audius.co/v1/tracks/search', {'query': keyword, 'limit': limit, 'app_name': 'musicdl'})
        return [{'id': s['id'], 'title': s['title'], 'artists': [s.get('user', {}).get('name')],
                 'duration': s.get('duration'), 'provider': 'audius',
                 'is_downloadable': s.get('is_downloadable')} for s in data.get('data', [])]
    raise ValueError('Search provider must be gd or audius')


def qobuz_get(path, params):
    app = os.environ.get('QOBUZ_APP_ID')
    token = os.environ.get('QOBUZ_USER_AUTH_TOKEN')
    if not app or not token:
        raise RuntimeError('Configure your own QOBUZ_APP_ID and QOBUZ_USER_AUTH_TOKEN locally')
    return get_json('https://www.qobuz.com/api.json/0.2/' + path, params,
                    {'X-App-Id': app, 'X-User-Auth-Token': token})


def resolve(provider, track_id):
    validate_id(provider, track_id)
    if provider == 'gd':
        data = gd({'types': 'url', 'source': 'netease', 'id': track_id, 'br': 128})
        raw_url = data.get('url')
        metadata = get_json('https://music.163.com/api/song/detail/', {'id': track_id, 'ids': '[' + track_id + ']'})
        songs = metadata.get('songs') or []
        if not songs:
            raise RuntimeError('Song metadata missing; cannot verify identity/duration')
        song = songs[0]
        result = {'id': track_id, 'provider': provider, 'source': 'netease', 'url': raw_url,
                  'title': song['name'], 'artists': [a['name'] for a in song.get('artists', [])],
                  'expected_duration': song.get('duration', 0) / 1000,
                  'reported_bytes': data.get('size'), 'bitrate_kbps': data.get('br')}
    elif provider == 'audius':
        song = get_json('https://api.audius.co/v1/tracks/' + track_id, {'app_name': 'musicdl'}).get('data') or {}
        if not song or song.get('is_stream_gated') or song.get('is_download_gated'):
            raise RuntimeError('Song is missing or gated')
        result = {'id': track_id, 'provider': provider, 'source': provider, 'title': song.get('title'),
                  'artists': [song.get('user', {}).get('name')], 'expected_duration': song.get('duration'),
                  'url': 'https://api.audius.co/v1/tracks/' + track_id + '/stream?app_name=musicdl'}
    else:
        secret = os.environ.get('QOBUZ_APP_SECRET')
        if not secret:
            raise RuntimeError('Configure your own QOBUZ_APP_SECRET locally')
        timestamp = str(time.time())
        signature = hashlib.md5(('trackgetFileUrlformat_id6intentstreamtrack_id' + track_id + timestamp + secret).encode()).hexdigest()
        data = qobuz_get('track/getFileUrl', {'request_ts': timestamp, 'request_sig': signature,
                            'track_id': track_id, 'format_id': 6, 'intent': 'stream'})
        song = qobuz_get('track/get', {'track_id': track_id})
        if data.get('sample') or data.get('is_sample'):
            raise RuntimeError('Upstream returned a preview')
        result = {'id': track_id, 'provider': provider, 'source': provider, 'title': song.get('title'),
                  'expected_duration': song.get('duration'), 'url': data.get('url')}
    if not result.get('url') or str(result['url']).lower() == 'none':
        raise RuntimeError('No audio URL returned; this song is not available through this request')
    if urllib.parse.urlsplit(result['url']).scheme not in ('http', 'https'):
        raise RuntimeError('Unexpected audio URL scheme')
    result['full_verified'] = False  # Set only after a complete file has been inspected.
    return result


def download_verified(result, destination):
    if not shutil.which('ffprobe'):
        raise RuntimeError('Install FFmpeg (ffprobe) to verify full audio before downloading')
    expected = float(result.get('expected_duration') or 0)
    if not math.isfinite(expected) or expected <= 0:
        raise RuntimeError('Missing expected duration; full audio cannot be verified')
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, tmpname = tempfile.mkstemp(prefix='.music-', suffix='.part', dir=destination.parent)
    os.close(fd)
    tmp = Path(tmpname)
    try:
        req = urllib.request.Request(result['url'], headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as response, tmp.open('wb') as stream:
            if response.status != 200:
                raise RuntimeError('Expected a complete HTTP 200 audio response')
            content_type = response.headers.get('Content-Type', '').lower()
            if any(t in content_type for t in ('json', 'text/html', 'mpegurl')):
                raise RuntimeError('Upstream returned an error page or playlist, not an audio file')
            reported = response.headers.get('Content-Length')
            count = 0
            while True:
                chunk = response.read(128 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > MAX_BYTES:
                    raise RuntimeError('Audio exceeds the 256 MiB limit')
                stream.write(chunk)
        if count == 0 or (reported and int(reported) != count):
            raise RuntimeError('Audio transfer is incomplete')
        p = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration,format_name:stream=codec_name',
                            '-of', 'json', str(tmp)], capture_output=True, text=True, timeout=30)
        if p.returncode:
            raise RuntimeError('Downloaded data is not a readable audio file')
        probe = json.loads(p.stdout)
        actual = float(probe.get('format', {}).get('duration') or 0)
        if not math.isfinite(actual) or abs(actual - expected) > max(3, expected * 0.02):
            raise RuntimeError(f'Duration mismatch: expected {expected:.2f}s, got {actual:.2f}s; refusing preview/wrong file')
        if destination.exists():
            raise FileExistsError('Destination already exists; choose another filename')
        digest = hashlib.sha256()
        with tmp.open('rb') as f:
            for chunk in iter(lambda: f.read(128 * 1024), b''):
                digest.update(chunk)
        os.replace(tmp, destination)
        return {**result, 'full_verified': True, 'duration': actual, 'bytes': count,
                'sha256': digest.hexdigest(), 'file': str(destination), 'probe': probe}
    finally:
        tmp.unlink(missing_ok=True)


class Handler(BaseHTTPRequestHandler):
    def json_response(self, code, data):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        args = urllib.parse.parse_qs(parsed.query)
        param = lambda key, default='': args.get(key, [default])[0]
        try:
            provider = param('provider', 'gd')
            if parsed.path == '/health':
                self.json_response(200, {'ok': True, 'ffprobe': bool(shutil.which('ffprobe'))})
            elif parsed.path == '/search':
                self.json_response(200, {'songs': search(provider, param('q'), int(param('limit', '5')))})
            elif parsed.path == '/url':
                self.json_response(200, resolve(provider, param('id')))
            elif parsed.path == '/download':
                result = resolve(provider, param('id'))
                with tempfile.TemporaryDirectory() as directory:
                    info = download_verified(result, Path(directory) / 'audio')
                    codec = info['probe'].get('streams', [{}])[0].get('codec_name', '')
                    extension = {'mp3': 'mp3', 'flac': 'flac', 'aac': 'm4a', 'opus': 'ogg', 'vorbis': 'ogg'}.get(codec, 'audio')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/octet-stream')
                    self.send_header('Content-Disposition', f'attachment; filename="{provider}_{param("id")}.{extension}"')
                    self.send_header('Content-Length', str(info['bytes']))
                    self.send_header('X-Audio-Duration', str(info['duration']))
                    self.send_header('X-Audio-SHA256', info['sha256'])
                    self.send_header('Cache-Control', 'no-store')
                    self.end_headers()
                    with open(info['file'], 'rb') as f:
                        shutil.copyfileobj(f, self.wfile)
            else:
                self.json_response(404, {'error': 'Use /search?q=..., /url?id=..., /download?id=...; provider=gd or audius'})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except (ValueError, FileExistsError) as e:
            self.json_response(400, {'error': str(e)})
        except Exception as e:
            self.json_response(502, {'error': type(e).__name__, 'detail': str(e)})


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    server = sub.add_parser('serve')
    server.add_argument('--port', type=int, default=8888)
    for name in ('search', 'url', 'download'):
        cmd = sub.add_parser(name)
        cmd.add_argument('--provider', choices=['gd', 'audius', 'qobuz'], default='gd')
        cmd.add_argument('--query' if name == 'search' else '--id', required=True)
        if name == 'download':
            cmd.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command == 'serve':
        print(f'Local music API: http://127.0.0.1:{args.port}', flush=True)
        ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
        return
    if args.command == 'search':
        result = search(args.provider, args.query, 5)
    else:
        result = resolve(args.provider, args.id)
        if args.command == 'download':
            result = download_verified(result, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
