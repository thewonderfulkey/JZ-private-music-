# 八类项目的核心取流链路与 API 审计

## 结论与范围

源码中存在接口不等于现在可返回完整歌曲。本次分别核对项目身份、搜索入口、音频解析、下载保存与鉴权，实测能够连通的候选请求，并完成一条整曲下载验证。
这是核心功能调用链审计，不声称穷尽每个项目的所有平台、每一种加密协议或全部代码路径。
没有登录用户账号、安装 MusicFree/洛雪音源插件、注册外部 MCP，或运行各仓库自带的安装脚本。
reverse-skill 仅用作源码取证、最小复现、区分事实与假设的方法参考；未运行其完整 bootstrap 工作流。

## 项目身份与结论

| 用户名称 | 实际审查对象 | 核心机制 | 本轮完整音频结果 |
| --- | --- | --- | --- |
| Listen1 | listen1/listen1；另对照 listen1_chrome_extension | provider 搜索、解析 URL、本地代理/播放器 | 上轮直接网易云播放查询为 null；不能宣称可用 |
| musicdl | CharlesPikachu/musicdl | 平台适配器 + 第三方解析器 + 下载器 | GD → 网易云链路完整下载成功；不代表所有 musicdl 平台可用 |
| go-music-dl | guohuiyuan/go-music-dl；按 go.mod 固定 music-lib 依赖版本 | 本地 Web API → music-lib 的平台客户端 → 下载器 | 找到下载路由；未编译运行整套 Go 应用；酷我候选官方接口返回地区限制 |
| SpotiFLAC | 原 spotbye/SpotiFLAC 当前拉取失败；明确改审 lahiruchinthana/SpotiFLAC-CLI 派生版及 spotiflacapp/SpotiFLAC-Extension 当前重定向仓库 | Spotify 等元数据映射到其他平台，再调用网关/解析器下载 | 原仓库未完成源码审查；派生版旧端点失败或未返回音频；新版插件需要签名会话和 ticket |
| Deemix | bambanah/deemix（README 标明 revived 项目，区别于原 RemixDev） | Deezer 登录态 → license/track token → FULL 媒体 URL → 音频处理 → 文件 | 没有用户账号，未验证整曲下载 |
| qobuz-dl | vitiko98/qobuz-dl | 登录、订阅检查、签名 getFileUrl、下载 URL | 没有用户账号，未验证整曲下载 |
| MusicFree | maotoumao/MusicFree | 外部插件 `getMediaSource` → RN 文件下载 | 主仓库不自带一套可直接拿走的通用音乐 HTTP API；未提供具体插件，无法验证音源 |
| 洛雪（用户写作“落雪”） | lyswhut/lx-music-desktop | 自定义音源 `musicUrl` 请求 → URL → 下载器 | 主仓库当前内置接口列表为空，依赖用户音源脚本；本地开放 API 主要控制播放器 |

所有仓库 URL、固定提交和关键文件哈希见 `source_manifest.json`。SpotiFLAC 的替代来源不是原仓库同版本，不能混为一谈。

## 1. 已验证完整下载：musicdl 的 GD Studio 分支

证据：`musicdl/modules/sources/netease.py::_parsewithgdstudioapi`；酷我适配器中也存在同名第三方分支。

### 搜索

```http
GET https://music-api.gdstudio.xyz/api.php?types=search&source=netease&name=晴天&count=5&pages=1
```

参数：`name` 搜索词，`count` 返回数量，`pages` 页码。返回数组，包含 `id/name/artist/album/source`。

### 获取可下载地址

```http
GET https://music-api.gdstudio.xyz/api.php?types=url&source=netease&id=2652820720&br=128
```

返回字段：`url/br/size`。源码尝试 `br=999`，本轮有完整文件验证的请求是 `br=128`；不能把它写成“已验证 FLAC”。
`source=kuwo` 的一次候选请求返回 HTTP 400，不把它列为本轮可用源。

### 验证证据

| 项目 | 实测 |
| --- | --- |
| 歌曲 ID | 2652820720 |
| 歌曲/歌手 | 晴天(深情版) / Lucky小爱 |
| 格式 | MP3，44.1 kHz，128 kbps |
| 下载字节数 | 4,464,684，与解析器声明一致 |
| 元数据时长 | 278.961 秒 |
| 文件时长 | 279.013878 秒 |
| 全文件解码 | ffmpeg 退出码 0 |
| SHA256 | 6c06e6a9170dc1ac6709f4896c50329b2011f936543c37cf3137d55cc1b56817 |

这是一次真实成功样本。第三方解析器并不属于网易云官方 API 服务，其可用性和覆盖歌曲可能变化。

## 2. Listen1：直接平台请求与本地代理

旧仓库固定路由：

```text
GET /search?source=0&keywords=搜索词
GET /track_file?id=netrack_歌曲ID&source=netease&artist=歌手&album=专辑&title=标题
```

`source=0/1/2/3` 对应网易云/虾米/QQ/豆瓣。搜索结果 `url` 指向本地代理，不是音乐 CDN 地址。
`TrackFileHandler` 在缺少 URL 时调用 provider 的 `get_url_by_id`，随后取音频并向客户端转发，可能重定向缓存文件。

网易云上游：

```text
POST https://music.163.com/api/search/get
表单：s=搜索词&type=1&offset=0&limit=5

POST https://music.163.com/weapi/song/enhance/player/url?csrf_token=
表单：params=...&encSecKey=...
原始对象：ids、br、csrf_token

新版：POST https://interface3.music.163.com/eapi/song/enhance/player/url
表单：params=...
原始对象：ids="[歌曲ID]"、br
```

搜索成功，直接播放查询的测试样本都返回 `url=null`。通过 GD 解析同一平台，是另一条链路，不能反过来宣称 Listen1 直接接口已修复。

## 3. go-music-dl：已有本地下载 HTTP API

运行官方程序 `music-dl web` 后，默认根地址为 `http://localhost:8080/music`。

```text
GET /music/search?q=搜索词&sources=netease
GET /music/inspect?id=歌曲ID&source=netease&duration=预期时长
GET /music/download?id=歌曲ID&source=netease&name=标题&artist=歌手
GET /music/download?id=歌曲ID&source=netease&stream=1
```

注意：`/search` 默认是 Web 搜索页，不应当作固定 JSON 歌曲 API；`/inspect` 返回探测信息；`/download` 才是音频响应入口。`POST /music/download` 虽注册存在，handler 读取的是 URL query；不要误写成只传 JSON body。
需要保留搜索得到的 `extra` 字段时，将其按源码要求作为 query 编码传入。

核心平台端点（完整参数与签名需按 music-lib 实现，不是直接 GET 即可）：

| 平台 | 取流入口 | 条件/输出 |
| --- | --- | --- |
| 网易云 | POST `/weapi/song/enhance/player/url`；POST `https://interface3.music.163.com/eapi/song/enhance/player/url/v1` | Cookie、VIP/歌曲权限、WEAPI/EAPI；返回 URL |
| QQ | POST `https://u.y.qq.com/cgi-bin/musicu.fcg` | JSON 模块请求获取 purl，结合 CDN；高音质受账号权限影响 |
| 酷我 | GET `https://mobi.kuwo.cn/mobi.s` | `f/source/from/type/br/rid/user`；本轮 code=407 地区限制 |
| 咪咕 | GET `https://c.musicapp.migu.cn/MIGUM2.0/v2.1/content/listen-url` | Android 客户端参数、签名及资源/音质标记；部分格式还有额外音频处理 |
| B站 | GET `https://api.bilibili.com/x/player/playurl` | `bvid/cid/fnval/qn`；读取 DASH 音频 URL，通常需对应请求头 |

读取的 music-lib 已切换到 go.mod 所指定的 `7cc4467b4e300547edd5d3d5bf0eff1c21ffc2ec`。
酷我失败的地区提示明确存在；没有修改或伪造地区请求头进行绕过。

## 4. SpotiFLAC：元数据并不来自音频源

原 `spotbye/SpotiFLAC` 本次网页请求 404、git 拉取失败。以下旧端点来自明确标识的 `lahiruchinthana/SpotiFLAC-CLI`，不能冒充原仓库当前有效实现。

| 功能 | 派生版源码里的请求 | 本轮状态 |
| --- | --- | --- |
| 跨平台 ID 匹配 | GET `https://api.song.link/v1-alpha.1/links?url=Spotify链接` | 源码发现；仅元数据映射 |
| Qobuz 第三方解析 | GET `https://jumo-dl.pages.dev/get?track_id=ID&format_id=6&region=US` | 实际返回 HTML，未获得音频 URL |
| Qobuz 第三方解析 | GET `https://dab.yeet.su/api/stream?trackId=ID&quality=6` | 源码发现，未测试 |
| Qobuz 第三方解析 | GET `https://dabmusic.xyz/api/stream?trackId=ID&quality=6` | 本轮 HTTP 403 |
| Tidal 第三方解析 | GET `https://triton.squid.wtf/track/?id=ID&quality=LOSSLESS` | 仅探测根地址得到 503；具体取流未验证 |
| Tidal 备选域名 | `https://hifi-one.spotisaver.net`、`https://hifi-two.spotisaver.net` 下的 `/track/` | 源码发现，未测试 |
| Amazon 第三方解析 | GET `https://amazon.afkarxyz.fun/api/track/ASIN` | 源码发现，未测试；后续还可能包含音频处理 |

Tidal 响应可能是 Base64 的 JSON/DASH manifest，需要解析或获取多个分片，不能把接口 JSON 直接保存为 FLAC。

当前 `SpotiFLAC-Extension` 重定向至 Mornye 插件仓库：

```text
POST https://api.zarz.moe/v2/dl/qbz
POST https://api.zarz.moe/v2/dl/tid
```

Qobuz 示例 body 在插件中包含 `quality/upload_to_r2/id/type/url`。
它调用 `session.signedFetch`、`signedTicket`，依赖 bootstrap/challenge/session exchange、会话签名和 ticket。
只复制端点、缺少签名会话不能构成可用下载 API。health 返回可达/降级状态，也不能证明能下载。
本轮没有冒用插件宿主身份或试图绕过其会话校验。

## 5. Deemix：账号权限及音频处理

证据：`packages/deezer-sdk/src/deezer.ts::get_tracks_url`、`gw.ts::get_track`、`packages/deemix/src/decryption.ts`。

```text
POST https://www.deezer.com/ajax/gw-light.php
常用 method：deezer.getUserData、song.getData

POST https://media.deezer.com/v1/get_url
```

媒体请求 body 结构：

```json
{
  "license_token": "你账户的授权token",
  "media": [{"type": "FULL", "formats": [{"cipher": "BF_CBC_STRIPE", "format": "FLAC"}]}],
  "track_tokens": ["对应歌曲的token"]
}
```

`FULL` 只表示请求类型，不是无条件获批。源码先检查 license_token、lossless/HQ 权限；取得的媒体也可能是加密流，需要项目后续处理后才是可播放文件。
`https://api.deezer.com/search/track?q=...` 等公开元数据接口不等于完整音频下载接口。
本轮无 ARL 或许可账号，因此不提交虚假的成功音频结果。

## 6. qobuz-dl：签名 getFileUrl

证据：`qobuz_dl/qopy.py::Client.api_call/auth/get_track_url`。

```text
GET https://www.qobuz.com/api.json/0.2/user/login
GET https://www.qobuz.com/api.json/0.2/track/get?track_id=ID
GET https://www.qobuz.com/api.json/0.2/track/getFileUrl
```

getFileUrl query：`track_id/format_id/intent=stream/request_ts/request_sig`。
header：`X-App-Id`、`X-User-Auth-Token`。
签名：`MD5("trackgetFileUrlformat_id" + format_id + "intentstreamtrack_id" + track_id + timestamp + app_secret)`，需使用调用者有权使用的应用参数与账户。
源码接受格式 5/6/7/27，并检查账户资格；README 明确要求有效订阅。完整文件地址读取响应 `url`。
`music_api.py --provider qobuz` 是按此格式编写的可配置适配器，没有账号实测，不能标为已验证。

## 7. MusicFree：实际接口在外部插件里

`src/types/plugin.d.ts` 声明 `getMediaSource(musicItem, quality)`，结果为 `{url, headers, userAgent, quality}`。
`src/core/pluginManager/plugin.ts` 调用已安装插件的方法；`src/core/downloader.ts` 使用 `downloadFile({fromUrl, headers, ...})` 保存文件。

因此 MusicFree 主程序可下载，不意味着存在某个固定的 `musicfree.com/api/download`。没有具体音源插件时，可定位调用契约，但无法给出该插件实际使用的上游域名、签名和成功下载结论。

## 8. 洛雪：自定义音源协议与播放器开放 API

证据：`src/renderer/core/useApp/useInitUserApi.ts`、`src/renderer/utils/musicSdk/api-source-info.ts`、`src/main/modules/openApi/index.ts`。

自定义音源请求结构：

```json
{"source":"wy","action":"musicUrl","info":{"type":"128k","musicInfo":{"示意":"完整歌曲对象"}}}
```

实际脚本应按照洛雪的事件协议处理请求并返回 URL。这不是可以直接发送到某个公共域名的 HTTP 请求。
当前内置 `sources` 数组为空，旧 `tm.tempmusics.tk` 等代码处于未启用列表，不能把这些历史字符串当作当前有效音源。
本地 `/status`、`/play`、`/pause`、`/seek` 等开放 API 控制播放器，不是“传歌曲 ID 返回完整音频”的服务。

## 附加候选：musicdl 的公开音源

```text
GET https://api.audius.co/v1/tracks/search?query=关键词&limit=5&app_name=musicdl
GET https://api.audius.co/v1/tracks/ID?app_name=musicdl
GET https://api.audius.co/v1/tracks/ID/stream?app_name=musicdl

GET https://ccmixter.org/api/query?f=json&limit=1&tags=instrumental
GET https://ccmixter.org/api/query?f=xspf&t=search_uploads&search_type=any&search=关键词&limit=5
```

Audius 搜索与某首音频前 32 字节探测成功，但该曲 download_conditions 标记需付费，独立适配器拒绝该下载；另一个搜索候选的后续请求遇到 404。未计作整曲验证成功。
ccMixter 返回文件和许可证元数据；本轮未完整下载，不计入已验证整曲来源。

## 测试结论的边界

完整成功样本：GD → 网易云的一首 MP3，含 CLI 和本地 HTTP 下载验证。
账号受限部分：Deemix、qobuz-dl。
缺少外部插件：MusicFree、洛雪。
仓库不可拉取：SpotiFLAC 原版；派生版/插件已单独分析。
HTTP 200 的 HTML、manifest、URL JSON、30 秒试听和网关 health 都不能替代完整音频验证。

候选 URL 清单只用于复核源码。其数量不等于可用音乐 API 数量，未测试端点绝不因出现在清单里而被认定有效。
