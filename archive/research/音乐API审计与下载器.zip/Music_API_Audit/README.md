# 音乐 API：搜索、获取地址、本地下载

本包含八类项目的核心取流链路审计和一个独立本地 API。
已实测完整下载的是 **musicdl 引用的 GD Studio → 网易云 CDN** 链路。
其他接口的鉴权条件、失败结果和未验证项见 `API_AUDIT.md`，不能把整份候选接口清单理解为全部可用。

## 启动

需要 Python 3.9+。本地 API 主程序仅使用 Python 标准库，不需要 pip 安装依赖。
下载功能需要 FFmpeg 中的 `ffprobe` 在 PATH 内：

```powershell
py --version
ffprobe -version
py music_api.py serve
```

FFmpeg 官方下载入口：<https://ffmpeg.org/download.html>。
如果 `ffprobe` 命令不存在，需要先安装 FFmpeg，确保其 bin 文件夹在 PATH 中，再重新打开终端。
只查询搜索和 URL 不要求 FFmpeg；下载缺少它时会明确报错。

## 浏览器/HTTP 调用

| 请求 | 返回 |
| --- | --- |
| `http://127.0.0.1:8888/search?q=晴天` | 歌曲列表，默认 GD → 网易云 |
| `http://127.0.0.1:8888/url?id=2652820720` | 当前音乐 URL、歌名、歌手及预期时长 |
| `http://127.0.0.1:8888/download?id=2652820720` | 验证后返回完整音频文件，浏览器可保存 |
| `http://127.0.0.1:8888/health` | 本地服务状态及 ffprobe 是否可用 |

Windows 终端中也可以直接保存：

```powershell
py music_api.py download --id 2652820720 --output .\downloads\sample.mp3
```

或者服务启动后：

```powershell
curl.exe --fail "http://127.0.0.1:8888/download?id=2652820720" -o sample.mp3
```

该测试歌曲是 **Lucky小爱《晴天(深情版)》**，不是周杰伦原唱。搜索不同版本时必须核对 `title/artists/album` 和 ID。
先搜索再下载；不能把其他平台的 ID 用作网易云 ID。
临时 CDN URL 可能过期，应重新调用 `/url`，不要把测试时的临时直链长期写死。

## 完整性检查

下载在临时文件中完成，检查通过后才提供保存结果：

1. 请求完整文件，拒绝 JSON、网页、播放列表等非音频响应。
2. 检查 HTTP 声明长度（如提供），避免传输截断。
3. 用 ffprobe 验证可读音频，并比较媒体时长和歌曲元数据。
4. 时长允许 `max(3秒, 2%)` 误差；不匹配时拒绝提供文件，避免把常见试听片段当完整版。
5. 输出 SHA256、字节数、时长；已有文件不主动覆盖。

这是文件完整性和时长验证，不是声纹鉴定，也不是对原唱、母带或曲库覆盖率的保证。
`/url` 中的 `full_verified=false` 表示尚未下载核验；成功下载后才为 true。
本轮实测还额外对测试 MP3 做了 ffmpeg 全文件解码，退出码 0。

## 其他 provider

- `provider=audius`：实现 musicdl 同款搜索与 stream 请求。遇到平台标记的 gated 内容直接拒绝；本轮只有搜索和部分流字节探测成功，完整下载没有通过，不列为已验证可用源。
- `provider=qobuz`：根据 qobuz-dl 请求格式实现取 URL 和下载，必须在你本地配置自己的 `QOBUZ_APP_ID`、`QOBUZ_APP_SECRET`、`QOBUZ_USER_AUTH_TOKEN`，且有对应账户权限。本轮未配置账号，未验证成功下载。
- Deemix、MusicFree、洛雪、go-music-dl 原有服务的入口在审计文档中列出；本程序没有声称把这些完整程序全部重新实现。

不要把账号 Token 发到对话中。服务仅绑定本机 `127.0.0.1`；Ctrl+C 停止。

## 文件说明

- `API_AUDIT.md`：项目映射、请求参数、鉴权和实测状态。
- `api_catalog.json`：整理的核心接口及参数。
- `candidate_urls.csv`：指定核心源码目录中的候选 URL 字符串路径清单，查询值已去除；不是有效 API 保证。
- `source_manifest.json`：仓库、固定提交、关键文件哈希及符号行号。
- `verification.json`：完整 MP3 下载与媒体核验记录。
- `http_download_verification.json`：本地 `/download` 的实际 HTTP 下载测试。
- `probe_results.json`：失败、权限和可达性探测摘要。
- `listen1_previous/`：上一轮 Listen1 源码接口适配器和说明，保留原始失败记录。

不能从多个开源播放器推导出“任何歌曲、任何音质、免账号、长期稳定”的通用接口。没有取得必要账号或音源插件的部分，结果明确标为未验证。
