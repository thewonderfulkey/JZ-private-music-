#!/usr/bin/env python3
"""Small local Listen1-derived NetEase adapter. See LICENSE and README.md."""
import argparse
import hashlib
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7


def request_json(url, data=None, cookie=None):
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://music.163.com/"}
    if cookie:
        headers["Cookie"] = cookie
    encoded = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=encoded, headers=headers)
    with urllib.request.urlopen(req, timeout=15) as response:
        result = json.load(response)
    if not isinstance(result, dict) or result.get("code", 200) != 200:
        raise RuntimeError("Upstream returned a non-success response")
    return result


def search(keyword, limit=10):
    data = request_json("https://music.163.com/api/search/get", {
        "s": keyword, "type": 1, "offset": 0, "limit": limit,
    })
    result = data.get("result") or {}
    return {"total": result.get("songCount", 0), "songs": [{
        "id": song["id"], "title": song["name"],
        "artists": [a["name"] for a in song.get("artists", [])],
        "album": song.get("album", {}).get("name"),
        "fee": song.get("fee"), "source": "netease",
        "source_url": "https://music.163.com/song?id=" + str(song["id"]),
    } for song in result.get("songs", [])]}


def eapi(path, payload):
    # Request encoding reproduced from Listen1 Chrome extension netease.eapi.
    text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    digest = hashlib.md5(f"nobody{path}use{text}md5forencrypt".encode()).hexdigest()
    raw = f"{path}-36cd479b6b5-{text}-36cd479b6b5-{digest}".encode()
    padder = PKCS7(128).padder()
    raw = padder.update(raw) + padder.finalize()
    encryptor = Cipher(algorithms.AES(b"e82ckenh8dichen8"), modes.ECB()).encryptor()
    return {"params": (encryptor.update(raw) + encryptor.finalize()).hex().upper()}


def song_url(song_id):
    song_id = str(song_id).removeprefix("netrack_")
    if not re.fullmatch(r"[0-9]{1,20}", song_id):
        raise ValueError("id must be a numeric NetEase song ID")
    path = "/api/song/enhance/player/url"
    data = request_json("https://interface3.music.163.com/eapi/song/enhance/player/url",
                        eapi(path, {"ids": f"[{song_id}]", "br": 128000}), "os=pc")
    items = data.get("data") or []
    if not items:
        raise RuntimeError("Upstream returned no song data")
    item = items[0]
    url = item.get("url")
    if url and urllib.parse.urlsplit(url).scheme not in ("http", "https"):
        raise RuntimeError("Unexpected upstream URL scheme")
    return {"id": int(song_id), "url": url, "available": bool(url),
            "bitrate": item.get("br"), "expires_in": item.get("expi"),
            "upstream_code": item.get("code"), "trial": item.get("freeTrialInfo"),
            "message": None if url else "当前请求未获得播放权限或音源不可用"}


class Handler(BaseHTTPRequestHandler):
    def output(self, status, data):
        content = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        args = urllib.parse.parse_qs(parsed.query)
        try:
            if parsed.path == "/health":
                self.output(200, {"ok": True, "upstream_tested": False})
            elif parsed.path == "/search":
                keyword = args.get("keywords", [""])[0].strip()
                if not keyword or len(keyword) > 200:
                    raise ValueError("keywords must have 1–200 characters")
                limit = int(args.get("limit", ["10"])[0])
                if not 1 <= limit <= 30:
                    raise ValueError("limit must be between 1 and 30")
                self.output(200, search(keyword, limit))
            elif parsed.path in ("/url", "/play"):
                result = song_url(args.get("id", [""])[0])
                if parsed.path == "/play" and result["url"]:
                    self.send_response(302)
                    self.send_header("Location", result["url"])
                    self.send_header("Content-Length", "0")
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                else:
                    self.output(200 if parsed.path == "/url" else 404, result)
            else:
                self.output(404, {"error": "Use /search?keywords=..., /url?id=..., /play?id=..."})
        except ValueError as exc:
            self.output(400, {"error": str(exc)})
        except (urllib.error.URLError, TimeoutError, OSError, RuntimeError, KeyError) as exc:
            self.output(502, {"error": "upstream_error", "detail": str(exc)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8888)
    opts = parser.parse_args()
    print(f"Local music API: http://127.0.0.1:{opts.port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", opts.port), Handler).serve_forever()
