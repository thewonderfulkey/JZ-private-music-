# Listen1 音乐接口提取结果

## 当前结论

已经定位搜索、歌曲 ID、播放 URL 获取、音频代理的完整代码链路，并编写 Python 3.9+ 本地接口适配器。
**搜索已实测成功；本轮播放 URL 测试均返回 null，未验证到可播放音频。**
这不是已部署的公网音乐服务，也不能保证所有歌曲能够播放。

## 使用方法（Windows）

解压后，在当前目录打开终端：

```powershell
py -m pip install -r requirements.txt
py music_api.py
```

服务只监听本机 `127.0.0.1:8888`。按 Ctrl+C 停止。

| 接口 | 作用 |
| --- | --- |
| `GET /search?keywords=Beethoven&limit=5` | 返回歌曲 ID、标题、歌手、专辑 |
| `GET /url?id=26705082` | 返回平台提供的临时播放地址或 null |
| `GET /play?id=26705082` | 有地址时 302 跳转，无地址时返回 404 JSON |
| `GET /health` | 仅检查本地服务存活，不代表音源可用 |

搜索也支持中文：`http://127.0.0.1:8888/search?keywords=晴天`。
从搜索结果取 `songs[].id` 再请求 `/url`；不能根据搜索成功推断可播放。

返回结构示意（不是成功播放的实测）：

```json
{"id":26705082,"url":null,"available":false,"bitrate":0,"expires_in":1200,"upstream_code":404,"trial":null,"message":"当前请求未获得播放权限或音源不可用"}
```

该适配器不使用个人登录 Cookie；会发送与新版 Listen1 一致的设备标记 `os=pc`。
如平台返回试看信息，`trial` 原样输出；有 URL 不代表一定是完整歌曲。
链接可能过期，实际 CDN 播放还可能受请求头、地区等因素影响。本地服务未配置浏览器跨域访问。

## 源码证据与接口映射

指定旧仓库：<https://github.com/listen1/listen1>

固定提交：`8b5298d02f80c26c4fe5cc3e8d5aa44ee17f3fe4`。
其 README 明确写明停止维护，指向插件版和桌面版。

| 旧版本地接口 | 源文件 / 符号 | 返回内容 |
| --- | --- | --- |
| `/search?source=0&keywords=...` | `listen1/handlers/search.py::SearchHandler.get` | `{"result":[歌曲对象]}` |
| `/show_playlist?source=0` | `listen1/handlers/playlist.py::ShowPlaylistHandler.get` | 推荐歌单 |
| `/playlist?list_id=neplaylist_数字` | `listen1/handlers/playlist.py::PlaylistHandler.get` | 歌单歌曲 |
| `/artist?artist_id=neartist_数字` | `listen1/handlers/player.py::ArtistHandler.get` | 歌手歌曲 |
| `/album?album_id=nealbum_数字` | `listen1/handlers/player.py::AlbumHandler.get` | 专辑歌曲 |
| `/track_file?id=netrack_数字&source=netease&artist=...&album=...&title=...` | `listen1/handlers/trackfile.py::TrackFileHandler.get` | 音频流或缓存重定向，而非 JSON 直链 |

以上表格是旧项目的原有路由，不是本适配器新增的全部路由。
旧版 `source` 的枚举：`0=netease, 1=xiami, 2=qq, 3=douban`，证据见 `listen1/replay/__init__.py::get_provider_list`。
搜索结果 `url` 为 `/track_file?...` 本地相对地址，不能直接当作平台 CDN 地址。

### 网易云实际上游

1. `listen1/replay/netease.py::search_track`：POST `http://music.163.com/api/search/get`，表单字段 `s/type/offset/total/limit`。
2. `get_url_by_id`：POST `http://music.163.com/weapi/song/enhance/player/url?csrf_token=`，请求体为 `params + encSecKey`，原始对象含 `ids/br/csrf_token`；读取 `data[0].url`。`params` 由双层 AES-CBC 编码，`encSecKey` 由 RSA 处理会话密钥。
3. `TrackFileHandler`：根据 ID 调用 provider，向上游获取音频并转发给播放器，同时写入缓存。

旧源码的 `br` 为 `12800`，本报告不把它擅自解释为 128 kbps。旧版基于 Python 2（`urllib2/xrange/iteritems`），不能直接用 Python 3 运行。

### 新版对照与本适配器实现

官方后继仓库：<https://github.com/listen1/listen1_chrome_extension>

固定提交：`3f24efa045125875a609dcb0f3f3f0be4edb8b37`。

`js/provider/netease.js::bootstrap_track` 改用：

```text
POST https://interface3.music.163.com/eapi/song/enhance/player/url
原始对象：{"ids":"[歌曲ID]","br":999000}
表单字段：params
响应位置：data[0].url
```

`netease.eapi` 对路径和 JSON 生成 MD5 摘要，再拼接后使用 AES-ECB 编码。
适配器复现该现有请求格式，并采用 `br=128000`；搜索沿用经验证可响应的旧接口 HTTPS 地址。
这不是一个把 `id` 拼入 URL 后就能直接 GET 的公开 REST 音频地址。

QQ 旧版的 `replay/qq.py::_get_qqtoken/get_url_by_id` 先请求 musicexpress 获取 key，再拼接 `cc.stream.qqmusic.qq.com/C200{songmid}.m4a?vkey=...`。
它是旧代码中的机制，本适配器未实现 QQ，也未证实该旧机制当前可用。

## 验证记录（2026-10-23，北京时间）

- 网易云 POST 搜索 `晴天` 与 `Beethoven`：HTTP 200，返回含 ID、歌名等字段的歌曲列表。
- 网易云歌曲详情 ID `347230`：HTTP 200，返回歌曲信息。
- 新版 EAPI 播放查询 ID `347230`、`26705082`：顶层 code=200，单曲 code=404，url=null。
- 旧版 WEAPI 批量查询 `26705082/5276808/25830157/1901371647/22636634`：各歌曲均 url=null、单曲 code=404。
- outer/url 尝试 `26705082/5276808`：HTTP 200，但内容为 JSON 错误（code=-460），不是 MP3。
- QQ 旧搜索地址以网易云 Referer 请求：返回 Refer Error。这只能说明该请求条件不满足，不能据此断言 QQ 接口已失效。
- 本地路由检查：`/health` 返回 200，无效 ID 返回 400，空关键词返回 400，未知路径返回 404。
- 未验证 CDN 音频字节；不能宣称音乐播放成功。

接口响应未提供足够证据区分地区限制、权限、资源状态或协议变化；应在实际使用环境继续验证。

## reverse-skill 方法的使用范围

参考了指定仓库的 README_zh、README_AI、MASTER-ROUTING 和 js-reverse：先确认目标和入口，再沿调用链取证，最后最小复现并区分事实与假设。
本次为开源源码分析与普通接口调用验证，没有安装、注册或执行 reverse-skill 自带脚本，也没有完成其完整 bootstrap/case-review 流程。
因此本报告是参考该方法的源码接口提取结果，不声称完整运行该工具链。

## 文件

- `music_api.py`：本地接口适配器。
- `requirements.txt`：Python 依赖。
- `verification.json`：单曲播放查询的实际返回结果（null）。
- `source_evidence.json`：关键源文件、符号及 SHA256。
- `LICENSE`：上游 MIT 许可证。
