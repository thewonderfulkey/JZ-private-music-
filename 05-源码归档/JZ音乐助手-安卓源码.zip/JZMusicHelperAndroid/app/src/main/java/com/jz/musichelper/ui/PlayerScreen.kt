package com.jz.musichelper.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.model.PlayMode
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.LyricLine
import com.jz.musichelper.network.LyricsService
import com.jz.musichelper.network.SourcePicker
import com.jz.musichelper.network.SourceProbe
import com.jz.musichelper.network.UrlResolver
import com.jz.musichelper.ui.theme.LocalPalette
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

// ===== 正在播放页 v1.5.2（大歌词模式：双击封面→控制栏上方全为歌词；双击歌词→渐变切回封面）=====
@Composable
fun PlayerScreen(song: Song, onBack: () -> Unit) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()

    var showLyrics by remember { mutableStateOf(false) }   // 大歌词模式：true=主体区域显示歌词
    var showSheet by remember { mutableStateOf(false) }
    var lyricsLoading by remember { mutableStateOf(true) } // 歌词是否仍在请求中（加载中提示）
    var lyrics by remember { mutableStateOf<List<LyricLine>>(emptyList()) }
    var lyricsSource by remember { mutableStateOf<String?>(null) }
    var isDownloading by remember { mutableStateOf(false) }

    // 取流状态来自全局播放任务（点击/切歌即开始解析，退出播放页也不中断）；本页只消费，不自行发起请求
    val songKey = song.platform.name + song.platformID
    val isResolving = AppState.resolvingSongKey.value == songKey
    val resolveErr = AppState.resolveError.value?.takeIf { it.first == songKey }?.second

    val position by PlayerManager.position.collectAsState()
    val duration by PlayerManager.duration.collectAsState()
    val isPlaying by PlayerManager.isPlaying.collectAsState()
    val playerErrorFlow by PlayerManager.error.collectAsState()
    var dragValue by remember { mutableStateOf<Float?>(null) }

    // 进入/切歌：取流由 AppState 全局任务完成（见 resolveAndPlayIfNeeded），本页不再持有 LaunchedEffect 取流，
    // 避免"退出播放页即取消请求、永远加载不出来"的问题
    // 加载歌词（网易云官方直连 → 网易云搜索精确匹配 → LrcApi 兜底；统一简体）
    LaunchedEffect(song.platform, song.platformID) {
        lyrics = emptyList()
        lyricsSource = null
        lyricsLoading = true
        val r = runCatching { LyricsService.fetch(song) }.getOrNull()
        if (r != null && r.lines.isNotEmpty()) {
            lyrics = r.lines
            lyricsSource = r.source
        }
        lyricsLoading = false
    }

    // 外层：不透明主题渐变背景 → 全屏覆盖主界面，杜绝下层内容透出
    // 空白区域拦截点击，防止点击穿透到下层主界面
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(p.glow, Color.Transparent),
                        center = Offset(0.5f, 0f),
                        radius = 900f
                    )
                )
                // 背景保持全屏，内容避开状态栏与系统手势条
                .safeDrawingPadding()
        ) {
        // 固定比例：内容列最大宽度 500dp 并水平居中 → 手机/iPad 观感一致
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 500.dp)
                .align(Alignment.TopCenter)
        ) {
            // 顶部：返回 + 标题 + 更多
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButtonCompat(Icons.AutoMirrored.Filled.ArrowBack, "返回", onClick = onBack)
                Text(
                    "正在播放",
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = p.text2,
                    fontSize = 15.sp
                )
                IconButtonCompat(Icons.Filled.MoreVert, "更多", onClick = { toast("更多操作（演示）") })
            }

            // 主体区：封面/歌名/歌手/爱心 ↔ 大歌词，渐变动画切换；进度与控制在下方固定
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center
            ) {
                AnimatedContent(
                    targetState = showLyrics,
                    transitionSpec = {
                        (fadeIn(tween(300)) togetherWith fadeOut(tween(300)))
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    label = "cover-lyrics"
                ) { ly ->
                    if (ly) {
                        LyricsLargeView(
                            lines = lyrics,
                            source = lyricsSource,
                            loading = lyricsLoading,
                            position = position,
                            onToggle = { showLyrics = false }   // 双击歌词 → 渐变切回封面
                        )
                    } else {
                        PlayerCoverBlock(
                            song = song,
                            showLyrics = showLyrics,
                            onToggle = { showLyrics = true }    // 双击封面 → 渐变切到大歌词
                        )
                    }
                }

                // 进度条
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(formatTime(position), color = p.text3, fontSize = 11.sp)
                    Slider(
                        value = if (duration > 0) (dragValue ?: position.toFloat()).coerceIn(0f, duration.toFloat()) else 0f,
                        onValueChange = { dragValue = it },
                        onValueChangeFinished = {
                            dragValue?.let { PlayerManager.seekTo(it.toLong()) }
                            dragValue = null
                        },
                        valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                        enabled = duration > 0,
                        colors = SliderDefaults.colors(
                            thumbColor = p.accent,
                            activeTrackColor = p.accent,
                            inactiveTrackColor = p.surface2
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                    )
                    Text(formatTime(duration), color = p.text3, fontSize = 11.sp)
                }

                // 底部单行（从左到右）：循环播放 → 左切歌 → 暂停（封面正中）→ 右切歌 → 下载
                // 歌词入口已移除（双击封面即可查看歌词），保证窄屏安卓手机也能完整放下
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 左侧空位：循环播放（靠左排列）
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 循环/随机按钮：单曲循环 → 列表循环 → 随机播放，每点一次切换一次
                        val mode = AppState.playMode.value
                        val (modeIcon, modeLabel) = when (mode) {
                            PlayMode.SINGLE_LOOP -> Icons.Filled.RepeatOne to "单曲循环"
                            PlayMode.LIST_LOOP -> Icons.Filled.Repeat to "列表循环"
                            PlayMode.SHUFFLE -> Icons.Filled.Shuffle to "随机播放"
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { AppState.cyclePlayMode() }
                        ) {
                            Icon(
                                modeIcon,
                                contentDescription = null,
                                tint = p.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(modeLabel, color = p.accent, fontSize = 10.sp)
                        }
                    }
                    // 左切歌（距暂停固定间距）
                    IconBtnLarge(Icons.Filled.SkipPrevious, "上一首", onClick = { AppState.prevSong() })
                    Spacer(Modifier.width(20.dp))
                    // 暂停 / 播放（封面正中 / 整行正中）
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(50))
                            .background(p.accent)
                            .clickable { PlayerManager.toggle() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "暂停" else "播放",
                            tint = Color(0xFF101410),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Spacer(Modifier.width(20.dp))
                    // 右切歌
                    IconBtnLarge(Icons.Filled.SkipNext, "下一首", onClick = { AppState.nextSong() })
                    // 右侧空位：下载（靠右排列）
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { showSheet = true }) {
                            Icon(
                                Icons.Filled.Download,
                                contentDescription = null,
                                tint = p.text2,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.height(2.dp))
                            Text("下载", color = p.text2, fontSize = 11.sp)
                        }
                    }
                }

                if (isResolving) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = p.accent, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("正在解析音源…", color = p.text3, fontSize = 12.sp)
                    }
                } else if (resolveErr != null) {
                    Text(resolveErr, color = Color(0xFFE5484D), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                } else if (playerErrorFlow != null) {
                    Text(playerErrorFlow!!, color = Color(0xFFE5484D), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }

            }   // 主体 Column 闭合
        }   // 内容列闭合
        }   // 主内容 Box（背景+避让）闭合

        // 下载弹层
        if (showSheet) {
            DownloadSheet(
                song = song,
                isDownloading = isDownloading,
                onCancel = { showSheet = false },
                onConfirm = { q ->
                    scope.launch {
                        isDownloading = true
                        val r = runCatching { UrlResolver.resolveAll(song, q) }.getOrNull()
                        // 按所选音质挑选最匹配源（无损优先 flac/ape/wav，杜绝“选无损拿 128k m4a”）
                        val src = if (r != null) SourcePicker.pick(r.sources, q) else null
                        if (src != null) {
                            DownloadManager.startDownload(song, src)
                            val downgraded = src.quality != q
                            val note = if (downgraded) "（未找到${q.displayName}源，已自动降级为${src.quality.displayName}）" else ""
                            toast("开始下载《${song.name}》${q.displayName}${note}")
                        } else {
                            toast("暂无可用音源，请稍后重试")
                        }
                        isDownloading = false
                        showSheet = false
                    }
                }
            )
        }
    }
}

// ===== 封面区（大封面 + 歌名/歌手 + 爱心；双击/单击切换大歌词）=====
@Composable
private fun PlayerCoverBlock(
    song: Song,
    showLyrics: Boolean,
    onToggle: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        // 封面
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val coverSize = 286.dp
            Box(
                modifier = Modifier
                    .size(coverSize)
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.surface2)
                    .pointerInput(Unit) {
                        // 约定交互：仅双击封面切换大歌词；单击不响应（避免单击误入歌词/双击来回闪）
                        detectTapGestures(
                            onDoubleTap = { onToggle() }
                        )
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.linearGradient(listOf(p.surface2, p.surface)))
                ) {
                    val url = song.picUrl
                    if (!url.isNullOrBlank()) {
                        androidx.compose.foundation.Image(
                            painter = coil.compose.rememberAsyncImagePainter(url),
                            contentDescription = song.name,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.PlayArrow, contentDescription = null,
                                tint = p.accent2.copy(alpha = 0.5f),
                                modifier = Modifier.size(90.dp)
                            )
                        }
                    }
                }
                Text(
                    "双击看歌词",
                    color = Color(0xFFE8F2EA),
                    fontSize = 10.sp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .background(Color(0x66000000), RoundedCornerShape(percent = 50))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Spacer(Modifier.height(18.dp))

        // 歌名 / 歌手
        Text(
            song.name,
            color = p.text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            song.singer + (if (song.album.isNotBlank()) " · " + song.album else ""),
            color = p.text2,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)
        )

        // 爱心：右侧、进度条略上方（对齐原型）
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.weight(1f))
            PlayerFavBtn(song)
        }
        Spacer(Modifier.height(6.dp))
    }
}

// ===== 大歌词视图（占播放控制栏上方全部空间；当前行滚动高亮；双击/单击切回封面）=====
@Composable
private fun LyricsLargeView(
    lines: List<LyricLine>,
    source: String?,
    loading: Boolean,
    position: Long,
    onToggle: () -> Unit
) {
    val p = LocalPalette.current
    val listState = rememberLazyListState()
    val hl = LyricsService.indexAt(lines, position)

    // 跟唱滚动（网易云同款实现）：歌词列表上下各加“半个视口高度”的空白占位，
    // 滚动到当前行 index（顶部对齐）后，当前行恰好出现在视口正中间。
    // 旧实现依赖 layoutInfo 计算偏移，歌词不足一屏时无法滚动导致当前行停留在顶部。
    LaunchedEffect(hl) {
        if (hl >= 0) {
            // 等一帧确保列表完成首次布局，再平滑滚动到当前行
            withFrameNanos { }
            listState.animateScrollToItem(hl)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .pointerInput(Unit) {
                // 约定交互：仅双击歌词切回封面；单击不响应
                detectTapGestures(
                    onDoubleTap = { onToggle() }
                )
            }
    ) {
        if (lines.isNotEmpty()) {
            val halfVh = maxHeight / 2
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(vertical = halfVh)
            ) {
                items(lines.size) { i ->
                    val line = lines[i]
                    val active = i == hl
                    // 当前行：明显变大+变色（tween 320ms 平滑）；唱过后恢复原样
                    val fontSize by animateFloatAsState(
                        targetValue = if (active) 22f else 14f,
                        animationSpec = tween(320),
                        label = "lyricSize"
                    )
                    val textColor by animateColorAsState(
                        targetValue = if (active) p.accent2 else p.text3.copy(alpha = 0.45f),
                        animationSpec = tween(320),
                        label = "lyricColor"
                    )
                    Text(
                        line.text.ifBlank { " " },
                        color = textColor,
                        fontSize = fontSize.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = if (active) 9.dp else 6.dp)
                    )
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        loading -> "歌词加载中…"
                        source != null -> "暂无歌词（$source）"
                        else -> "暂无歌词"
                    },
                    color = p.text3,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ===== 播放页爱心（右侧进度条上方；空心↔实心）=====
@Composable
private fun PlayerFavBtn(song: Song) {
    val p = LocalPalette.current
    var fav by remember { mutableStateOf(HistoryStore.isFavorite(song)) }
    Box(
        modifier = Modifier
            .size(44.dp)
            .clickable { fav = HistoryStore.toggleFavorite(song) },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = if (fav) "取消收藏" else "收藏",
            tint = if (fav) p.heartOn else p.text3.copy(alpha = 0.9f),
            modifier = Modifier.size(26.dp)
        )
    }
}

// ===== 下载弹层：三档音质 + 单个开始下载按钮（隐藏来源，内部按音质自动匹配）=====
@Composable
private fun DownloadSheet(
    song: Song,
    isDownloading: Boolean,
    onCancel: () -> Unit,
    onConfirm: (QualityLevel) -> Unit
) {
    val p = LocalPalette.current
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }
    // 打开时检测三档真实可用性：有源的档位可点，无源置灰不可点（复用 SourceProbe 缓存，短超时）
    var available by remember(song) { mutableStateOf<Map<QualityLevel, Boolean>?>(null) }
    LaunchedEffect(song) {
        available = coroutineScope {
            val results = QualityLevel.entries.map { q -> async { q to (SourceProbe.probe(song, q).state == SourceProbe.ProbeState.OK) } }
            results.associate { it.await() }
        }
    }
    val enabledFor: (QualityLevel) -> Boolean = { q -> available?.get(q) ?: false }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(enabled = !isDownloading, onClick = onCancel),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .padding(horizontal = 22.dp, vertical = 18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("下载歌曲", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "取消",
                    tint = p.text3,
                    modifier = Modifier
                        .size(32.dp)
                        .clickable(enabled = !isDownloading, onClick = onCancel)
                        .padding(6.dp)
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(song.name + " · " + song.singer, color = p.text2, fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QualityLevel.entries.forEach { q ->
                    val selected = quality == q
                    val has = enabledFor(q)
                    val colColor = when {
                        selected -> p.accent.copy(alpha = 0.16f)
                        has -> p.surface2
                        else -> p.surface2.copy(alpha = 0.45f)
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(colColor, RoundedCornerShape(12.dp))
                            .clickable(enabled = !isDownloading && has) { quality = q }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            q.displayName,
                            color = if (selected) p.accent2 else if (has) p.text2 else p.text3.copy(alpha = 0.5f),
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        )
                        if (!has) {
                            Spacer(Modifier.height(3.dp))
                            Text(
                                if (available == null) "检测中…" else "该曲无此音质",
                                color = p.text3.copy(alpha = 0.6f),
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                when {
                    available == null -> "正在检测可用音质…"
                    !enabledFor(quality) -> "请选择有可用音源的品质"
                    else -> "将自动匹配可用音源"
                },
                color = p.text3,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDownloading || available == null || !enabledFor(quality)) p.surface2 else p.accent, RoundedCornerShape(14.dp))
                    .clickable(enabled = !isDownloading && available != null && enabledFor(quality)) { onConfirm(quality) }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isDownloading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF101410), strokeWidth = 2.dp)
                } else {
                    Text(
                        "开始下载",
                        color = if (available == null || !enabledFor(quality)) p.text3 else Color(0xFF101410),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

// ===== 通用小组件 =====
@Composable
private fun IconButtonCompat(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(40.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = p.text2, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun IconBtnLarge(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(48.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = p.text2, modifier = Modifier.size(32.dp))
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = ms / 1000
    return String.format("%02d:%02d", totalSec / 60, totalSec % 60)
}

// 简易 toast（不依赖系统 Toast 也能在 Compose 内提示）
private var toastText = mutableStateOf<String?>(null)
private var toastJob: kotlinx.coroutines.Job? = null
fun toast(msg: String) {
    toastText.value = msg
    toastJob?.cancel()
    toastJob = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
        kotlinx.coroutines.delay(1800)
        toastText.value = null
    }
}

@Composable
fun ToastHost() {
    val p = LocalPalette.current
    val msg = toastText.value ?: return
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            msg,
            color = p.text,
            fontSize = 13.sp,
            modifier = Modifier
                .background(Color(0xE6293330), RoundedCornerShape(percent = 50))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}
