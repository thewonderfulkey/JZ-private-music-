package com.jz.musichelper.network

import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap

/**
 * 音源可用性预检（搜索结果惰性过滤 / 下载音质档位检测共用）。
 *
 * 三态判定（修复 v1.7.2 误隐藏）：
 *  - OK    ：接口确认有可用源 → 不隐藏
 *  - EMPTY ：接口明确完成且无任何可用源 → 才允许隐藏
 *  - 检测中/排队中：由 isProbing() 暴露给 UI 做半透明"检测音源中…"标识，绝不当作无源隐藏
 *
 * 并发安全：同一首歌同一音质的并发请求复用同一个 Deferred（滚动反复触发不会因冲突误判）；
 * 完整解析不截断（慢接口最长等到底层适配器自身超时 ~12s），结果为准；
 * 全局并发限流 Semaphore(6)，滚动触发的大量预检排队执行，避免打爆解析接口。
 */
object SourceProbe {

    enum class ProbeState { OK, EMPTY }

    data class ProbeResult(val state: ProbeState, val sources: List<StreamSource>)

    private data class CacheEntry(val result: ProbeResult, val at: Long)

    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val inflight = ConcurrentHashMap<String, Deferred<ProbeResult>>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private const val TTL_MS = 10 * 60_000L
    private const val MAX_CONCURRENT = 6

    private val gate = Semaphore(MAX_CONCURRENT)

    private fun key(song: Song, quality: QualityLevel) = song.platform.name + "|" + song.platformID + "|" + quality.name

    /** 是否已有可靠结论（OK/EMPTY 且在 TTL 内）——有结论的歌不重复发起检测 */
    fun isCached(song: Song, quality: QualityLevel): Boolean {
        val e = cache[key(song, quality)] ?: return false
        return System.currentTimeMillis() - e.at < TTL_MS
    }

    /** 是否正在检测中（含排队）——UI 用于"检测音源中…"半透明标识 */
    fun isProbing(song: Song, quality: QualityLevel): Boolean = inflight.containsKey(key(song, quality))

    /** 检测（挂起直到出结论）：OK=有源；EMPTY=明确无源。并发触发复用同一任务，不因冲突误判。 */
    suspend fun probe(song: Song, quality: QualityLevel): ProbeResult {
        val k = key(song, quality)
        cache[k]?.let {
            if (System.currentTimeMillis() - it.at < TTL_MS) return it.result
        }
        val deferred = inflight.computeIfAbsent(k) {
            scope.async {
                val result = runProbe(song, quality)
                cache[k] = CacheEntry(result, System.currentTimeMillis())
                result
            }
        }
        try {
            return deferred.await()
        } finally {
            inflight.remove(k, deferred)
        }
    }

    private suspend fun runProbe(song: Song, quality: QualityLevel): ProbeResult = gate.withPermit {
        val r = runCatching { UrlResolver.resolveAll(song, quality) }.getOrNull()
        val sources = r?.sources ?: emptyList()
        if (sources.isEmpty()) ProbeResult(ProbeState.EMPTY, emptyList())
        else ProbeResult(ProbeState.OK, sources)
    }
}
