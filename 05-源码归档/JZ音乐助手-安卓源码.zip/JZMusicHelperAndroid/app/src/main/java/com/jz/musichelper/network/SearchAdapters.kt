package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.Song
import org.json.JSONArray
import org.json.JSONObject

// 搜索适配器：每个平台一个实现
interface SearchAdapter {
    val platform: MusicPlatform
    suspend fun search(keyword: String, limit: Int): List<Song>
}

// ---------- QQ 音乐搜索 ----------
// https://c.y.qq.com/soso/fcgi-bin/client_search_cp?p=1&n=10&w=关键词&format=json
class QQSearchAdapter : SearchAdapter {
    override val platform = MusicPlatform.QQ

    override suspend fun search(keyword: String, limit: Int): List<Song> {
        val url = "https://c.y.qq.com/soso/fcgi-bin/client_search_cp?p=1&n=$limit&w=${urlEncode(keyword)}&format=json"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://y.qq.com/"))
        val list = json.optJSONObject("data")?.optJSONObject("song")?.optJSONArray("list") ?: JSONArray()
        val songs = mutableListOf<Song>()
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            val songname = item.optString("songname") ?: continue
            val songmid = item.optString("songmid") ?: continue
            if (songname.isEmpty() || songmid.isEmpty()) continue
            val singers = (item.optJSONArray("singer") ?: JSONArray()).let { arr ->
                buildString {
                    for (j in 0 until arr.length()) {
                        if (j > 0) append("/")
                        append(arr.optJSONObject(j)?.optString("name") ?: "")
                    }
                }
            }
            val album = item.optString("albumname", "")
            val dur = item.optInt("interval", 0)
            val albumMid = item.optString("albummid", "")
            val pic = if (albumMid.isNotEmpty()) "https://y.gtimg.cn/music/photo_new/T002R300x300M000$albumMid.jpg" else null
            songs.add(Song(MusicPlatform.QQ, songmid, songname, singers, album, dur, pic))
        }
        return songs
    }
}

// ---------- 网易云搜索 ----------
// https://music.163.com/api/search/get/web?csrf_token=&s=关键词&type=1&offset=0&limit=10
class NeteaseSearchAdapter : SearchAdapter {
    override val platform = MusicPlatform.NETEASE

    override suspend fun search(keyword: String, limit: Int): List<Song> {
        val url = "https://music.163.com/api/search/get/web?csrf_token=&s=${urlEncode(keyword)}&type=1&offset=0&limit=$limit"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://music.163.com/"))
        if (json.optInt("code") != 200) return emptyList()
        val list = json.optJSONObject("result")?.optJSONArray("songs") ?: JSONArray()
        val songs = mutableListOf<Song>()
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            val id = item.optLong("id", -1)
            val name = item.optString("name", "")
            if (id <= 0 || name.isEmpty()) continue
            val artists = (item.optJSONArray("artists") ?: JSONArray()).let { arr ->
                buildString {
                    for (j in 0 until arr.length()) {
                        if (j > 0) append("/")
                        append(arr.optJSONObject(j)?.optString("name") ?: "")
                    }
                }
            }
            val albumObj = item.optJSONObject("album")
            val album = albumObj?.optString("name", "") ?: ""
            val durMs = item.optLong("duration", 0)
            val pic = albumObj?.optString("picUrl")?.takeIf { it.isNotEmpty() }
            songs.add(Song(MusicPlatform.NETEASE, id.toString(), name, artists, album, (durMs / 1000).toInt(), pic))
        }
        return songs
    }
}

// ---------- 酷我搜索 ----------
// https://search.kuwo.cn/r.s?all=关键词&ft=music&rn=10&pn=1&rformat=json&encoding=utf8
// 注意：返回的是 Python 风格单引号 dict 文本（非标准 JSON），需特殊解析
class KuwoSearchAdapter : SearchAdapter {
    override val platform = MusicPlatform.KUWO

    override suspend fun search(keyword: String, limit: Int): List<Song> {
        val url = "https://search.kuwo.cn/r.s?all=${urlEncode(keyword)}&ft=music&rn=$limit&pn=1&rformat=json&encoding=utf8"
        val text = ApiClient.get(url, headers = mapOf("Referer" to "https://www.kuwo.cn/"))
        val records = extractAbsList(text)
        val songs = mutableListOf<Song>()
        for (item in records) {
            val name = item["SONGNAME"]?.trim().orEmpty()
            val rawRid = item["MUSICRID"].orEmpty().replace("MUSIC_", "")
            if (name.isEmpty() || rawRid.isEmpty()) continue
            val artist = item["ARTIST"].orEmpty()
            val album = item["ALBUM"].orEmpty()
            val dur = parseDuration(item["DURATION"].orEmpty())
            songs.add(Song(MusicPlatform.KUWO, rawRid, name, artist, album, dur, null))
        }
        return songs
    }

    /** 从 Python 单引号 dict 文本中抽取 abslist 记录 */
    private fun extractAbsList(text: String): List<Map<String, String>> {
        val absIdx = text.indexOf("'abslist'")
        if (absIdx < 0) return emptyList()
        val rest = text.substring(absIdx)
        val open = rest.indexOf('[')
        val close = rest.lastIndexOf(']')
        if (open < 0 || close <= open) return emptyList()
        val listText = rest.substring(open, close + 1)
        val chunks = splitTopLevel(listText)
        return chunks.mapNotNull { parseSingleQuotedDict(it) }
    }

    private fun splitTopLevel(s: String): List<String> {
        val inner = s.removePrefix("[").removeSuffix("]")
        var depth = 0
        var current = StringBuilder()
        val chunks = mutableListOf<String>()
        for (ch in inner) {
            when (ch) {
                '[', '{' -> depth++
                ']', '}' -> depth--
                ',' -> if (depth == 0) {
                    val c = current.toString()
                    if (c.isNotBlank()) chunks.add(c)
                    current = StringBuilder()
                } else current.append(ch)
                else -> current.append(ch)
            }
        }
        if (current.toString().isNotBlank()) chunks.add(current.toString())
        return chunks
    }

    /** 解析单引号键值对：'key':'value' */
    private fun parseSingleQuotedDict(text: String): Map<String, String>? {
        val trimmed = text.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) return null
        val inner = trimmed.removePrefix("{").removeSuffix("}")
        val map = mutableMapOf<String, String>()
        val regex = Regex("'([^']*)':\\s*'((?:[^'\\\\]|\\\\.)*)'")
        regex.findAll(inner).forEach { m ->
            val key = m.groupValues[1]
            var value = m.groupValues[2].replace("\\'", "'")
            value = value.replace("&nbsp;", " ").replace("&amp;", "&")
            map[key] = value
        }
        return map.ifEmpty { null }
    }

    private fun parseDuration(s: String): Int {
        val parts = s.split(":")
        return when (parts.size) {
            2 -> parts[0].toIntOrNull()?.times(60)?.plus(parts[1].toIntOrNull() ?: 0) ?: 0
            3 -> {
                val h = parts[0].toIntOrNull() ?: 0
                val m = parts[1].toIntOrNull() ?: 0
                val sec = parts[2].toIntOrNull() ?: 0
                h * 3600 + m * 60 + sec
            }
            else -> 0
        }
    }
}

// ---------- 酷狗搜索 ----------
// https://mobilecdn.kugou.com/api/v3/search/song?format=json&keyword=关键词&page=1&pagesize=10&showtype=1
class KugouSearchAdapter : SearchAdapter {
    override val platform = MusicPlatform.KUGOU

    override suspend fun search(keyword: String, limit: Int): List<Song> {
        val url = "https://mobilecdn.kugou.com/api/v3/search/song?format=json&keyword=${urlEncode(keyword)}&page=1&pagesize=$limit&showtype=1"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://www.kugou.com/"))
        val list = json.optJSONObject("data")?.optJSONArray("info") ?: JSONArray()
        val songs = mutableListOf<Song>()
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            val songname = item.optString("songname", "")
            val hash = item.optString("hash", "")
            if (songname.isEmpty() || hash.isEmpty()) continue
            val singer = item.optString("singername", "")
            val album = item.optString("album_name", "")
            val dur = item.optInt("duration", 0)
            val albumId = item.optLong("album_id", -1)
            val pic = if (albumId > 0) "https://imgessl.kugou.com/stdmusic/$albumId/500.jpg" else null
            songs.add(Song(MusicPlatform.KUGOU, hash, songname, singer, album, dur, pic))
        }
        return songs
    }
}

internal fun urlEncode(s: String): String {
    return java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
}
