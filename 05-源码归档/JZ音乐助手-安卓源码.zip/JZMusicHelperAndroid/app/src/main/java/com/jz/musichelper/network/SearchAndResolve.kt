package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

// 并发搜索服务：所有平台同时搜，先返回的先进结果列表；单平台超时/失败自动忽略
// 硬约束：任何单个平台的任何异常都不得外抛（否则整个 App 崩溃），就地转为失败结果
object SearchService {

    private val adapters: List<SearchAdapter> = listOf(
        QQSearchAdapter(),
        NeteaseSearchAdapter(),
        KuwoSearchAdapter(),
        KugouSearchAdapter()
    )

    private const val PER_SOURCE_TIMEOUT_MS = 10_000L

    // 每个平台的搜索结果（保持平台维度）
    data class PlatformResult(val platform: MusicPlatform, val songs: List<Song>, val error: String?)

    /** 并发搜索全部平台，等待所有完成（每个平台独立超时；单平台失败只标记 error，不抛出） */
    suspend fun searchAll(keyword: String, limit: Int = 20): List<PlatformResult> = coroutineScope {
        adapters.map { adapter ->
            async {
                try {
                    val result = withTimeoutOrNull(PER_SOURCE_TIMEOUT_MS) {
                        adapter.search(keyword, limit)
                    }
                    if (result != null) {
                        PlatformResult(adapter.platform, result, null)
                    } else {
                        PlatformResult(adapter.platform, emptyList(), "超时")
                    }
                } catch (e: Exception) {
                    // 捕获一切异常（含取消副作用 / SSL / 解析失败），转为该平台失败，绝不外抛
                    PlatformResult(adapter.platform, emptyList(), e.message ?: "失败")
                }
            }
        }.awaitAll()
    }
}

// 并发取流解析：一首歌同时尝试所有可用后端，收集全部成功结果
// 硬约束：单个后端失败只计入 failed，不外抛
object UrlResolver {

    private const val PER_BACKEND_TIMEOUT_MS = 12_000L

    data class ResolveResult(val sources: List<StreamSource>, val failed: Map<String, String>)

    suspend fun resolveAll(song: Song, quality: QualityLevel): ResolveResult = coroutineScope {
        val adapters = SourceRegistry.adaptersFor(song)
        val sources = mutableListOf<StreamSource>()
        val failed = mutableMapOf<String, String>()

        adapters.map { adapter ->
            async {
                val r = try {
                    withTimeoutOrNull(PER_BACKEND_TIMEOUT_MS) {
                        adapter.resolve(song, quality)
                    }
                } catch (e: Exception) {
                    null
                }
                adapter.name to r
            }
        }.awaitAll().forEach { (name, src) ->
            if (src != null) sources.add(src) else failed[name] = "失败或超时"
        }
        ResolveResult(sources, failed)
    }
}

// 按用户所选音质从多个可用源中挑选最匹配的一个（防“选无损却拿到 128k m4a”）
// 评分：无损优先 flac/ape/wav 真无损 → 标注无损 → 高品 → 标准；m4a 一律最低优先级
object SourcePicker {
    fun pick(sources: List<StreamSource>, want: QualityLevel): StreamSource? {
        if (sources.isEmpty()) return null
        return sources.maxWithOrNull(compareBy { score(it, want) })
    }

    private fun score(src: StreamSource, want: QualityLevel): Int {
        val isLosslessFmt = src.format.contains("flac") || src.format.contains("ape") || src.format.contains("wav")
        return when (want) {
            QualityLevel.LOSSLESS -> when {
                src.quality == QualityLevel.LOSSLESS && isLosslessFmt -> 5
                src.quality == QualityLevel.LOSSLESS -> 4
                src.quality == QualityLevel.HIGH -> 2
                src.quality == QualityLevel.STANDARD -> 1
                else -> 0
            }
            QualityLevel.HIGH -> when {
                src.quality == QualityLevel.HIGH && !src.format.contains("m4a") -> 4
                src.quality == QualityLevel.HIGH -> 3
                src.quality == QualityLevel.LOSSLESS -> 3
                src.quality == QualityLevel.STANDARD -> 1
                else -> 0
            }
            QualityLevel.STANDARD -> if (src.quality == QualityLevel.STANDARD) 2 else 1
        }
    }
}
