package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import okhttp3.Request

// 轻量校验：Range GET 检查候选 URL 返回的是音频而非 HTML 落地页（IO 线程）
object StreamVerifier {
    suspend fun isAudioUrl(urlString: String, timeoutSec: Long = 8): Boolean {
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val req = Request.Builder()
                    .url(urlString)
                    .header("Range", "bytes=0-4095")
                    .header("User-Agent", ApiClient.MOBILE_UA)
                    .header("Referer", "https://music.qq.com/")
                    .build()
                ApiClient.client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful && resp.code != 206) return@withContext false
                    // 必须真正是音频：Content-Type 需 audio/* 或 octet-stream；JSON/HTML/文本一律不算
                    val ct = resp.header("Content-Type")?.lowercase() ?: return@withContext false
                    val isAudio = ct.startsWith("audio/") || ct.contains("octet-stream")
                    isAudio
                }
            } catch (_: Exception) {
                false
            }
        }
    }
}

// 取流后端：给定歌曲与音质，返回可用流地址
interface StreamSourceAdapter {
    val name: String
    val platform: MusicPlatform
    suspend fun resolve(song: Song, quality: QualityLevel): StreamSource
}

// ---------- 酷我系 ----------

// oiapi 酷我（搜索式）——酷我/酷狗取流主力（实测返回全量 320k）
class OiapiKuwoAdapter : StreamSourceAdapter {
    override val name = "oiapi 酷我"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val br = when (quality) {
            QualityLevel.STANDARD -> "7"
            QualityLevel.HIGH -> "5"
            QualityLevel.LOSSLESS -> "1"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://oiapi.net/api/Kuwo?msg=${urlEncode(song.searchKeyword)}&n=1&br=$br"
        val json = ApiClient.getJson(url, timeoutSec = 10)
        // oiapi 改版后：URL 可能仍在 data.url / url，也可能只在 message 文本的"音乐链接："里（实测全量 320k）
        var stream: String? = json.optJSONObject("data")?.optString("url", "")
        if (stream.isNullOrEmpty()) stream = json.optString("url", "")
        if (stream.isNullOrEmpty()) stream = extractUrlFromMessage(json.optString("message", ""))
        if (stream.isNullOrEmpty()) throw ApiError.Parse("oiapi 酷我未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "搜索式取流")
    }

    /** 从 oiapi 改版后的 message 文本中提取"音乐链接："后的 URL（形如 音乐链接：http://...±换行） */
    private fun extractUrlFromMessage(message: String): String? {
        if (message.isBlank()) return null
        val idx = message.indexOf("音乐链接")
        val from = if (idx >= 0) message.substring(idx + 4) else message
        val m = Regex("https?://\\S+").find(from) ?: return null
        return m.value.trim().trimEnd('±', '，', '。')
    }
}

// ---------- QQ 系 ----------

// cyapi.top QQ 直链
class CyapiQQAdapter : StreamSourceAdapter {
    override val name = "cyapi QQ"
    override val platform = MusicPlatform.QQ

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val url = "https://cyapi.top/API/qq_music.php?apikey=1ffdf5733f5d538760e63d7e46ba17438d9f7b9dfc18c51be1109386fd74c3a1&type=json&mid=${song.platformID}"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://y.qq.com/"), timeoutSec = 12)
        val stream = json.optString("url", "")
        if (stream.isEmpty()) throw ApiError.Parse("cyapi 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        // 修正标注：cyapi 只提供 m4a，恒标注高品，禁止以"无损"名义返回 m4a（SourcePicker 据此不会误选）
        return StreamSource(stream, name, platform, QualityLevel.HIGH, "m4a", "VIP 全量 m4a")
    }
}

// ---------- 网易云系 ----------

// gdstudio 网易
class GdstudioNeteaseAdapter : StreamSourceAdapter {
    override val name = "gdstudio 网易"
    override val platform = MusicPlatform.NETEASE

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val br = when (quality) {
            QualityLevel.STANDARD -> "128"
            QualityLevel.HIGH -> "320"
            QualityLevel.LOSSLESS -> "740"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://music-api.gdstudio.xyz/api.php?use_xbridge3=true&loader_name=forest&need_sec_link=1&sec_link_scene=im&theme=light&types=url&source=netease&id=${song.platformID}&br=$br"
        val json = ApiClient.getJson(url, headers = mapOf("User-Agent" to "LX-Music-Mobile"), timeoutSec = 12)
        val stream = json.optString("url", "")
        if (stream.isEmpty()) throw ApiError.Parse("gdstudio 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "VIP 全量 mp3/FLAC")
    }
}

// oiapi Music_163
class OiapiNeteaseAdapter : StreamSourceAdapter {
    override val name = "oiapi 网易"
    override val platform = MusicPlatform.NETEASE

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val url = "https://oiapi.net/api/Music_163?id=${song.platformID}"
        val json = ApiClient.getJson(url, timeoutSec = 12)
        if (json.optInt("code") != 0) throw ApiError.Parse("oiapi 网易 code != 0")
        var stream: String? = null
        val data = json.optJSONArray("data")
        if (data != null && data.length() > 0) {
            stream = data.optJSONObject(0)?.optString("url", "")
        }
        if (stream.isNullOrEmpty()) stream = json.optString("url", "")
        if (stream.isNullOrEmpty()) throw ApiError.Parse("oiapi 网易未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, "mp3", "ID 直查")
    }
}

// ---------- 后端注册表 ----------
object SourceRegistry {

    val all: List<StreamSourceAdapter> = listOf(
        OiapiKuwoAdapter(),
        CyapiQQAdapter(),
        GdstudioNeteaseAdapter(),
        OiapiNeteaseAdapter()
    )

    // 某首歌可用的后端：同平台后端 + 跨平台搜索式后端
    fun adaptersFor(song: Song): List<StreamSourceAdapter> {
        val cross = listOf<StreamSourceAdapter>(OiapiKuwoAdapter())
        val result = mutableListOf<StreamSourceAdapter>()
        val seen = mutableSetOf<String>()
        for (a in all.filter { it.platform == song.platform } + cross) {
            if (seen.add(a.name)) result.add(a)
        }
        return result
    }
}

internal fun QualityLevel.levelName(): String = when (this) {
    QualityLevel.STANDARD -> "standard"
    QualityLevel.HIGH -> "exhigh"
    QualityLevel.LOSSLESS -> "lossless"
}
