package com.jz.musichelper.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.jz.musichelper.data.HistoryStore

// ===== 四套渐变暗色主题（对应 UI 原型：夜莺绿/暮山紫/深海蓝/鎏金琥珀）=====

enum class AppThemeType(val displayName: String) {
    NIGHTINGALE("夜莺绿"),
    TWILIGHT("暮山紫"),
    DEEPSEA("深海蓝"),
    AMBER("鎏金琥珀")
}

data class AppPalette(
    val accent: Color,        // 强调主色
    val accent2: Color,       // 强调亮色（渐变收尾/高亮）
    val glow: Color,          // 顶部色晕
    val bgTop: Color,         // 背景渐变顶部
    val bgBottom: Color,      // 背景渐变底部
    val surface: Color,       // 卡片/浮层
    val surface2: Color,      // 次级浮层（进度底/输入框）
    val text: Color,          // 主文字
    val text2: Color,         // 次级文字
    val text3: Color,         // 弱文字
    val heartOn: Color        // 已收藏爱心
)

val Nightingale = AppPalette(
    accent = Color(0xFF1DB954), accent2 = Color(0xFF1ED760), glow = Color(0x6620B058),
    bgTop = Color(0xFF101312), bgBottom = Color(0xFF0B0D0C),
    surface = Color(0xFF161A18), surface2 = Color(0xFF1F2623),
    text = Color(0xFFF2F7F3), text2 = Color(0xFFB7C4BA), text3 = Color(0xFF71806F),
    heartOn = Color(0xFF1ED760)
)

val Twilight = AppPalette(
    accent = Color(0xFFC9A8FF), accent2 = Color(0xFFE3D7FF), glow = Color(0x66583D8F),
    bgTop = Color(0xFF100E15), bgBottom = Color(0xFF0A0810),
    surface = Color(0xFF17141E), surface2 = Color(0xFF211C2C),
    text = Color(0xFFF4F0FA), text2 = Color(0xFFC2B8D2), text3 = Color(0xFF786E8C),
    heartOn = Color(0xFFE3D7FF)
)

val DeepSea = AppPalette(
    accent = Color(0xFF4DA3FF), accent2 = Color(0xFF6EB8FF), glow = Color(0x663A6FA8),
    bgTop = Color(0xFF0A1015), bgBottom = Color(0xFF060B10),
    surface = Color(0xFF0F1720), surface2 = Color(0xFF182634),
    text = Color(0xFFF0F5FA), text2 = Color(0xFFB6C6D6), text3 = Color(0xFF6E8296),
    heartOn = Color(0xFF6EB8FF)
)

val Amber = AppPalette(
    accent = Color(0xFFE3B25C), accent2 = Color(0xFFF0C87E), glow = Color(0x66A06F1E),
    bgTop = Color(0xFF100C07), bgBottom = Color(0xFF0A0704),
    surface = Color(0xFF171209), surface2 = Color(0xFF221B0E),
    text = Color(0xFFFAF6EC), text2 = Color(0xFFD3C5A5), text3 = Color(0xFF87775A),
    heartOn = Color(0xFFF0C87E)
)

fun paletteOf(type: AppThemeType): AppPalette = when (type) {
    AppThemeType.NIGHTINGALE -> Nightingale
    AppThemeType.TWILIGHT -> Twilight
    AppThemeType.DEEPSEA -> DeepSea
    AppThemeType.AMBER -> Amber
}

// 当前主题的调色板，供所有界面读取
val LocalPalette = staticCompositionLocalOf { Nightingale }

@Composable
fun AppTheme(type: AppThemeType, content: @Composable () -> Unit) {
    val p = paletteOf(type)
    val scheme = darkColorScheme(
        primary = p.accent,
        onPrimary = Color(0xFF101410),
        secondary = p.accent2,
        background = p.bgBottom,
        surface = p.surface,
        onBackground = p.text,
        onSurface = p.text,
        surfaceVariant = p.surface2,
        error = Color(0xFFE5484D)
    )
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

// 页面根背景：顶部色晕 + 同色系明暗过渡（暗色渐变，非纯黑）
@Composable
fun AppBackground(content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(p.glow, Color.Transparent),
                    center = Offset(0.5f, 0f),
                    radius = 1600f
                )
            )
            .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
    ) {
        content()
    }
}
