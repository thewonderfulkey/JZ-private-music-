package com.jz.musichelper.data

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import com.jz.musichelper.network.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// 在线试听：系统 MediaPlayer（带 UA/Referer 头）+ 进度/时长状态流
object PlayerManager {

    private lateinit var appContext: Context
    private var player: MediaPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var tickJob: Job? = null

    private val _currentUrl = MutableStateFlow<String?>(null)
    val currentUrl: StateFlow<String?> = _currentUrl

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // 播放完成事件（自增序号，供上层自动连播）
    private val _completed = MutableStateFlow(0L)
    val completed: StateFlow<Long> = _completed

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun play(url: String) {
        stop()
        _currentUrl.value = url
        _error.value = null
        _position.value = 0L
        try {
            val mp = MediaPlayer()
            mp.setDataSource(appContext, Uri.parse(url), mapOf(
                "User-Agent" to ApiClient.MOBILE_UA,
                "Referer" to "https://music.qq.com/"
            ))
            mp.setOnPreparedListener {
                it.start()
                _isPlaying.value = true
                _duration.value = it.duration.toLong().coerceAtLeast(0L)
                startTicker()
            }
            mp.setOnCompletionListener {
                _isPlaying.value = false
                _position.value = _duration.value
                _completed.value++
            }
            mp.setOnErrorListener { _, _, _ ->
                _error.value = "播放失败（源可能已失效）"
                _isPlaying.value = false
                release()
                true
            }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            _error.value = "播放失败：${e.message}"
        }
    }

    fun toggle() {
        val p = player ?: return
        if (_isPlaying.value) {
            p.pause()
            _isPlaying.value = false
        } else {
            p.start()
            _isPlaying.value = true
            startTicker()
        }
    }

    fun seekTo(ms: Long) {
        val p = player ?: return
        runCatching { p.seekTo(ms.toInt()) }
        _position.value = ms
    }

    private fun startTicker() {
        tickJob?.cancel()
        tickJob = scope.launch {
            while (_isPlaying.value) {
                runCatching { _position.value = player?.currentPosition?.toLong() ?: _position.value }
                delay(500)
            }
        }
    }

    fun stop() {
        tickJob?.cancel()
        release()
        _isPlaying.value = false
        _currentUrl.value = null
        _position.value = 0L
        _duration.value = 0L
    }

    private fun release() {
        player?.release()
        player = null
    }
}
