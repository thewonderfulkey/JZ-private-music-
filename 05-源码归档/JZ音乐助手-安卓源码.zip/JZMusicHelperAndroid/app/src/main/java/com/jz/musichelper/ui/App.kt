package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.model.PlayMode
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.LyricsService
import com.jz.musichelper.network.SourcePicker
import com.jz.musichelper.network.UrlResolver
import com.jz.musichelper.ui.theme.AppBackground
import com.jz.musichelper.ui.theme.AppTheme
import com.jz.musichelper.ui.theme.AppThemeType
import com.jz.musichelper.ui.theme.LocalPalette
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ===== 全局导航与播放状态 =====
object AppState {
    val currentSong = mutableStateOf<Song?>(null)          // 正在播放页覆盖
    val lastSong = mutableStateOf<Song?>(null)             // MiniPlayer 显示（最近打开的歌曲）
    val playlist = mutableStateOf<List<Song>>(emptyList()) // 播放队列
    val playIndex = mutableStateOf(-1)
    val playMode = mutableStateOf(
        runCatching { PlayMode.valueOf(HistoryStore.loadPlayMode()) }.getOrDefault(PlayMode.LIST_LOOP)
    )
    val theme = mutableStateOf(HistoryStore.loadTheme())
    val tab = mutableStateOf(MainTab.HOME)                 // 底部 Tab（提升到全局：返回键需要感知）
    val searchActive = mutableStateOf(false)               // 首页是否处于搜索结果态（返回键用于清空结果）
    val lastPlayedKey = mutableStateOf("")                 // 最近一次已解析播放的歌曲 key（防退出播放页后重播）
    val resolvingSongKey = mutableStateOf<String?>(null)    // 正在后台解析取流的歌曲 key（全局，不随播放页销毁）
    val resolveError = mutableStateOf<Pair<String, String>?>(null)  // (songKey, 错误信息)：最近一次解析失败
    val deadSongKeys = mutableStateOf<Set<String>>(emptySet())      // 已确认无源的歌曲 key（搜索列表据此自动隐藏）
    private var consecutiveFailures = 0                    // 连续无源失败次数（自动跳过无源歌的上限控制）
    private const val AUTO_SKIP_MAX = 3                    // 无源时自动切歌最多连跳 3 首，避免空列表死循环
    private const val AUTO_SKIP_DELAY_MS = 600L            // 失败提示展示时长，再自动切下一首

    // 取流/播放任务跑在应用级作用域：回退退出播放页也不中断解析
    private val globalScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** 打开播放页（并立即后台取流，回退不中断）；queue 为空时沿用已有队列 */
    fun openSong(song: Song, queue: List<Song>? = null) {
        val q = queue ?: playlist.value
        if (q.isNotEmpty()) {
            val idx = q.indexOfFirst { it.platform == song.platform && it.platformID == song.platformID }
            playIndex.value = if (idx >= 0) idx else 0
            playlist.value = q
        }
        lastSong.value = song
        currentSong.value = song
        HistoryStore.recordSong(song)
        resolveAndPlayIfNeeded(song)
    }

    fun nextSong() {
        val q = playlist.value
        if (q.isEmpty()) return
        // 随机模式下手动切下一首也随机（不重复当前）；其余模式按顺序取模
        val idx = if (playMode.value == PlayMode.SHUFFLE && q.size > 1) {
            var r = playIndex.value
            while (r == playIndex.value) r = (0 until q.size).random()
            r
        } else {
            (playIndex.value + 1) % q.size
        }
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        // 只有播放页已打开时才同步 currentSong（避免悬浮条切歌弹出播放页）
        if (currentSong.value != null) currentSong.value = s
        resolveAndPlayIfNeeded(s)
    }

    fun prevSong() {
        val q = playlist.value
        if (q.isEmpty()) return
        val idx = (playIndex.value - 1 + q.size) % q.size
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        if (currentSong.value != null) currentSong.value = s
        resolveAndPlayIfNeeded(s)
    }

    /**
     * 全局取流任务：点击/切歌/自动连播统一入口。
     * 应用级协程 + 防重入；解析成功后播放，失败记录错误（播放页/悬浮条可展示）。
     */
    fun resolveAndPlayIfNeeded(song: Song) {
        val key = song.platform.name + song.platformID
        if (resolvingSongKey.value == key) return          // 同一首歌解析中，不重复发起
        if (lastPlayedKey.value == key && PlayerManager.currentUrl.value != null) return  // 已在播
        resolvingSongKey.value = key
        resolveError.value = null
        // 与取流并发的歌词预取：点击/切歌瞬间即开始请求歌词（4h 缓存 + in-flight 去重），
        // 播放页打开时直接读缓存，歌出声时歌词已就绪；失败静默，不影响取流
        globalScope.launch { runCatching { LyricsService.fetch(song) } }
        globalScope.launch {
            val q = HistoryStore.loadQuality()
            val r = runCatching { UrlResolver.resolveAll(song, q) }.getOrNull()
            val src = if (r != null) SourcePicker.pick(r.sources, q) else null
            if (src != null) {
                AppState.lastPlayedKey.value = key
                consecutiveFailures = 0
                PlayerManager.play(src.url)
            } else {
                // 接口正常返回但确无可用源（非网络异常）：记录为无源歌（搜索列表自动隐藏）。
                // 注意：deadSongKeys 使用带下划线 key（与 HomeScreen 过滤/associateBy 格式一致），
                // 而 resolvingSongKey/resolveError/lastPlayedKey 沿用无下划线 key，互不影响。
                if (r != null) deadSongKeys.value = deadSongKeys.value + "${song.platform.name}_${song.platformID}"
                AppState.resolveError.value = key to "暂无可用的播放源"
                consecutiveFailures += 1
                // 播放页打开时：先短暂展示失败提示，再自动切下一首（无源自动跳过，最多连跳 3 首）
                if (consecutiveFailures <= AUTO_SKIP_MAX && currentSong.value != null) {
                    globalScope.launch {
                        delay(AUTO_SKIP_DELAY_MS)
                        if (resolvingSongKey.value == null && resolveError.value?.first == key) {
                            nextSong()
                        }
                    }
                }
            }
            if (AppState.resolvingSongKey.value == key) AppState.resolvingSongKey.value = null
        }
    }

    fun changeTheme(name: String) {
        theme.value = name
        HistoryStore.saveTheme(name)
    }

    /** 循环/随机按钮点击：单曲循环 → 列表循环 → 随机 → 单曲循环 */
    fun cyclePlayMode() {
        val next = when (playMode.value) {
            PlayMode.SINGLE_LOOP -> PlayMode.LIST_LOOP
            PlayMode.LIST_LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.SINGLE_LOOP
        }
        playMode.value = next
        HistoryStore.savePlayMode(next.name)
    }

    /** 一首歌自然播完后的自动处理。返回 true 表示需要重播当前曲目（单曲循环） */
    fun onTrackCompleted(): Boolean {
        val q = playlist.value
        if (q.isEmpty()) return false
        when (playMode.value) {
            PlayMode.SINGLE_LOOP -> return true
            PlayMode.LIST_LOOP -> goto((playIndex.value + 1) % q.size)
            PlayMode.SHUFFLE -> {
                if (q.size <= 1) {
                    goto(0)
                } else {
                    var r = playIndex.value
                    while (r == playIndex.value) r = (0 until q.size).random()
                    goto(r)
                }
            }
        }
        return false
    }

    /** 切到指定索引：更新队列位置与 lastSong；播放页开着时同步刷新 currentSong（PlayerScreen 自动取流） */
    private fun goto(idx: Int) {
        val q = playlist.value
        if (q.isEmpty() || idx !in q.indices) return
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        if (currentSong.value != null) currentSong.value = s
    }
}

enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("首页", Icons.Filled.Home),
    FAVORITES("收藏", Icons.Filled.Favorite),
    DOWNLOADS("下载", Icons.Filled.Download),
    HISTORY("历史", Icons.Filled.History),
    SETTINGS("设置", Icons.Filled.Settings)
}

@Composable
fun App() {
    val themeName = AppState.theme.value
    val themeType = runCatching { AppThemeType.valueOf(themeName) }.getOrDefault(AppThemeType.NIGHTINGALE)
    AppTheme(themeType) {
        AppBackground {
            Box(modifier = Modifier.fillMaxSize()) {
                // MainScaffold 常驻：各 Tab（含搜索态/结果列表）状态不因播放页打开而丢失
                MainScaffold()
                val song = AppState.currentSong.value
                if (song != null) {
                    // 播放页全屏覆盖在 MainScaffold 之上
                    PlayerScreen(song = song, onBack = { AppState.currentSong.value = null })
                }
                ToastHost()

                // 播完自动连播（播放页开/关均生效）：单曲循环重播当前；列表/随机切歌统一走全局取流任务
                LaunchedEffect(Unit) {
                    var lastSeq = 0L
                    PlayerManager.completed.collect { seq ->
                        if (seq == lastSeq) return@collect
                        lastSeq = seq
                        if (AppState.onTrackCompleted()) {
                            val url = PlayerManager.currentUrl.value
                            if (url != null) PlayerManager.play(url)
                        } else {
                            val s = AppState.lastSong.value ?: return@collect
                            AppState.resolveAndPlayIfNeeded(s)
                        }
                    }
                }

                // 返回键层级：播放页→主界面；搜索结果态→清空回首页初始；非首页 Tab→回首页；否则系统默认退出
                val canBack = song != null || AppState.searchActive.value || AppState.tab.value != MainTab.HOME
                androidx.activity.compose.BackHandler(enabled = canBack) {
                    when {
                        song != null -> AppState.currentSong.value = null
                        AppState.searchActive.value -> AppState.searchActive.value = false
                        AppState.tab.value != MainTab.HOME -> AppState.tab.value = MainTab.HOME
                    }
                }
            }
        }
    }
}

@Composable
private fun MainScaffold() {
    // safeDrawingPadding：顶出状态栏/底出系统手势条，避免底部导航被系统导航条区域吞掉点击
    Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
        Box(modifier = Modifier.weight(1f)) {
            when (AppState.tab.value) {
                MainTab.HOME -> HomeScreen()
                MainTab.FAVORITES -> FavoritesScreen()
                MainTab.DOWNLOADS -> DownloadsScreen()
                MainTab.HISTORY -> HistoryScreen()
                MainTab.SETTINGS -> SettingsScreen()
            }
        }
        MiniPlayer()
        BottomNav(tab = AppState.tab.value, onSelect = { AppState.tab.value = it })
    }
}

// ===== 底部导航 =====
@Composable
private fun BottomNav(tab: MainTab, onSelect: (MainTab) -> Unit) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(p.surface)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        MainTab.entries.forEach { t ->
            val selected = tab == t
            val color = if (selected) p.accent else p.text3
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    // key=t：每个 Tab 独立 interactionSource，避免 forEach 循环中共享实例导致点击状态互相干扰
                    .clickable(interactionSource = remember(t) { MutableInteractionSource() }, indication = null) { onSelect(t) }
                    .padding(vertical = 4.dp)
            ) {
                Icon(t.icon, contentDescription = t.label, tint = color, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(t.label, fontSize = 10.sp, color = color)
            }
        }
    }
}

// ===== 底部播放条（MiniPlayer）：封面+歌名 | 收藏 | 上一首 | 播放/暂停 | 下一首 =====
@Composable
private fun MiniPlayer() {
    val p = LocalPalette.current
    val song = AppState.lastSong.value ?: return
    val playingUrl by PlayerManager.currentUrl.collectAsState()
    val isPlaying by PlayerManager.isPlaying.collectAsState()
    val playing = playingUrl != null && isPlaying
    val scope = rememberCoroutineScope()
    // 收藏状态（切歌时按歌重算）
    var fav by remember(song.platform, song.platformID) { mutableStateOf(HistoryStore.isFavorite(song)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(p.surface.copy(alpha = 0.96f))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 封面 + 歌名（点击回播放页）
        Row(
            modifier = Modifier
                .weight(1f)
                .clickable { AppState.openSong(song) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongCover(song = song, size = 40.dp, corner = 10.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(song.name, color = p.text, fontSize = 14.sp, maxLines = 1)
                Text(song.singer + " · " + song.platform.shortName, color = p.text3, fontSize = 11.sp, maxLines = 1)
            }
        }
        // 收藏（紧邻上一首的左边）
        Box(
            modifier = Modifier
                .size(40.dp)
                .clickable { fav = HistoryStore.toggleFavorite(song) },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (fav) "取消收藏" else "收藏",
                tint = if (fav) Color(0xFFE5484D) else p.text3,
                modifier = Modifier.size(24.dp)
            )
        }
        // 上一首（暂停左边）：直调切歌（内部仅在播放页已打开时同步 currentSong，悬浮条保持不跳页）
        Box(
            modifier = Modifier.size(40.dp).clickable { AppState.prevSong() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.SkipPrevious, contentDescription = "上一首", tint = p.text2, modifier = Modifier.size(22.dp))
        }
        // 播放 / 暂停
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(p.surface2)
                .clickable {
                    // 已有播放源：点击仅切换 播放/暂停，绝不跳进播放页；无源时才进入播放页取流
                    if (PlayerManager.currentUrl.value != null) PlayerManager.toggle()
                    else AppState.openSong(song)
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = p.text,
                modifier = Modifier.size(22.dp)
            )
        }
        // 下一首：直调切歌（不跳播放页，后台解析自动播）
        Box(
            modifier = Modifier.size(40.dp).clickable { AppState.nextSong() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.SkipNext, contentDescription = "下一首", tint = p.text2, modifier = Modifier.size(22.dp))
        }
    }
}

// ===== 封面（Coil 加载真实封面，失败/无图回退主题色块）=====
@Composable
fun SongCover(song: Song, size: androidx.compose.ui.unit.Dp, corner: androidx.compose.ui.unit.Dp) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(coverFallback(song, p.accent))
    ) {
        val url = song.picUrl
        if (!url.isNullOrBlank()) {
            androidx.compose.foundation.Image(
                painter = coil.compose.rememberAsyncImagePainter(url),
                contentDescription = song.name,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                Icons.Filled.MusicNote,
                contentDescription = null,
                tint = p.accent2.copy(alpha = 0.85f),
                modifier = Modifier
                    .fillMaxSize()
                    .padding((size.value / 4).dp)
            )
        }
    }
}

/** 无封面时按平台给个区分色，避免千篇一律 */
private fun coverFallback(song: Song, accent: Color): Color = when (song.platform) {
    com.jz.musichelper.model.MusicPlatform.KUWO -> Color(0xFF3A2F52)
    com.jz.musichelper.model.MusicPlatform.QQ -> Color(0xFF1E3A52)
    com.jz.musichelper.model.MusicPlatform.NETEASE -> Color(0xFF4A2A32)
    com.jz.musichelper.model.MusicPlatform.KUGOU -> Color(0xFF2E4A2E)
}
