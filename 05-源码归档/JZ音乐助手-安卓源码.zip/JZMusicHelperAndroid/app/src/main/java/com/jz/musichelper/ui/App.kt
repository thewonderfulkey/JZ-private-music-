package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.model.PlayMode
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.CoverResolver
import com.jz.musichelper.network.LyricsService
import com.jz.musichelper.network.SourcePicker
import com.jz.musichelper.network.UrlResolver
import com.jz.musichelper.ui.theme.AppBackground
import com.jz.musichelper.ui.theme.AppTheme
import com.jz.musichelper.ui.theme.AppThemeType
import com.jz.musichelper.ui.theme.LocalPalette
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ===== 全局导航与播放状态 =====
object AppState {
    val currentSong = mutableStateOf<Song?>(null)          // 正在播放页覆盖
    val lastSong = mutableStateOf<Song?>(null)             // MiniPlayer 显示（最近打开的歌曲）
    val playlist = mutableStateOf<List<Song>>(emptyList()) // 播放队列
    val playIndex = mutableStateOf(-1)
    val playMode = mutableStateOf(
        runCatching { PlayMode.valueOf(HistoryStore.loadPlayMode()) }.getOrDefault(PlayMode.LIST_LOOP)
    )
    val theme = mutableStateOf(HistoryStore.loadTheme())
    val tab = mutableStateOf(MainTab.HOME)                 // 底部 Tab（提升到全局：返回键需要感知）
    val searchActive = mutableStateOf(false)               // 首页是否处于搜索结果态（返回键用于清空结果）
    val openPlaylist = mutableStateOf<EditorPlaylist?>(null) // 编辑精选歌单页覆盖（本地内置歌曲，点单曲才搜索）
    val lastPlayedKey = mutableStateOf("")                 // 最近一次已解析播放的歌曲 key（防退出播放页后重播）
    val resolvingSongKey = mutableStateOf<String?>(null)    // 正在后台解析取流的歌曲 key（全局，不随播放页销毁）
    val resolveError = mutableStateOf<Pair<String, String>?>(null)  // (songKey, 错误信息)：最近一次解析失败
    val deadSongKeys = mutableStateOf<Set<String>>(emptySet())      // 已确认无源的歌曲 key（搜索列表据此自动隐藏）
    private var consecutiveFailures = 0                    // 连续无源失败次数（自动跳过无源歌的上限控制）
    private const val AUTO_SKIP_MAX = 3                    // 无源时自动切歌最多连跳 3 首，避免空列表死循环
    private const val AUTO_SKIP_DELAY_MS = 600L            // 失败提示展示时长，再自动切下一首

    // 取流/播放任务跑在应用级作用域：回退退出播放页也不中断解析
    private val globalScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** 打开播放页（并立即后台取流，回退不中断）；queue 为空时沿用已有队列 */
    fun openSong(song: Song, queue: List<Song>? = null) {
        val q = queue ?: playlist.value
        if (q.isNotEmpty()) {
            val idx = q.indexOfFirst { it.platform == song.platform && it.platformID == song.platformID }
            playIndex.value = if (idx >= 0) idx else 0
            playlist.value = q
        }
        lastSong.value = song
        currentSong.value = song
        HistoryStore.recordSong(song)
        resolveAndPlayIfNeeded(song)
    }

    /** 歌单顺序队列替换（编辑精选点歌后后台补齐）：保持当前播放下标对齐，列表循环严格按队列顺序切歌 */
    fun replaceQueue(queue: List<Song>, playIndex: Int) {
        if (queue.isEmpty()) return
        playlist.value = queue
        this.playIndex.value = playIndex.coerceIn(0, queue.size - 1)
    }

    fun nextSong() {
        val q = playlist.value
        if (q.isEmpty()) return
        // 随机模式下手动切下一首也随机（不重复当前）；其余模式按顺序取模
        val idx = if (playMode.value == PlayMode.SHUFFLE && q.size > 1) {
            var r = playIndex.value
            while (r == playIndex.value) r = (0 until q.size).random()
            r
        } else {
            (playIndex.value + 1) % q.size
        }
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        // 只有播放页已打开时才同步 currentSong（避免悬浮条切歌弹出播放页）
        if (currentSong.value != null) currentSong.value = s
        resolveAndPlayIfNeeded(s)
    }

    fun prevSong() {
        val q = playlist.value
        if (q.isEmpty()) return
        val idx = (playIndex.value - 1 + q.size) % q.size
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        if (currentSong.value != null) currentSong.value = s
        resolveAndPlayIfNeeded(s)
    }

    /**
     * 全局取流任务：点击/切歌/自动连播统一入口。
     * 应用级协程 + 防重入；解析成功后播放，失败记录错误（播放页/悬浮条可展示）。
     */
    fun resolveAndPlayIfNeeded(song: Song) {
        val key = song.platform.name + song.platformID
        if (resolvingSongKey.value == key) return          // 同一首歌解析中，不重复发起
        if (lastPlayedKey.value == key && PlayerManager.currentUrl.value != null) return  // 已在播
        resolvingSongKey.value = key
        resolveError.value = null
        // 与取流并发的歌词预取：点击/切歌瞬间即开始请求歌词（4h 缓存 + in-flight 去重），
        // 播放页打开时直接读缓存，歌出声时歌词已就绪；失败静默，不影响取流
        globalScope.launch { runCatching { LyricsService.fetch(song) } }
        globalScope.launch {
            val q = HistoryStore.loadQuality()
            val r = runCatching { UrlResolver.resolveAll(song, q) }.getOrNull()
            val src = if (r != null) SourcePicker.pick(r.sources, q) else null
            if (src != null) {
                AppState.lastPlayedKey.value = key
                consecutiveFailures = 0
                PlayerManager.play(src.url)
            } else {
                // 接口正常返回但确无可用源（非网络异常）：记录为无源歌（搜索列表自动隐藏）。
                // 注意：deadSongKeys 使用带下划线 key（与 HomeScreen 过滤/associateBy 格式一致），
                // 而 resolvingSongKey/resolveError/lastPlayedKey 沿用无下划线 key，互不影响。
                if (r != null) deadSongKeys.value = deadSongKeys.value + "${song.platform.name}_${song.platformID}"
                AppState.resolveError.value = key to "暂无可用的播放源"
                consecutiveFailures += 1
                // 播放页打开时：先短暂展示失败提示，再自动切下一首（无源自动跳过，最多连跳 3 首）
                if (consecutiveFailures <= AUTO_SKIP_MAX && currentSong.value != null) {
                    globalScope.launch {
                        delay(AUTO_SKIP_DELAY_MS)
                        if (resolvingSongKey.value == null && resolveError.value?.first == key) {
                            nextSong()
                        }
                    }
                }
            }
            if (AppState.resolvingSongKey.value == key) AppState.resolvingSongKey.value = null
        }
    }

    fun changeTheme(name: String) {
        theme.value = name
        HistoryStore.saveTheme(name)
    }

    /** 循环/随机按钮点击：单曲循环 → 列表循环 → 随机 → 单曲循环 */
    fun cyclePlayMode() {
        val next = when (playMode.value) {
            PlayMode.SINGLE_LOOP -> PlayMode.LIST_LOOP
            PlayMode.LIST_LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.SINGLE_LOOP
        }
        playMode.value = next
        HistoryStore.savePlayMode(next.name)
    }

    /** 一首歌自然播完后的自动处理。返回 true 表示需要重播当前曲目（单曲循环） */
    fun onTrackCompleted(): Boolean {
        val q = playlist.value
        if (q.isEmpty()) return false
        when (playMode.value) {
            PlayMode.SINGLE_LOOP -> return true
            PlayMode.LIST_LOOP -> goto((playIndex.value + 1) % q.size)
            PlayMode.SHUFFLE -> {
                if (q.size <= 1) {
                    goto(0)
                } else {
                    var r = playIndex.value
                    while (r == playIndex.value) r = (0 until q.size).random()
                    goto(r)
                }
            }
        }
        return false
    }

    /** 切到指定索引：更新队列位置与 lastSong；播放页开着时同步刷新 currentSong（PlayerScreen 自动取流） */
    private fun goto(idx: Int) {
        val q = playlist.value
        if (q.isEmpty() || idx !in q.indices) return
        playIndex.value = idx
        val s = q[idx]
        lastSong.value = s
        if (currentSong.value != null) currentSong.value = s
    }
}

enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("首页", Icons.Filled.Home),
    FAVORITES("收藏", Icons.Filled.Favorite),
    DOWNLOADS("下载", Icons.Filled.Download),
    HISTORY("历史", Icons.Filled.History),
    SETTINGS("设置", Icons.Filled.Settings)
}

@Composable
fun App() {
    val themeName = AppState.theme.value
    val themeType = runCatching { AppThemeType.valueOf(themeName) }.getOrDefault(AppThemeType.NIGHTINGALE)
    AppTheme(themeType) {
        AppBackground {
            Box(modifier = Modifier.fillMaxSize()) {
                // MainScaffold 常驻：各 Tab（含搜索态/结果列表）状态不因播放页打开而丢失
                MainScaffold()
                val pl = AppState.openPlaylist.value
                if (pl != null) {
                    PlaylistScreen(pl = pl, onBack = { AppState.openPlaylist.value = null })
                }
                // 悬浮播放条：绘制在歌单页覆盖层之上（编辑精选点歌后常驻可见）、播放页之下（播放页全屏让位）
                MiniPlayer(modifier = Modifier.align(Alignment.BottomCenter))
                val song = AppState.currentSong.value
                if (song != null) {
                    // 播放页全屏覆盖在 MainScaffold 之上
                    PlayerScreen(song = song, onBack = { AppState.currentSong.value = null })
                }
                ToastHost()

                // 播完自动连播（播放页开/关均生效）：单曲循环重播当前；列表/随机切歌统一走全局取流任务
                LaunchedEffect(Unit) {
                    var lastSeq = 0L
                    PlayerManager.completed.collect { seq ->
                        if (seq == lastSeq) return@collect
                        lastSeq = seq
                        if (AppState.onTrackCompleted()) {
                            val url = PlayerManager.currentUrl.value
                            if (url != null) PlayerManager.play(url)
                        } else {
                            val s = AppState.lastSong.value ?: return@collect
                            AppState.resolveAndPlayIfNeeded(s)
                        }
                    }
                }

                // 返回键层级：播放页→歌单页→主界面；搜索结果态→清空回首页初始；非首页 Tab→回首页；否则系统默认退出
                val canBack = song != null || AppState.openPlaylist.value != null || AppState.searchActive.value || AppState.tab.value != MainTab.HOME
                androidx.activity.compose.BackHandler(enabled = canBack) {
                    when {
                        song != null -> AppState.currentSong.value = null
                        AppState.openPlaylist.value != null -> AppState.openPlaylist.value = null
                        AppState.searchActive.value -> AppState.searchActive.value = false
                        AppState.tab.value != MainTab.HOME -> AppState.tab.value = MainTab.HOME
                    }
                }
            }
        }
    }
}

@Composable
private fun MainScaffold() {
    // safeDrawingPadding：顶出状态栏/底出系统手势条，避免底部导航被系统导航条区域吞掉点击
    Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
        Box(modifier = Modifier.weight(1f)) {
            when (AppState.tab.value) {
                MainTab.HOME -> HomeScreen()
                MainTab.FAVORITES -> FavoritesScreen()
                MainTab.DOWNLOADS -> DownloadsScreen()
                MainTab.HISTORY -> HistoryScreen()
                MainTab.SETTINGS -> SettingsScreen()
            }
        }
        BottomNav(tab = AppState.tab.value, onSelect = { AppState.tab.value = it })
    }
}

// ===== 底部导航 =====
@Composable
private fun BottomNav(tab: MainTab, onSelect: (MainTab) -> Unit) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(p.surface)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        MainTab.entries.forEach { t ->
            val selected = tab == t
            val color = if (selected) p.accent else p.text3
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    // key=t：每个 Tab 独立 interactionSource，避免 forEach 循环中共享实例导致点击状态互相干扰
                    .clickable(interactionSource = remember(t) { MutableInteractionSource() }, indication = null) { onSelect(t) }
                    .padding(vertical = 4.dp)
            ) {
                Icon(t.icon, contentDescription = t.label, tint = color, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(t.label, fontSize = 10.sp, color = color)
            }
        }
    }
}

// ===== 底部播放条（MiniPlayer）：封面+歌名 | 收藏 | 上一首 | 播放/暂停 | 下一首 =====
@Composable
private fun MiniPlayer(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val song = AppState.lastSong.value ?: return
    val playingUrl by PlayerManager.currentUrl.collectAsState()
    val isPlaying by PlayerManager.isPlaying.collectAsState()
    val playing = playingUrl != null && isPlaying
    val scope = rememberCoroutineScope()
    // 收藏状态（切歌时按歌重算）
    var fav by remember(song.platform, song.platformID) { mutableStateOf(HistoryStore.isFavorite(song)) }
    // 底部抬升：首页等带底部导航的页面为底部导航让位（62dp）；歌单页无底部栏时贴底渲染（② 修复：背景已铺满，悬浮条不再悬空透底）
    val bottomPad = if (AppState.openPlaylist.value != null) 0.dp else 62.dp

    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(horizontal = 10.dp)
            .padding(bottom = bottomPad)
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(p.surface.copy(alpha = 0.97f))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 封面 + 歌名（点击回播放页）
        Row(
            modifier = Modifier
                .weight(1f)
                .clickable { AppState.openSong(song) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongCover(song = song, size = 40.dp, corner = 10.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(song.name, color = p.text, fontSize = 14.sp, maxLines = 1)
                Text(song.singer + " · " + song.platform.shortName, color = p.text3, fontSize = 11.sp, maxLines = 1)
            }
        }
        // 收藏（紧邻上一首的左边）
        Box(
            modifier = Modifier
                .size(40.dp)
                .clickable { fav = HistoryStore.toggleFavorite(song) },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (fav) "取消收藏" else "收藏",
                tint = if (fav) Color(0xFFE5484D) else p.text3,
                modifier = Modifier.size(24.dp)
            )
        }
        // 上一首（暂停左边）：直调切歌（内部仅在播放页已打开时同步 currentSong，悬浮条保持不跳页）
        Box(
            modifier = Modifier.size(40.dp).clickable { AppState.prevSong() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.SkipPrevious, contentDescription = "上一首", tint = p.text2, modifier = Modifier.size(22.dp))
        }
        // 播放 / 暂停
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(p.surface2)
                .clickable {
                    // 已有播放源：点击仅切换 播放/暂停，绝不跳进播放页；无源时才进入播放页取流
                    if (PlayerManager.currentUrl.value != null) PlayerManager.toggle()
                    else AppState.openSong(song)
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = p.text,
                modifier = Modifier.size(22.dp)
            )
        }
        // 下一首：直调切歌（不跳播放页，后台解析自动播）
        Box(
            modifier = Modifier.size(40.dp).clickable { AppState.nextSong() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.SkipNext, contentDescription = "下一首", tint = p.text2, modifier = Modifier.size(22.dp))
        }
    }
}

// ===== 封面：Coil 加载真实封面；无封面先落「平台渐变+歌名首字+音符」本地占位（离线可用），
//      同时异步走 QQ 同歌名+歌手复用兜底（命中后直接换真图，不做闪烁动画）=====
@Composable
fun SongCover(song: Song, size: androidx.compose.ui.unit.Dp, corner: androidx.compose.ui.unit.Dp) {
    Box(modifier = Modifier.size(size).clip(RoundedCornerShape(corner))) {
        SongCoverContent(song = song)
    }
}

/** 宽度自适应的方形封面（热门音乐双列网格用）；调用方需保证外层宽度确定 */
@Composable
fun SongCoverBox(song: Song, corner: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(corner))) {
        SongCoverContent(song = song)
    }
}

@Composable
private fun SongCoverContent(song: Song) {
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    CoverResolver.ensureInit(ctx)
    // 2.0.1：酷狗旧版 imgessl album_id 路径判死——CDN 已软失败为固定黑胶（HTTP 200），初始即弃用，直接走 QQ 兜底换真封面
    val legacyDeadPic = song.platform == com.jz.musichelper.model.MusicPlatform.KUGOU &&
        song.picUrl?.contains("imgessl", ignoreCase = true) == true
    var pic by remember(song.platform.name + song.platformID) { mutableStateOf(if (legacyDeadPic) null else song.picUrl) }
    // ④ 修复：原封面 URL 加载失败/挂起时，强制走 QQ 同歌名+歌手复用兜底（换真图，最多触发一次）
    var fallbackPic by remember(song.platform.name + song.platformID) { mutableStateOf<String?>(null) }
    var fallbackTried by remember(song.platform.name + song.platformID) { mutableStateOf(false) }
    var loadedOk by remember(song.platform.name + song.platformID) { mutableStateOf(false) }
    // 统一兜底入口：error 与挂起超时共用；兜底失败自动重试 1 次（网络抖动/偶发超时自愈）
    val triggerFallback = {
        if (!fallbackTried) {
            fallbackTried = true
            scope.launch {
                fallbackPic = CoverResolver.resolveForce(song)
                if (fallbackPic.isNullOrBlank()) {
                    kotlinx.coroutines.delay(800)
                    fallbackPic = CoverResolver.resolveForce(song)
                }
            }
        }
    }
    LaunchedEffect(song.platform.name + song.platformID, song.name, song.singer) {
        if (pic.isNullOrBlank()) {
            pic = CoverResolver.resolve(song)
            // ④ 修复：兜底失败自动重试 1 次（网络抖动/偶发超时自愈），仍失败才落本地占位
            if (pic.isNullOrBlank()) {
                kotlinx.coroutines.delay(800)
                pic = CoverResolver.resolve(song)
            }
        }
    }
    // ④ 修复：原 URL 加载挂起（Coil 既不成功也不报错）→ 4s 后强制触发 QQ 兜底换真图
    LaunchedEffect(song.platform.name + song.platformID, song.name, song.singer) {
        kotlinx.coroutines.delay(4000)
        if (!loadedOk && !fallbackTried) triggerFallback()
    }
    // ④ 修复：兜底真封面优先显示——原 URL 是失效/挂起 URL 时，兜底结果才能真正替换显示
    val url = fallbackPic ?: pic
    if (!url.isNullOrBlank()) {
        // 2.0.2：allowHardware(false) 强制软件位图——Coil 默认硬件位图上 Bitmap.getPixel() 抛异常，
        // 导致黑胶检测被 catch 吞掉返回 false、酷狗软失败黑胶（union_cover 也是黑胶图）直接显示；改为软件位图后检测恢复
        val request = coil.request.ImageRequest.Builder(ctx).data(url).allowHardware(false).build()
        coil.compose.SubcomposeAsyncImage(
            model = request,
            contentDescription = song.name,
            modifier = Modifier.fillMaxSize(),
            loading = { CoverPlaceholder(song) },
            error = {
                triggerFallback()
                CoverPlaceholder(song)
            },
            success = { state ->
                // 2.0.0：识别酷狗软失败的黑胶默认图 → 触发 QQ 兜底（期间显示本地占位）；真封面才标记成功
                val bmp = runCatching { state.result.drawable.toBitmap() }.getOrNull()
                if (bmp != null && VinylDetector.isVinyl(bmp)) {
                    triggerFallback()
                    CoverPlaceholder(song)
                } else {
                    loadedOk = true
                    androidx.compose.foundation.Image(state.painter, contentDescription = song.name, modifier = Modifier.fillMaxSize())
                }
            }
        )
    } else {
        CoverPlaceholder(song)
    }
}

/**
 * 黑胶默认图识别（2.0.0，2.0.1 增强为区域均值版）。酷狗 CDN 对无封面/失效路径不返回 404，而是 HTTP 200 + 固定黑胶图（软失败），
 * Coil 会当成功。这里按像素特征确定性识别：四角区域均值浅色 + 黑色圆盘 + 蓝色圆心，命中即判软失败、走 QQ 兜底。
 * 2.0.1 增强：背景改 5×5 区域均值（抗单点噪声/JPEG 噪点）、圆心改 3×3 邻域计数（抗圆心位置偏移），
 * 已用 12 张已知图回归验证（5 黑胶均命中、7 真封面均不误伤）。
 */
private object VinylDetector {
    private fun px(b: android.graphics.Bitmap, fx: Float, fy: Float): Int =
        b.getPixel((fx * (b.width - 1)).toInt().coerceIn(0, b.width - 1),
                   (fy * (b.height - 1)).toInt().coerceIn(0, b.height - 1))
    private fun lum(c: Int): Double =
        0.299 * android.graphics.Color.red(c) + 0.587 * android.graphics.Color.green(c) +
        0.114 * android.graphics.Color.blue(c)
    private fun isLight(c: Int): Boolean = lum(c) > 190
    private fun isDark(c: Int): Boolean = lum(c) < 70
    private fun isBlue(c: Int): Boolean {
        val r = android.graphics.Color.red(c); val g = android.graphics.Color.green(c)
        val bl = android.graphics.Color.blue(c)
        return bl > 110 && bl - r > 40 && bl - g > 15
    }
    fun isVinyl(b: android.graphics.Bitmap): Boolean = try {
        // 背景：四角 5×5 区域均值亮度，≥3 角浅(>185)
        fun regionLum(fx0: Float, fy0: Float, fx1: Float, fy1: Float): Double {
            var r = 0.0; var g = 0.0; var bl = 0.0
            for (i in 0..4) for (j in 0..4) {
                val c = px(b, fx0 + (fx1 - fx0) * i / 4f, fy0 + (fy1 - fy0) * j / 4f)
                r += android.graphics.Color.red(c); g += android.graphics.Color.green(c); bl += android.graphics.Color.blue(c)
            }
            return 0.299 * r / 25.0 + 0.587 * g / 25.0 + 0.114 * bl / 25.0
        }
        val corners = listOf(
            regionLum(.03f, .03f, .10f, .10f), regionLum(.90f, .03f, .97f, .10f),
            regionLum(.03f, .90f, .10f, .97f), regionLum(.90f, .90f, .97f, .97f)
        )
        if (corners.count { it > 185 } < 3) false
        else {
            val disk = listOf(px(b, .5f, .30f), px(b, .30f, .5f), px(b, .70f, .5f), px(b, .5f, .70f))
            if (disk.count { isDark(it) } < 3) false
            else {
                var blueN = 0
                for (i in 0..2) for (j in 0..2)
                    if (isBlue(px(b, .44f + .06f * i, .44f + .06f * j))) blueN++
                blueN >= 6
            }
        }
    } catch (_: Exception) { false }
}

/** 本地占位：平台色渐变 + 歌名首字大字 + 音符小标（无网络也可用） */
@Composable
private fun CoverPlaceholder(song: Song) {
    val (c1, c2) = coverGradient(song)
    Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c1, c2)))) {
        val initial = song.name.trim().take(1).ifEmpty { "♪" }
        Text(
            text = initial,
            color = Color.White.copy(alpha = 0.92f),
            fontSize = 28.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.align(Alignment.Center)
        )
        Icon(
            Icons.Filled.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.35f),
            modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).size(18.dp)
        )
    }
}

/** 平台区分色对（垂直渐变），避免千篇一律 */
private fun coverGradient(song: Song): Pair<Color, Color> = when (song.platform) {
    com.jz.musichelper.model.MusicPlatform.KUWO -> Color(0xFF3A2F52) to Color(0xFF6C4FA0)
    com.jz.musichelper.model.MusicPlatform.QQ -> Color(0xFF1E3A52) to Color(0xFF2E6EA6)
    com.jz.musichelper.model.MusicPlatform.NETEASE -> Color(0xFF4A2A32) to Color(0xFF8C2B3A)
    com.jz.musichelper.model.MusicPlatform.KUGOU -> Color(0xFF2E4A2E) to Color(0xFF4A8A4A)
}
