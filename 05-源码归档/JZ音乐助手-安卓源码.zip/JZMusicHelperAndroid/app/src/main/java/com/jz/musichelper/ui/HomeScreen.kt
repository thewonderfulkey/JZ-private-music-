package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.SearchRanker
import com.jz.musichelper.network.SearchService
import com.jz.musichelper.ui.theme.LocalPalette
import kotlinx.coroutines.launch

// ===== 首页：发现音乐（搜索 + 大家都在听 + 分组结果 + 收藏）=====
@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    var keyword by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<SearchService.PlatformResult>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val kb = LocalSoftwareKeyboardController.current
    val searched by AppState.searchActive

    // 已确认无源的歌曲（点击解析失败后由 AppState 自动记录）从搜索结果隐藏；其余歌曲立即可点、零等待
    val dead = AppState.deadSongKeys.value
    val effResults = remember(results, dead) {
        results.map { pr -> pr.copy(songs = pr.songs.filterNot { "${it.platform.name}_${it.platformID}" in dead }) }
    }
    // 方案一：去掉平台分组，全平台合并按匹配度（歌名/歌手/专辑多维打分）全局排序，平铺展示
    val flatRanked = remember(effResults, keyword) {
        SearchRanker.rank(keyword, effResults.flatMap { it.songs })
    }

    Column(modifier = modifier.fillMaxSize()) {
        // 标题行（搜索结果态显示返回按钮）
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searched) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable {
                            AppState.searchActive.value = false
                            keyword = ""
                            results = emptyList()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "返回",
                        tint = p.text2,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Text(
                "发现音乐",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = p.text,
                modifier = Modifier.padding(start = if (searched) 2.dp else 10.dp, top = 6.dp)
            )
        }

        // 搜索逻辑统一入口
        val doSearch: (String) -> Unit = { raw ->
            val k = raw.trim()
            if (k.isNotEmpty()) {
                keyword = k
                AppState.searchActive.value = true
                isSearching = true
                kb?.hide()   // 搜索后自动收起键盘：避免键盘顶起底部导航挡住 Tab 点击
                HistoryStore.recordSearch(k)
                scope.launch {
                    try {
                        results = SearchService.searchAll(k, 50)
                    } catch (e: Exception) {
                        results = emptyList()
                    } finally {
                        isSearching = false
                    }
                }
            }
        }

        // 搜索栏
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .background(p.surface2, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = p.text3, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                androidx.compose.foundation.text.BasicTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    textStyle = androidx.compose.ui.text.TextStyle(color = p.text, fontSize = 15.sp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { doSearch(keyword) })
                ) { inner ->
                    if (keyword.isEmpty()) {
                        Text("搜索歌曲，如：晴天 周杰伦", color = p.text3, fontSize = 14.sp)
                    }
                    inner()
                }
                if (keyword.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            // 叉号=清空全部：输入框 + 搜索结果 + 退出搜索态（回首页初始）
                            keyword = ""
                            results = emptyList()
                            AppState.searchActive.value = false
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "清空", tint = p.text3, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .background(p.accent, RoundedCornerShape(12.dp))
                    .clickable { doSearch(keyword) }
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                if (isSearching) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF101410), strokeWidth = 2.dp)
                } else {
                    Text("搜索", color = Color(0xFF101410), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // 平台状态行（搜索后显示）
        if (searched) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                MusicPlatform.entries.forEach { pl ->
                    val pr = effResults.firstOrNull { it.platform == pl }
                    val color = when {
                        isSearching -> p.accent2
                        pr == null -> p.text3.copy(alpha = 0.5f)
                        pr.songs.isNotEmpty() -> p.accent
                        pr.error != null -> Color(0xFFE5484D)
                        else -> p.text3
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(color, CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text(pl.shortName, fontSize = 12.sp, color = p.text2)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("4 平台并发", fontSize = 11.sp, color = p.text3)
            }
        }

        // 内容区
        when {
            isSearching -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = p.accent)
            }

            searched && effResults.all { it.songs.isEmpty() } -> EmptyHint("没有找到结果", "换个关键词试试")

            searched -> {
                // 平铺：全平台合并、按匹配度排序（每条自带平台标签），无平台分组标题
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(flatRanked, key = { "${it.platform.name}_${it.platformID}" }) { song ->
                        DarkSongRow(song, queue = flatRanked)
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }

            else -> HomeRecommend(onSearch = doSearch)
        }
    }
}

// ===== 未搜索时：大家都在听 + 引导 =====
@Composable
private fun HomeRecommend(onSearch: (String) -> Unit) {
    val p = LocalPalette.current
    val favs = HistoryStore.loadFavorites()
    val recents = HistoryStore.loadRecentSongs()
    val cards = (favs + recents).distinctBy { "${it.platform.name}_${it.platformID}" }.take(8)

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        if (cards.isEmpty()) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 90.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(56.dp), tint = p.text3.copy(alpha = 0.5f))
                    Spacer(Modifier.height(12.dp))
                    Text("输入关键词搜索歌曲", color = p.text2, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("支持 QQ / 网易 / 酷我 / 酷狗 四平台", color = p.text3, fontSize = 12.sp)
                }
            }
            return@LazyColumn
        }
        item {
            Text(
                "大家都在听",
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = p.text,
                modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 10.dp)
            )
        }
        item {
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cards, key = { "${it.platform.name}_${it.platformID}" }) { song ->
                    Column(modifier = Modifier.clickable {
                        val r = runCatching { AppState.openSong(song, cards) }
                        if (r.isFailure) toast("打开失败：" + (r.exceptionOrNull()?.message ?: "未知异常"))
                    }) {
                        SongCover(song = song, size = 126.dp, corner = 14.dp)
                        Spacer(Modifier.height(6.dp))
                        Text(song.name, color = p.text, fontSize = 13.sp, maxLines = 1, modifier = Modifier.width(126.dp))
                        Text(song.singer, color = p.text3, fontSize = 11.sp, maxLines = 1, modifier = Modifier.width(126.dp))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
        item {
            Text(
                "搜索历史",
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = p.text,
                modifier = Modifier.padding(start = 18.dp, bottom = 6.dp)
            )
        }
        val his = HistoryStore.loadSearchHistory()
        if (his.isEmpty()) {
            item {
                Text("暂无搜索历史", color = p.text3, fontSize = 12.sp, modifier = Modifier.padding(start = 18.dp))
            }
        } else {
            items(his, key = { it.keyword }) { h ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSearch(h.keyword) }
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = p.text3, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(h.keyword, color = p.text2, fontSize = 14.sp)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ===== 深色歌曲行：封面 + 歌名/歌手 + 平台 + 时长 + 收藏爱心 =====
@Composable
fun DarkSongRow(
    song: Song,
    queue: List<Song>? = null,
    showPlatform: Boolean = true,
    showDuration: Boolean = true
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                // 打开播放页；若内部异常则 toast 显示原因（诊断），不静默失败
                val r = runCatching { AppState.openSong(song, queue) }
                if (r.isFailure) toast("打开失败：" + (r.exceptionOrNull()?.message ?: "未知异常"))
            }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongCover(song = song, size = 48.dp, corner = 8.dp)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(song.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(
                song.singer + (if (song.album.isNotBlank()) " · " + song.album else ""),
                color = p.text3,
                fontSize = 12.sp,
                maxLines = 1
            )
        }
        if (showDuration) {
            Text(song.durationText, color = p.text3, fontSize = 11.sp)
            Spacer(Modifier.width(8.dp))
        }
        FavoriteBtn(song = song)
        if (showPlatform) {
            Spacer(Modifier.width(8.dp))
            Text(
                song.platform.shortName,
                color = p.accent2,
                fontSize = 10.sp,
                modifier = Modifier
                    .background(p.accent.copy(alpha = 0.14f), RoundedCornerShape(50))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

// ===== 收藏爱心按钮（实心=已收藏，点击切换带动画）=====
@Composable
fun FavoriteBtn(song: Song, size: androidx.compose.ui.unit.Dp = 24.dp) {
    val p = LocalPalette.current
    var fav by remember { mutableStateOf(HistoryStore.isFavorite(song)) }
    Box(
        modifier = Modifier
            .size(size + 16.dp)
            .clickable {
                val now = HistoryStore.toggleFavorite(song)
                fav = now
            }
            .padding((size + 16.dp) / 2 - size / 2),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = if (fav) "取消收藏" else "收藏",
            tint = if (fav) p.heartOn else p.text3,
            modifier = Modifier.size(size)
        )
    }
}

// ===== 空态提示 =====
@Composable
fun EmptyHint(title: String, subtitle: String) {
    val p = LocalPalette.current
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(56.dp), tint = p.text3.copy(alpha = 0.5f))
        Spacer(Modifier.height(12.dp))
        Text(title, color = p.text2, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = p.text3, fontSize = 12.sp)
    }
}
