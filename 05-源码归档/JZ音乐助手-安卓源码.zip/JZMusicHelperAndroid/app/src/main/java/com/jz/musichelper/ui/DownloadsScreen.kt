package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.model.DownloadItem
import com.jz.musichelper.model.DownloadStatus
import com.jz.musichelper.ui.theme.LocalPalette

// ===== 下载管理页：行点击进播放页 + 垃圾桶删除本地文件 =====
@Composable
fun DownloadsScreen(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val items by DownloadManager.items.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        // 左上角返回按钮 + 标题
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(p.accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                    .clickable { AppState.tab.value = MainTab.HOME },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "返回",
                    tint = p.accent2,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                "下载管理",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = p.text,
                modifier = Modifier.padding(start = 8.dp, top = 6.dp)
            )
        }

        if (items.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(56.dp), tint = p.text3.copy(alpha = 0.5f))
                Spacer(Modifier.height(12.dp))
                Text("还没有下载任务", color = p.text2, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("播放页点「下载」选择音质即可", color = p.text3, fontSize = 12.sp)
            }
            return
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Text(
                    "保存位置：系统媒体库 Music/JZ音乐助手",
                    fontSize = 12.sp,
                    color = p.text3,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)
                )
            }
            items(items, key = { it.id }) { item ->
                DownloadRowDark(item)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun DownloadRowDark(item: DownloadItem) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { AppState.openSong(item.song) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongCover(song = item.song, size = 48.dp, corner = 8.dp)
        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.song.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(qualityTag(item.quality), color = p.accent2, fontSize = 10.sp)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "${item.song.singer} · ${item.status.text()}",
                color = p.text3,
                fontSize = 12.sp,
                maxLines = 1
            )
            if (item.status == DownloadStatus.DOWNLOADING || item.status == DownloadStatus.PENDING) {
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(p.surface2)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(item.progress.coerceIn(0f, 1f))
                            .height(4.dp)
                            .clip(RoundedCornerShape(50))
                            .background(p.accent)
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(item.progressText, color = p.text3, fontSize = 11.sp)
            }
            if (item.status == DownloadStatus.FAILED) {
                Spacer(Modifier.height(2.dp))
                Text(item.errorMessage ?: "下载失败", color = Color(0xFFE5484D), fontSize = 11.sp, maxLines = 2)
            }
        }

        // 右侧操作
        when (item.status) {
            DownloadStatus.DOWNLOADING, DownloadStatus.PENDING -> {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = p.accent, strokeWidth = 2.dp)
            }
            DownloadStatus.FAILED -> {
                Icon(
                    Icons.Filled.Refresh,
                    contentDescription = "重试",
                    tint = p.accent2,
                    modifier = Modifier
                        .size(40.dp)
                        .clickable { DownloadManager.retry(item.id) }
                        .padding(8.dp)
                )
            }
            else -> {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "删除本地文件",
                    tint = p.text3,
                    modifier = Modifier
                        .size(40.dp)
                        .clickable {
                            DownloadManager.remove(item.id, deleteFile = item.status == DownloadStatus.COMPLETED)
                            toast("已删除《${item.song.name}》")
                        }
                        .padding(8.dp)
                )
            }
        }
    }
}

private fun DownloadStatus.text(): String = when (this) {
    DownloadStatus.PENDING -> "等待中"
    DownloadStatus.DOWNLOADING -> "下载中"
    DownloadStatus.COMPLETED -> "已完成"
    DownloadStatus.FAILED -> "失败"
    DownloadStatus.CANCELLED -> "已取消"
}

private fun qualityTag(q: com.jz.musichelper.model.QualityLevel): String = when (q) {
    com.jz.musichelper.model.QualityLevel.STANDARD -> "标准"
    com.jz.musichelper.model.QualityLevel.HIGH -> "高品 320k"
    com.jz.musichelper.model.QualityLevel.LOSSLESS -> "无损"
}
