package com.jz.musichelper.data

import android.content.Context
import com.jz.musichelper.model.DownloadItem
import com.jz.musichelper.model.DownloadStatus
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.SearchHistoryItem
import com.jz.musichelper.model.Song
import org.json.JSONArray
import org.json.JSONObject

// 历史与偏好存储：SharedPreferences + JSON
object HistoryStore {

    private const val PREFS = "jz_music_prefs"
    private const val KEY_SEARCH_HISTORY = "search_history"
    private const val KEY_RECENT_SONGS = "recent_songs"
    private const val KEY_DOWNLOADS = "downloads"
    private const val KEY_QUALITY = "quality"
    private const val KEY_THEME = "theme"
    private const val KEY_PLAY_MODE = "play_mode"
    private const val KEY_FAVORITES = "favorites"

    private lateinit var prefs: android.content.SharedPreferences
    private val maxSearchHistory = 20
    private val maxRecentSongs = 50

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    // ---------- 搜索历史 ----------

    fun loadSearchHistory(): List<SearchHistoryItem> {
        val raw = prefs.getString(KEY_SEARCH_HISTORY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SearchHistoryItem(o.optString("keyword"), o.optLong("createdAt"))
            }
        }.getOrDefault(emptyList())
    }

    fun recordSearch(keyword: String) {
        val kw = keyword.trim()
        if (kw.isEmpty()) return
        val list = loadSearchHistory().filterNot { it.keyword == kw }
        val newList = listOf(SearchHistoryItem(kw, System.currentTimeMillis())) + list
        val trimmed = newList.take(maxSearchHistory)
        saveSearchHistory(trimmed)
    }

    fun clearSearchHistory() {
        prefs.edit().remove(KEY_SEARCH_HISTORY).apply()
    }

    private fun saveSearchHistory(list: List<SearchHistoryItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("keyword", it.keyword).put("createdAt", it.createdAt)) }
        prefs.edit().putString(KEY_SEARCH_HISTORY, arr.toString()).apply()
    }

    // ---------- 最近歌曲 ----------

    fun loadRecentSongs(): List<Song> {
        val raw = prefs.getString(KEY_RECENT_SONGS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i -> songFromJson(arr.getJSONObject(i)) }
        }.getOrDefault(emptyList())
    }

    fun recordSong(song: Song) {
        val list = loadRecentSongs().filterNot {
            it.platform == song.platform && it.platformID == song.platformID
        }
        val newList = listOf(song) + list
        val trimmed = newList.take(maxRecentSongs)
        val arr = JSONArray()
        trimmed.forEach { arr.put(songToJson(it)) }
        prefs.edit().putString(KEY_RECENT_SONGS, arr.toString()).apply()
    }

    // ---------- 下载记录 ----------

    fun loadDownloadItems(): List<DownloadItem> {
        val raw = prefs.getString(KEY_DOWNLOADS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i -> itemFromJson(arr.getJSONObject(i)) }
        }.getOrDefault(emptyList())
    }

    fun saveDownloadItems(items: List<DownloadItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(itemToJson(it)) }
        prefs.edit().putString(KEY_DOWNLOADS, arr.toString()).apply()
    }

    // ---------- 设置 ----------

    fun saveQuality(q: QualityLevel) {
        prefs.edit().putString(KEY_QUALITY, q.name).apply()
    }

    fun loadQuality(): QualityLevel {
        val name = prefs.getString(KEY_QUALITY, null) ?: return QualityLevel.HIGH
        return runCatching { QualityLevel.valueOf(name) }.getOrDefault(QualityLevel.HIGH)
    }

    // ---------- 主题 ----------

    fun loadTheme(): String {
        return prefs.getString(KEY_THEME, null) ?: "NIGHTINGALE"
    }

    fun saveTheme(name: String) {
        prefs.edit().putString(KEY_THEME, name).apply()
    }

    // ---------- 播放模式 ----------

    fun savePlayMode(mode: String) {
        prefs.edit().putString(KEY_PLAY_MODE, mode).apply()
    }

    fun loadPlayMode(): String {
        return prefs.getString(KEY_PLAY_MODE, null) ?: "LIST_LOOP"
    }

    // ---------- 收藏 ----------

    fun loadFavorites(): List<Song> {
        val raw = prefs.getString(KEY_FAVORITES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i -> songFromJson(arr.getJSONObject(i)) }
        }.getOrDefault(emptyList())
    }

    fun saveFavorites(list: List<Song>) {
        val arr = JSONArray()
        list.forEach { arr.put(songToJson(it)) }
        prefs.edit().putString(KEY_FAVORITES, arr.toString()).apply()
    }

    fun isFavorite(song: Song): Boolean =
        loadFavorites().any { it.platform == song.platform && it.platformID == song.platformID }

    fun toggleFavorite(song: Song): Boolean {
        val list = loadFavorites()
        val exists = list.any { it.platform == song.platform && it.platformID == song.platformID }
        val newList = if (exists) list.filterNot { it.platform == song.platform && it.platformID == song.platformID }
        else listOf(song) + list
        saveFavorites(newList)
        return !exists
    }

    // ---------- JSON 序列化 ----------

    private fun songToJson(s: Song): JSONObject = JSONObject()
        .put("platform", s.platform.name)
        .put("platformID", s.platformID)
        .put("name", s.name)
        .put("singer", s.singer)
        .put("album", s.album)
        .put("durationSec", s.durationSec)
        .put("picUrl", s.picUrl)

    private fun songFromJson(o: JSONObject): Song {
        val platform = com.jz.musichelper.model.MusicPlatform.valueOf(o.optString("platform", "QQ"))
        return Song(
            platform = platform,
            platformID = o.optString("platformID"),
            name = o.optString("name"),
            singer = o.optString("singer"),
            album = o.optString("album"),
            durationSec = o.optInt("durationSec"),
            picUrl = o.optString("picUrl").takeIf { it.isNotEmpty() && it != "null" }
        )
    }

    private fun itemToJson(it: DownloadItem): JSONObject = JSONObject()
        .put("id", it.id)
        .put("song", songToJson(it.song))
        .put("streamUrl", it.streamUrl)
        .put("backendName", it.backendName)
        .put("quality", it.quality.name)
        .put("fileName", it.fileName)
        .put("status", it.status.name)
        .put("progress", it.progress)
        .put("receivedBytes", it.receivedBytes)
        .put("totalBytes", it.totalBytes)
        .put("createdAt", it.createdAt)
        .put("errorMessage", it.errorMessage)
        .put("localPath", it.localPath)

    private fun itemFromJson(o: JSONObject): DownloadItem = DownloadItem(
        id = o.optString("id"),
        song = songFromJson(o.optJSONObject("song") ?: JSONObject()),
        streamUrl = o.optString("streamUrl"),
        backendName = o.optString("backendName"),
        quality = runCatching { QualityLevel.valueOf(o.optString("quality", "HIGH")) }.getOrDefault(QualityLevel.HIGH),
        fileName = o.optString("fileName"),
        status = runCatching { DownloadStatus.valueOf(o.optString("status", "PENDING")) }.getOrDefault(DownloadStatus.PENDING),
        progress = o.optDouble("progress", 0.0).toFloat(),
        receivedBytes = o.optLong("receivedBytes"),
        totalBytes = o.optLong("totalBytes"),
        createdAt = o.optLong("createdAt"),
        errorMessage = o.optString("errorMessage").takeIf { it.isNotEmpty() && it != "null" },
        localPath = o.optString("localPath").takeIf { it.isNotEmpty() && it != "null" }
    )
}
