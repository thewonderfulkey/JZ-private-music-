package com.jz.musichelper

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.ui.App
import java.io.File
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 全局兜底：任何未预期异常写入 crash.log 与偏好（设置页可查诊断），不弹窗、不杀进程
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val f = File(filesDir, "crash.log")
                f.appendText("===== ${Date()} [${thread.name}] =====\n$throwable\n")
                throwable.stackTrace?.forEach { f.appendText("    at $it\n") }
                f.appendText("\n")
                // 同步到偏好，供设置页"异常诊断"直接展示
                val stack = throwable.stackTrace?.take(10)?.joinToString("\n") { "    at $it" } ?: ""
                getSharedPreferences("jz_music_prefs", MODE_PRIVATE)
                    .edit()
                    .putString("last_error", "$throwable\n$stack")
                    .putLong("last_error_time", System.currentTimeMillis())
                    .apply()
            } catch (_: Exception) {
            }
        }
        DownloadManager.init(this)
        PlayerManager.init(this)
        enableEdgeToEdge()
        setContent {
            App()
        }
    }
}
