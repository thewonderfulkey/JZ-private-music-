package com.jz.musichelper.data

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.jz.musichelper.model.DownloadItem
import com.jz.musichelper.model.DownloadStatus
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import com.jz.musichelper.network.ApiClient
import com.jz.musichelper.network.ApiError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// 下载管理器：协程流式下载 + 保存到公共 Music 目录（媒体库可见）
// App 切后台/锁屏不中断（全局作用域）；进程被杀则中断，可在下载页重试
object DownloadManager {

    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items

    val activeJobs = mutableMapOf<String, Job>()

    fun init(context: Context) {
        appContext = context.applicationContext
        HistoryStore.init(appContext)
        _items.value = HistoryStore.loadDownloadItems()
    }

    private fun sanitizeFileName(s: String): String =
        s.replace(Regex("[/\\\\:*?\"<>|]"), "_")

    private fun extensionFor(format: String, url: String): String {
        val f = format.lowercase()
        if (f.contains("flac")) return "flac"
        if (f.contains("m4a") || f.contains("aac")) return "m4a"
        if (f.contains("ogg")) return "ogg"
        if (f.contains("wav")) return "wav"
        if (f.contains("mp3")) return "mp3"
        val ext = url.substringAfterLast('.', "").take(5)
        if (ext.isNotEmpty() && !ext.contains('/')) return ext
        return "mp3"
    }

    fun startDownload(song: Song, source: StreamSource) {
        val ext = extensionFor(source.format, source.url)
        val fileName = sanitizeFileName("${song.singer} - ${song.name} [${song.platform.shortName}/${source.backendName}].$ext")
        val id = UUID.randomUUID().toString()
        val item = DownloadItem(
            id = id,
            song = song,
            streamUrl = source.url,
            backendName = source.backendName,
            quality = source.quality,
            fileName = fileName,
            status = DownloadStatus.DOWNLOADING,
            progress = 0f,
            receivedBytes = 0,
            totalBytes = 0,
            createdAt = System.currentTimeMillis()
        )
        appendItem(item)
        activeJobs[id] = scope.launch {
            try {
                downloadToPublic(item)
            } catch (e: Exception) {
                updateItem(id) { it.copy(status = DownloadStatus.FAILED, errorMessage = e.message ?: "下载失败") }
            } finally {
                activeJobs.remove(id)
            }
        }
    }

    // 下载到公共 Music 目录
    private suspend fun downloadToPublic(item: DownloadItem) {
        val req = Request.Builder()
            .url(item.streamUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Mobile Safari/604.1")
            .header("Referer", "https://music.qq.com/")
            .build()
        val resp = ApiClient.client.newCall(req).execute()
        if (!resp.isSuccessful) throw ApiError.HTTP(resp.code)
        val total = resp.body?.contentLength() ?: 0L
        updateItem(item.id) { it.copy(totalBytes = total) }

        // 先写临时文件（用 InputStream 标准 API，避免 okio 特殊 API）
        val tmpFile = File(appContext.cacheDir, "dl_${item.id}.part")
        resp.body!!.byteStream().use { input ->
            val sink = FileOutputStream(tmpFile).buffered()
            val buf = ByteArray(64 * 1024)
            var downloaded = 0L
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                sink.write(buf, 0, n)
                downloaded += n
                val p = if (total > 0) downloaded.toFloat() / total else 0f
                updateItem(item.id) { it.copy(receivedBytes = downloaded, progress = p.coerceIn(0f, 1f)) }
            }
            sink.close()
        }
        resp.close()

        // 保存到公共目录
        val finalPath = saveToPublicMusic(tmpFile, item.fileName)
        tmpFile.delete()
        updateItem(item.id) { it.copy(status = DownloadStatus.COMPLETED, progress = 1f, localPath = finalPath) }
    }

    // API 29+ 用 MediaStore 写公共 Music；API 26-28 写外部存储 MUSIC 目录
    private fun saveToPublicMusic(tmpFile: File, fileName: String): String {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(fileName))
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/JZ音乐助手")
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
            }
            val resolver = appContext.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("无法写入媒体库")
            resolver.openOutputStream(uri)?.use { out ->
                tmpFile.inputStream().use { it.copyTo(out) }
            } ?: throw Exception("无法打开输出流")
            uri.toString()
        } else {
            val musicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val dir = File(musicDir, "JZ音乐助手").apply { mkdirs() }
            val dest = File(dir, fileName)
            tmpFile.copyTo(dest, overwrite = true)
            // 触发媒体库扫描
            MediaScannerConnection.scanFile(appContext, arrayOf(dest.absolutePath), arrayOf(mimeFor(fileName)), null)
            dest.absolutePath
        }
    }

    private fun mimeFor(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "flac" -> "audio/flac"
        "m4a" -> "audio/mp4"
        "ogg" -> "audio/ogg"
        "wav" -> "audio/wav"
        else -> "audio/mpeg"
    }

    fun cancel(id: String) {
        activeJobs[id]?.cancel()
        updateItem(id) { it.copy(status = DownloadStatus.CANCELLED) }
        activeJobs.remove(id)
    }

    fun remove(id: String, deleteFile: Boolean) {
        val item = _items.value.find { it.id == id } ?: return
        if (deleteFile && item.status == DownloadStatus.COMPLETED) {
            item.localPath?.let { path ->
                runCatching {
                    if (path.startsWith("content://")) {
                        appContext.contentResolver.delete(android.net.Uri.parse(path), null, null)
                    } else {
                        File(path).delete()
                    }
                }
            }
        }
        _items.value = _items.value.filterNot { it.id == id }
        HistoryStore.saveDownloadItems(_items.value)
    }

    fun retry(id: String) {
        val item = _items.value.find { it.id == id } ?: return
        // 复用新条目
        val newId = UUID.randomUUID().toString()
        val newItem = item.copy(id = newId, status = DownloadStatus.DOWNLOADING, progress = 0f,
            receivedBytes = 0, totalBytes = 0, errorMessage = null, localPath = null)
        appendItem(newItem)
        activeJobs[newId] = scope.launch {
            try {
                downloadToPublic(newItem)
            } catch (e: Exception) {
                updateItem(newId) { it.copy(status = DownloadStatus.FAILED, errorMessage = e.message ?: "下载失败") }
            } finally {
                activeJobs.remove(newId)
            }
        }
    }

    private fun appendItem(item: DownloadItem) {
        _items.value = listOf(item) + _items.value
        HistoryStore.saveDownloadItems(_items.value)
    }

    private fun updateItem(id: String, transform: (DownloadItem) -> DownloadItem) {
        _items.value = _items.value.map {
            if (it.id == id) transform(it) else it
        }
        HistoryStore.saveDownloadItems(_items.value)
    }
}
