package com.jz.musichelper.data

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import com.jz.musichelper.network.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// 在线试听：系统 MediaPlayer（带 UA/Referer 头）
object PlayerManager {

    private lateinit var appContext: Context
    private var player: MediaPlayer? = null

    private val _currentUrl = MutableStateFlow<String?>(null)
    val currentUrl: StateFlow<String?> = _currentUrl

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun play(url: String) {
        stop()
        _currentUrl.value = url
        _error.value = null
        try {
            val mp = MediaPlayer()
            mp.setDataSource(appContext, Uri.parse(url), mapOf(
                "User-Agent" to ApiClient.MOBILE_UA,
                "Referer" to "https://music.qq.com/"
            ))
            mp.setOnPreparedListener {
                it.start()
                _isPlaying.value = true
            }
            mp.setOnCompletionListener {
                _isPlaying.value = false
            }
            mp.setOnErrorListener { _, _, _ ->
                _error.value = "播放失败（源可能已失效）"
                _isPlaying.value = false
                release()
                true
            }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            _error.value = "播放失败：${e.message}"
        }
    }

    fun toggle() {
        val p = player ?: return
        if (_isPlaying.value) {
            p.pause()
            _isPlaying.value = false
        } else {
            p.start()
            _isPlaying.value = true
        }
    }

    fun stop() {
        release()
        _isPlaying.value = false
        _currentUrl.value = null
    }

    private fun release() {
        player?.release()
        player = null
    }
}
