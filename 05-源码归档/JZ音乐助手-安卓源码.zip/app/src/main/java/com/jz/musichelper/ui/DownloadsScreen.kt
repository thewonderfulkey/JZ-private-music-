package com.jz.musichelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.model.DownloadItem
import com.jz.musichelper.model.DownloadStatus

@Composable
fun DownloadsScreen(modifier: Modifier = Modifier) {
    val items by DownloadManager.items.collectAsState()

    if (items.isEmpty()) {
        Column(
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Filled.ArrowDownward, contentDescription = null, modifier = Modifier.size(56.dp), tint = Color(0xFFBBBBBB))
            Spacer(Modifier.height(12.dp))
            Text("还没有下载任务", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("在歌曲详情页点「下载」即可开始", color = Color(0xFF888888))
        }
        return
    }

    LazyColumn(modifier = modifier.fillMaxSize()) {
        item {
            Text(
                "保存位置：系统媒体库 Music/JZ音乐助手（可在音乐 App 中查看）",
                fontSize = 12.sp,
                color = Color(0xFF999999),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        items(items, key = { it.id }) { item ->
            DownloadRow(item)
        }
    }
}

@Composable
fun DownloadRow(item: DownloadItem) {
    Surface(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        color = Color(0xFFF7F7F7),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    iconFor(item.status),
                    contentDescription = null,
                    tint = colorFor(item.status),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.song.name, fontWeight = FontWeight.Medium, maxLines = 1)
                    Text(
                        "${item.song.singer} · ${item.backendName}",
                        fontSize = 12.sp,
                        color = Color(0xFF888888),
                        maxLines = 1
                    )
                }
                Text(statusText(item.status), fontSize = 12.sp, color = Color(0xFF666666))
            }

            if (item.status == DownloadStatus.DOWNLOADING || item.status == DownloadStatus.PENDING) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { item.progress },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                Row {
                    Text(item.progressText, fontSize = 11.sp, color = Color(0xFF999999))
                    Spacer(Modifier.weight(1f))
                    if (item.sizeText.isNotEmpty()) {
                        Text(item.sizeText, fontSize = 11.sp, color = Color(0xFF999999))
                    }
                }
            }

            if (item.status == DownloadStatus.FAILED) {
                item.errorMessage?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, fontSize = 12.sp, color = Color(0xFFD32F2F), maxLines = 2)
                }
            }

            if (item.status == DownloadStatus.FAILED || item.status == DownloadStatus.CANCELLED) {
                Spacer(Modifier.height(6.dp))
                Row {
                    TextButton(onClick = { DownloadManager.retry(item.id) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("重试")
                    }
                    TextButton(onClick = { DownloadManager.remove(item.id, deleteFile = false) }) {
                        Text("删除记录")
                    }
                }
            }

            if (item.status == DownloadStatus.COMPLETED) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("已保存到媒体库", fontSize = 12.sp, color = Color(0xFF2E7D32))
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { DownloadManager.remove(item.id, deleteFile = true) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "删除文件", tint = Color(0xFF888888))
                    }
                }
            }
        }
    }
}

private fun iconFor(status: DownloadStatus) = when (status) {
    DownloadStatus.PENDING -> Icons.Filled.MusicNote
    DownloadStatus.DOWNLOADING -> Icons.Filled.ArrowDownward
    DownloadStatus.COMPLETED -> Icons.Filled.CheckCircle
    DownloadStatus.FAILED -> Icons.Filled.Error
    DownloadStatus.CANCELLED -> Icons.Filled.Cancel
}

private fun colorFor(status: DownloadStatus) = when (status) {
    DownloadStatus.PENDING -> Color(0xFFF59E0B)
    DownloadStatus.DOWNLOADING -> Color(0xFF1E88E5)
    DownloadStatus.COMPLETED -> Color(0xFF2E7D32)
    DownloadStatus.FAILED -> Color(0xFFD32F2F)
    DownloadStatus.CANCELLED -> Color(0xFF9E9E9E)
}

private fun statusText(status: DownloadStatus) = when (status) {
    DownloadStatus.PENDING -> "等待中"
    DownloadStatus.DOWNLOADING -> "下载中"
    DownloadStatus.COMPLETED -> "已完成"
    DownloadStatus.FAILED -> "失败"
    DownloadStatus.CANCELLED -> "已取消"
}
