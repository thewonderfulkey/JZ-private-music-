package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

// 并发搜索服务：所有平台同时搜，先返回的先进结果列表；单平台超时/失败自动忽略
object SearchService {

    private val adapters: List<SearchAdapter> = listOf(
        QQSearchAdapter(),
        NeteaseSearchAdapter(),
        KuwoSearchAdapter(),
        KugouSearchAdapter()
    )

    private const val PER_SOURCE_TIMEOUT_MS = 10_000L

    // 每个平台的搜索结果（保持平台维度）
    data class PlatformResult(val platform: MusicPlatform, val songs: List<Song>, val error: String?)

    /** 并发搜索全部平台，等待所有完成（每个平台独立超时） */
    suspend fun searchAll(keyword: String, limit: Int = 20): List<PlatformResult> = coroutineScope {
        adapters.map { adapter ->
            async {
                val result = withTimeoutOrNull(PER_SOURCE_TIMEOUT_MS) {
                    runCatching { adapter.search(keyword, limit) }.getOrElse { throw it }
                }
                if (result != null) {
                    PlatformResult(adapter.platform, result, null)
                } else {
                    PlatformResult(adapter.platform, emptyList(), "超时")
                }
            }
        }.awaitAll().map { pr ->
            if (pr.songs.isEmpty() && pr.error == null) {
                // 无异常但空结果，保留平台维度
                pr
            } else pr
        }
    }
}

// 并发取流解析：一首歌同时尝试所有可用后端，收集全部成功结果
object UrlResolver {

    private const val PER_BACKEND_TIMEOUT_MS = 12_000L

    data class ResolveResult(val sources: List<StreamSource>, val failed: Map<String, String>)

    suspend fun resolveAll(song: Song, quality: com.jz.musichelper.model.QualityLevel): ResolveResult = coroutineScope {
        val adapters = SourceRegistry.adaptersFor(song)
        val sources = mutableListOf<StreamSource>()
        val failed = mutableMapOf<String, String>()

        adapters.map { adapter ->
            async {
                val r = withTimeoutOrNull(PER_BACKEND_TIMEOUT_MS) {
                    runCatching { adapter.resolve(song, quality) }.getOrNull()
                }
                adapter.name to r
            }
        }.awaitAll().forEach { (name, src) ->
            if (src != null) sources.add(src) else failed[name] = "失败或超时"
        }
        ResolveResult(sources, failed)
    }
}
