package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

// 并发搜索服务：所有平台同时搜，先返回的先进结果列表；单平台超时/失败自动忽略
// 硬约束：任何单个平台的任何异常都不得外抛（否则整个 App 崩溃），就地转为失败结果
object SearchService {

    private val adapters: List<SearchAdapter> = listOf(
        QQSearchAdapter(),
        NeteaseSearchAdapter(),
        KuwoSearchAdapter()
        // v2.1.9：废弃酷狗——取流后端从未实现（SourceRegistry 无酷狗适配器，跨平台兜底为空），
        // 官方三接口匿名全被风控（wwwapi 30020 / mobilecdn Access Deny / m.kugou url 为空），
        // 第三方通道（妖狐/gdstudio/oiapi/V7）实测全不可用，修取流无现成实现，按用户拍板废弃
    )

    private const val PER_SOURCE_TIMEOUT_MS = 8_000L   // v2.1.9：6s→8s，酷我慢网/大响应（rn=20≈45KB）更稳

    // 每个平台的搜索结果（保持平台维度）
    data class PlatformResult(val platform: MusicPlatform, val songs: List<Song>, val error: String?)

    /** 并发搜索全部平台，等待所有完成（每个平台独立超时；单平台失败只标记 error，不抛出） */
    suspend fun searchAll(keyword: String, limit: Int = 20): List<PlatformResult> = coroutineScope {
        adapters.map { adapter ->
            async {
                try {
                    val result = withTimeoutOrNull(PER_SOURCE_TIMEOUT_MS) {
                        adapter.search(keyword, limit)
                    }
                    if (result != null) {
                        PlatformResult(adapter.platform, result, null)
                    } else {
                        PlatformResult(adapter.platform, emptyList(), "超时")
                    }
                } catch (e: Exception) {
                    // 捕获一切异常（含取消副作用 / SSL / 解析失败），转为该平台失败，绝不外抛
                    PlatformResult(adapter.platform, emptyList(), e.message ?: "失败")
                }
            }
        }.awaitAll()
    }
}

// 并发取流解析：一首歌同时尝试所有可用后端，收集全部成功结果
// 硬约束：单个后端失败只计入 failed，不外抛
object UrlResolver {

    private const val PER_BACKEND_TIMEOUT_MS = 12_000L

    data class ResolveResult(val sources: List<StreamSource>, val failed: Map<String, String>)

    suspend fun resolveAll(song: Song, quality: QualityLevel): ResolveResult = coroutineScope {
        val adapters = SourceRegistry.adaptersFor(song)
        val sources = mutableListOf<StreamSource>()
        val failed = mutableMapOf<String, String>()

        adapters.map { adapter ->
            async {
                val r = try {
                    withTimeoutOrNull(PER_BACKEND_TIMEOUT_MS) {
                        adapter.resolve(song, quality)
                    }
                } catch (e: Exception) {
                    null
                }
                adapter.name to r
            }
        }.awaitAll().forEach { (name, src) ->
            if (src != null) sources.add(src) else failed[name] = "失败或超时"
        }
        ResolveResult(sources, failed)
    }
}

// 按用户所选音质从多个可用源中挑选最匹配的一个（防“选无损却拿到 128k m4a”）
// 评分：无损优先 flac/ape/wav 真无损 → 标注无损 → 高品 → 标准；m4a 一律最低优先级
object SourcePicker {
    fun pick(sources: List<StreamSource>, want: QualityLevel): StreamSource? {
        if (sources.isEmpty()) return null
        // v2.1.4：同档分数下优先"按平台 ID 直连"的后端（身份可靠），搜索式取流后置——
        // 避免 HIGH 档 320k 标注的搜索式 mp3 压过同平台 QQ m4a 直链（"夜曲"曾因此播到伴奏）
        return sources.maxWithOrNull(
            compareBy<StreamSource> { score(it, want) }
                .thenByDescending { if (it.directId) 1 else 0 }
        )
    }

    internal fun score(src: StreamSource, want: QualityLevel): Int {
        val isLosslessFmt = src.format.contains("flac") || src.format.contains("ape") || src.format.contains("wav")
        return when (want) {
            QualityLevel.LOSSLESS -> when {
                src.quality == QualityLevel.LOSSLESS && isLosslessFmt -> 5
                src.quality == QualityLevel.LOSSLESS -> 4
                src.quality == QualityLevel.HIGH -> 2
                src.quality == QualityLevel.STANDARD -> 1
                else -> 0
            }
            QualityLevel.HIGH -> when {
                src.quality == QualityLevel.HIGH && !src.format.contains("m4a") -> 4
                src.quality == QualityLevel.HIGH -> 3
                src.quality == QualityLevel.LOSSLESS -> 3
                src.quality == QualityLevel.STANDARD -> 1
                else -> 0
            }
            QualityLevel.STANDARD -> if (src.quality == QualityLevel.STANDARD) 2 else 1
        } - if (src.directId) 0 else 1
    }
}

/**
 * v2.1.29：同曲跨平台补源——猜你喜欢/热门/自动连播与搜索共用同一套解析逻辑。
 * 背景：猜你喜欢只带"来源平台"的 ID，UrlResolver 默认只问本平台后端（SourceRegistry 的 cross 恒为空），
 * 本平台后端一挂就判无源并跳过；而同一首歌在其它平台的条目（搜索里能秒解析的那条）从未被尝试。
 * 做法：按"歌名+歌手"调用与搜索完全相同的 SearchService.searchAll（同适配器、同超时、同过滤），
 * 取出所有平台中"同歌手 / 同歌曲"的候选，逐个用候选自己平台的后端解析；
 * 只有全部候选都解析失败才返回 null —— 由调用方（AppState）决定是否跳过，
 * 从而保证"明明能解析的歌绝不被跳过"。
 */
object SameSongCrossResolver {

    private const val MAX_CANDIDATES = 8          // 单轮最多试 8 条同曲候选，避免长尾拖死队列
    private const val TOTAL_TIMEOUT_MS = 40_000L  // 整轮补源硬超时（搜索 8s + 候选逐个 12s）
    private const val MAX_DURATION_DIFF_SEC = 12  // 双方都有时长时，差 >12s 视为不同版本（live/remix/伴奏）
    private const val STRICT_DURATION_DIFF_SEC = 3 // v2.1.48：原唱换到 live/节目变体时的严阈值（差 >3s 一律否决）

    /**
     * @param triedKeys 已尝试过的候选 key 集合（跨轮次复用，避免重复打同一批候选）
     * @return 可用音源；所有同曲候选都失败时返回 null
     */
    suspend fun resolve(
        song: Song,
        quality: QualityLevel,
        triedKeys: MutableSet<String>
    ): StreamSource? = withTimeoutOrNull(TOTAL_TIMEOUT_MS) {
        val kw = (song.name + " " + song.singer).trim()
        if (kw.isBlank()) return@withTimeoutOrNull null
        val results = runCatching { SearchService.searchAll(kw, 30) }.getOrNull()
            ?: return@withTimeoutOrNull null
        val cands = results.asSequence()
            .flatMap { it.songs.asSequence() }
            .filter { sameSong(song, it) }
            .filter { candKey(it) !in triedKeys }
            // v2.1.30：同平台取流更稳优先；同平台内再按「录音棚原唱」得分排——
            // 避免先试到同平台的 (Live)/节目版，白跑一轮后端
            .sortedWith(
                compareBy<Song> { if (it.platform == song.platform) 0 else 1 }
                    .thenByDescending { StudioPick.studioScore(it) }
            )
            .distinctBy { candKey(it) }
            .take(MAX_CANDIDATES)
            .toList()
        for (c in cands) {
            triedKeys.add(candKey(c))
        }
        // 候选分批（每批 3 条）并发解析：单批约 1 个后端超时（12s）即可出结果，避免 8 条串行拖到分钟级
        var picked: StreamSource? = null
        for (batch in cands.chunked(3)) {
            if (picked != null) break
            coroutineScope {
                val got = batch.map { c ->
                    async {
                        val r = runCatching { UrlResolver.resolveAll(c, quality) }.getOrNull()
                        if (r != null) SourcePicker.pick(r.sources, quality) else null
                    }
                }.awaitAll()
                picked = got.firstOrNull { it != null }
            }
        }
        picked
    }

    /** 跨源补源的产出：exact=正好是目标档（优先用）；best=能拿到的最高档（降级兜底用） */
    data class CrossOutcome(val exact: StreamSource?, val best: StreamSource?)

    /**
     * v2.1.48 下载专用：一次遍历同时求「目标档」与「最高可得档」。
     * 与 [resolve] 的差别——resolve 拿到一条源就返回（播放够用即可），
     * 而下载必须先知道"拿到的到底是不是用户要的那一档"，否则就是"说能下无损、实际下 128k"。
     */
    suspend fun resolveForDownload(
        song: Song,
        want: QualityLevel,
        triedKeys: MutableSet<String>
    ): CrossOutcome? = withTimeoutOrNull(TOTAL_TIMEOUT_MS) {
        val kw = (song.name + " " + song.singer).trim()
        if (kw.isBlank()) return@withTimeoutOrNull CrossOutcome(null, null)
        val results = runCatching { SearchService.searchAll(kw, 30) }.getOrNull()
            ?: return@withTimeoutOrNull CrossOutcome(null, null)
        val cands = results.asSequence()
            .flatMap { it.songs.asSequence() }
            .filter { sameSong(song, it) }
            .filter { candKey(it) !in triedKeys }
            // 同平台优先（取流链路更稳）→ 录音棚原唱得分高者优先（先把 Live/节目版排到后面）
            .sortedWith(
                compareBy<Song> { if (it.platform == song.platform) 0 else 1 }
                    .thenByDescending { StudioPick.studioScore(it) }
            )
            .distinctBy { candKey(it) }
            .take(MAX_CANDIDATES)
            .toList()
        for (c in cands) triedKeys.add(candKey(c))

        var exact: StreamSource? = null
        var best: StreamSource? = null
        for (batch in cands.chunked(3)) {
            if (exact != null) break     // 已拿到目标档，没必要再把剩下的打完
            val got = coroutineScope {
                batch.map { c ->
                    async {
                        val r = runCatching { UrlResolver.resolveAll(c, want) }.getOrNull()
                        if (r != null) SourcePicker.pick(r.sources, want) else null
                    }
                }.awaitAll()
            }
            for (s in got) {
                if (s == null) continue
                if (s.quality == want && exact == null) exact = s
                val cur = best
                if (cur == null || s.quality.ordinal > cur.quality.ordinal) best = s
            }
        }
        CrossOutcome(exact, best)
    }

    private fun candKey(s: Song) = s.platform.name + "_" + s.platformID

    /** 同曲判定（统一口径见 NameMatch）：歌名匹配 + 歌手匹配 + 时长不差一个版本 */
    private fun sameSong(src: Song, cand: Song): Boolean {
        if (src.platform == cand.platform && src.platformID == cand.platformID) return false  // 自己不算候选
        if (!NameMatch.titleMatches(src.name, cand.name)) return false
        if (!NameMatch.singerMatches(src.singer, cand.singer)) return false
        if (src.durationSec > 0 && cand.durationSec > 0) {
            val diff = kotlin.math.abs(src.durationSec - cand.durationSec)
            // v2.1.48 版本防线（对应"换源不能下错版本"）：源是干净原唱、候选却是 live/综艺/节目变体时，
            // 换源就等于把别人的版本下给用户。只有时长几乎一致（≤3s，通常就是同一录音的不同码率转出）才认。
            val candIsVariant = !StudioPick.isCleanTitle(cand.name) ||
                (cand.album.isNotBlank() && StudioPick.isLiveAlbum(cand.album))
            if (StudioPick.isCleanTitle(src.name) && candIsVariant && diff > STRICT_DURATION_DIFF_SEC) return false

            if (diff > MAX_DURATION_DIFF_SEC) {
                // v2.1.30：源条目本身是「现场/节目变体」（歌名带 (Live)/（央视春晚现场版）等非裸名前缀），
                // 而候选是干净的录音室条目（裸名 + 正式专辑 + 更长），视为同一首歌的原唱版，允许跨越时长差。
                // 例如源《龙文 (Live)》236s → 候选《龙文》/专辑《看见》313s。
                val srcIsVariant = !StudioPick.isCleanTitle(src.name)
                val candIsStudio = StudioPick.isCleanTitle(cand.name) &&
                    cand.album.isNotBlank() && !StudioPick.isLiveAlbum(cand.album) &&
                    cand.durationSec > src.durationSec
                if (!(srcIsVariant && candIsStudio)) return false
            }
        }
        return true
    }
}

/**
 * v2.1.48 下载取源编排：目标档优先 → 本平台换后端 → 跨平台换源 → 如实降级。
 *
 * 为什么单独一层：原来下载直接调 SourcePicker.pick，而 pick 用 maxWithOrNull，列表非空必返回一条，
 * 于是"选了无损却拿到 128k"成为必然。这里把"是否真的拿到目标档"变成一个明确的返回值，
 * 让 UI 能如实告诉用户实际下到的是什么档（用户口径：可以降级，但必须说清楚）。
 */
object DownloadResolver {

    private const val GENERIC_TIMEOUT_MS = 12_000L  // 通用搜索式后端（妖狐酷我）单次硬超时

    data class Pick(
        val source: StreamSource?,   // null = 一个源都拿不到
        val exact: Boolean,          // 是否就是用户要的那一档
        val switched: Boolean,       // 是否靠换源（换平台/换条目）拿到
        val crossTried: Int          // 本轮换源试过多少条同曲候选
    )

    suspend fun resolve(song: Song, want: QualityLevel): Pick {
        // 第一轮：本平台自己的后端（QQ 只有 cyapi、网易有 gdstudio+oiapi、酷我有妖狐）
        val local = runCatching { UrlResolver.resolveAll(song, want) }.getOrNull()
        val localExact = local?.sources
            ?.filter { it.quality == want }
            ?.maxByOrNull { SourcePicker.score(it, want) }
        if (localExact != null) {
            // 妖狐挂在酷我名下，但它服务的是任何平台的歌——平台不同就如实算"已换源"
            return Pick(localExact, true, localExact.platform != song.platform, 0)
        }

        // 第二轮（v2.1.49）：通用搜索式后端兜底。
        // 妖狐酷我按"歌名+歌手"取流，跟歌来自哪个平台无关，实测是唯一稳定给真 FLAC 的通道
        // （网易那条路受搜索降权影响：周杰伦的歌在网易搜索里搜不到原唱条目，gdstudio 拿不到正确 id，
        //  于是"内置了那么多音源也拿不到无损"）。
        // 只对无损请求启用：妖狐恒返回 lossless，用户只要 128k/320k 时不该塞给他 40MB 的 FLAC。
        val generic: StreamSource? =
            if (want == QualityLevel.LOSSLESS && song.platform != MusicPlatform.KUWO) {
                runCatching {
                    withTimeoutOrNull(GENERIC_TIMEOUT_MS) {
                        YaohuKuwoAdapter().resolve(song, QualityLevel.LOSSLESS)
                    }
                }.getOrNull()
            } else null
        if (generic != null && generic.quality == QualityLevel.LOSSLESS) {
            return Pick(generic, true, true, 0)
        }

        // 第三轮：跨源换源——同歌名 + 同歌手，StudioPick 排掉 live/节目版，逐个换到拿到目标档为止
        val tried = mutableSetOf<String>()
        val cross = runCatching { SameSongCrossResolver.resolveForDownload(song, want, tried) }.getOrNull()
        val crossExact = cross?.exact
        if (crossExact != null) return Pick(crossExact, true, true, tried.size)

        // 第四轮：所有源都没目标档 → 如实降级到"能拿到的最高档"
        val localBest = local?.let { SourcePicker.pick(it.sources, want) }
        val crossBest = cross?.best
        val candidates = listOfNotNull(localBest, generic, crossBest)
        val fallback = candidates.maxByOrNull { it.quality.ordinal }
            ?: return Pick(null, false, false, tried.size)
        return Pick(fallback, false, fallback !== localBest, tried.size)
    }
}

