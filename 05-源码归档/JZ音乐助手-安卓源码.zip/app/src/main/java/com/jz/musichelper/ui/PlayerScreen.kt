package com.jz.musichelper.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.R
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.model.PlayMode
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.DownloadResolver
import com.jz.musichelper.network.LyricLine
import com.jz.musichelper.network.LyricsService
import com.jz.musichelper.ui.theme.InkTitleFont
import com.jz.musichelper.ui.theme.LocalPalette
import kotlinx.coroutines.launch

// ===== 正在播放页 v2.1.48（下载弹层去掉预检：三档选了就拿，跨源换源 + 拿不到时如实降级；循环键整圈回正、状态行固定占位沿用）=====
// ===== 断点口径 = Material3 WindowSizeClass（<600 手机 / 600–840 平板竖 / ≥840 平板横）=====
// ===== 平板两档 = 内容列限宽 420dp 居中、纵向余量由三处锚点均分（顶-画心 / 歌手-进度 / 控件-音源）=====
private enum class PlayerTier(
    val colWidth: Dp,          // 内容列宽（COMPACT 用 widthIn 上限，平板两档固定列宽）
    val frameW: Dp,            // 白框装裱宽
    val art: Dp,               // 方幅画心（1:1）
    val topGap: Dp,            // 弹性1：主体顶到白框
    val titleSp: TextUnit,     // 歌名字号
    val titleLh: TextUnit,
    val artistSp: TextUnit,
    val hintGap: Dp,           // 白框底到提示
    val titleGap: Dp,          // 提示底到题名
    val artistGap: Dp,         // 题名底到歌手
    val midSpacer: Dp,         // 进度到控件
    val ctlCenter: Boolean,    // 控件行：平板列内居中整组 / 手机两端对齐
    val ctlGap: Dp,
    val srcTop: Dp,            // 控件到音源行（弹性3）
    val srcBottom: Dp          // 音源行到底（贴底锚定）
) {
    COMPACT(0.dp, 286.dp, 258.dp, 32.dp, 32.sp, 35.sp, 12.sp, 32.dp, 22.dp, 4.dp, 30.dp, false, 0.dp, 10.dp, 0.dp),
    MEDIUM(420.dp, 420.dp, 392.dp, 120.dp, 40.sp, 44.sp, 13.sp, 14.dp, 8.dp, 4.dp, 30.dp, true, 32.dp, 120.dp, 30.dp),
    EXPANDED(420.dp, 336.dp, 300.dp, 16.dp, 40.sp, 44.sp, 13.sp, 10.dp, 8.dp, 2.dp, 8.dp, true, 32.dp, 16.dp, 24.dp)
}

@Composable
fun PlayerScreen(song: Song, onBack: () -> Unit) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()

    var showLyrics by remember { mutableStateOf(false) }   // 大歌词模式：true=主体区域显示歌词
    var showSheet by remember { mutableStateOf(false) }
    var lyricsLoading by remember { mutableStateOf(true) } // 歌词是否仍在请求中（加载中提示）
    var lyrics by remember { mutableStateOf<List<LyricLine>>(emptyList()) }
    var lyricsSource by remember { mutableStateOf<String?>(null) }
    var isDownloading by remember { mutableStateOf(false) }

    // 取流状态来自全局播放任务（点击/切歌即开始解析，退出播放页也不中断）；本页只消费，不自行发起请求
    val songKey = song.platform.name + song.platformID
    val isResolving = AppState.resolvingSongKey.value == songKey
    val resolveErr = AppState.resolveError.value?.takeIf { it.first == songKey }?.second

    val position by PlayerManager.position.collectAsState()
    val duration by PlayerManager.duration.collectAsState()
    val isPlaying by PlayerManager.isPlaying.collectAsState()
    val playerErrorFlow by PlayerManager.error.collectAsState()
    var dragValue by remember { mutableStateOf<Float?>(null) }

    // 进入/切歌：取流由 AppState 全局任务完成（见 resolveAndPlayIfNeeded），本页不再持有 LaunchedEffect 取流，
    // 避免"退出播放页即取消请求、永远加载不出来"的问题
    // 加载歌词（网易云官方直连 → 网易云搜索精确匹配 → LrcApi 兜底；统一简体）
    LaunchedEffect(song.platform, song.platformID) {
        lyrics = emptyList()
        lyricsSource = null
        lyricsLoading = true
        val r = runCatching { LyricsService.fetch(song) }.getOrNull()
        if (r != null && r.lines.isNotEmpty()) {
            lyrics = r.lines
            lyricsSource = r.source
        }
        lyricsLoading = false
    }

    // 外层：不透明主题渐变背景 → 全屏覆盖主界面，杜绝下层内容透出
    // 空白区域拦截点击，防止点击穿透到下层主界面
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1EDE2))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        // 水墨山水背景（播放页加深版）+ 纸色遮罩：氛围更强，歌词/封面区仍可读
        Image(
            painter = painterResource(R.drawable.ink_bg_player),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xDBFAF8F3),
                            Color(0x8CFAF8F3),
                            Color(0xD9F1EDE2)
                        )
                    )
                )
        )
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(p.glow, Color.Transparent), Offset(0.5f, 0f), 900f))
                // 背景保持全屏，内容避开状态栏与系统手势条
                .safeDrawingPadding()
        ) {
        // 系统自适应分档（跟随可用宽/高，横竖屏切换自动重组）；矮屏（手机横屏等）一律回退手机档
        val tier = when {
            maxWidth < 600.dp -> PlayerTier.COMPACT
            maxWidth < 840.dp -> if (maxHeight >= 900.dp) PlayerTier.MEDIUM else PlayerTier.COMPACT
            else -> if (maxHeight >= 600.dp) PlayerTier.EXPANDED else PlayerTier.COMPACT
        }
        // 手机：内容列上限 500dp 居中；平板两档：内容列固定 420dp 居中（B 单列收窄）
        Column(
            modifier = Modifier
                .then(
                    if (tier == PlayerTier.COMPACT) Modifier.fillMaxSize().widthIn(max = 500.dp)
                    else Modifier.width(tier.colWidth).fillMaxHeight()
                )
                .align(Alignment.TopCenter)
        ) {
            // 顶部：返回 + 标题 + 更多
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = if (tier == PlayerTier.COMPACT) 10.dp else 24.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButtonCompat(Icons.AutoMirrored.Filled.ArrowBack, "返回", onClick = onBack)
                Text(
                    "正在播放",
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = p.text2,
                    fontSize = 14.sp,
                    letterSpacing = 3.sp
                )
                IconButtonCompat(Icons.Filled.MoreVert, "更多", onClick = { toast("更多操作（演示）") })
            }

            // 主体区：封面/歌名/歌手/爱心 ↔ 大歌词，v2.1.5 #1a 改回纯渐变切换（用户：歌词双击后要渐变）
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center
            ) {
                AnimatedContent(
                    targetState = showLyrics,
                    transitionSpec = {
                        (fadeIn(tween(320, easing = FastOutSlowInEasing)))
                            .togetherWith(
                                fadeOut(tween(240, easing = FastOutSlowInEasing))
                            )
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    label = "cover-lyrics"
                ) { ly ->
                    if (ly) {
                        LyricsLargeView(
                            lines = lyrics,
                            source = lyricsSource,
                            loading = lyricsLoading,
                            position = position,
                            onToggle = { showLyrics = false }   // 双击歌词 → 渐变切回封面
                        )
                    } else {
                        PlayerCoverBlock(
                            song = song,
                            tier = tier,
                            showLyrics = showLyrics,
                            onToggle = { showLyrics = true }    // 双击封面 → 渐变切到大歌词
                        )
                    }
                }

                // 进度：墨线（干墨 1dp / 湿墨 3dp / 朱砂点），点按定位、可拖拽
                InkProgress(
                    position = position,
                    duration = duration,
                    onSeek = { PlayerManager.seekTo(it) }
                )

                Spacer(Modifier.height(tier.midSpacer))

                // 五件横排：循环 · 上一 · 朱砂印 · 下一 · 下载
                // 手机：两端对齐贴 24 边距；平板两档：列内居中整组、间距 32
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .then(if (tier.ctlCenter) Modifier.wrapContentWidth(Alignment.CenterHorizontally) else Modifier),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = if (tier.ctlCenter) Arrangement.spacedBy(tier.ctlGap) else Arrangement.SpaceBetween
                ) {
                    // 循环/随机：图标随档位每次换挡转满整圈，落角恒为 0°
                    val mode = AppState.playMode.value
                    val (modeIcon, modeLabel) = when (mode) {
                        PlayMode.SINGLE_LOOP -> Icons.Filled.RepeatOne to "单曲循环"
                        PlayMode.LIST_LOOP -> Icons.Filled.Repeat to "列表循环"
                        PlayMode.SHUFFLE -> Icons.Filled.Shuffle to "随机播放"
                    }
                    // v2.1.47：v2.1.38 的做法是「每换一档 += 120°」且永远累加、不归零，
                    // 三档落角因此变成 0° / 120° / 240°——其中两档对 Repeat / RepeatOne / Shuffle
                    // 都不是对称角，点完就停在斜角上，看着别扭。
                    // 改成每换一档 +360°（正好一个整圈），落角永远是 360 的整数倍＝正位；
                    // 旋转移到外层容器上，交叉淡入只管新旧图标，不再出现「两套图标各转一个角度」。
                    var modeRotTarget by remember { mutableStateOf(0f) }
                    var prevPlayMode by remember { mutableStateOf(mode) }
                    LaunchedEffect(mode) {
                        if (mode != prevPlayMode) {
                            prevPlayMode = mode
                            modeRotTarget += 360f
                        }
                    }
                    val modeRot by animateFloatAsState(
                        targetValue = modeRotTarget,
                        animationSpec = tween(300, easing = InkEaseOut),
                        label = "modeRot"
                    )
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        // v2.1.46：补足 44dp 最小点击区（不显底色，只放大热区）
                        modifier = Modifier
                            .widthIn(min = 44.dp)
                            .heightIn(min = 44.dp)
                            .inkClickable { AppState.cyclePlayMode() }
                    ) {
                        Box(
                            modifier = Modifier.rotate(modeRot),
                            contentAlignment = Alignment.Center
                        ) {
                            AnimatedContent(
                                targetState = modeIcon,
                                transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(120)) },
                                label = "modeIcon"
                            ) { mi ->
                                Icon(
                                    mi,
                                    contentDescription = null,
                                    tint = p.text2,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        AnimatedContent(
                            targetState = modeLabel,
                            transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(110)) },
                            label = "modeLabel"
                        ) { lb ->
                            Text(lb, color = p.accent2, fontSize = 12.sp, letterSpacing = 0.5.sp)
                        }
                    }

                    // 上一首：实心三角 + 竖杠
                    Box(
                        modifier = Modifier.size(44.dp).inkClickable { AppState.prevSong() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.SkipPrevious,
                            contentDescription = "上一首",
                            tint = p.accent,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 暂停 / 播放：56dp 朱砂方印（暂停双杠 / 播放三角）
                    PlaySeal(isPlaying = isPlaying, onClick = { PlayerManager.toggle() })

                    // 下一首
                    Box(
                        modifier = Modifier.size(44.dp).inkClickable { AppState.nextSong() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.SkipNext,
                            contentDescription = "下一首",
                            tint = p.accent,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // 下载
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        // v2.1.46：补足 44dp 最小点击区（不显底色，只放大热区）
                        modifier = Modifier
                            .widthIn(min = 44.dp)
                            .heightIn(min = 44.dp)
                            .inkClickable { showSheet = true }
                    ) {
                        Icon(
                            Icons.Filled.Download,
                            contentDescription = "下载",
                            tint = p.text2,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("下载", color = p.accent2, fontSize = 12.sp, letterSpacing = 0.5.sp)
                    }
                }

                // v2.1.47：状态行改成固定 20dp 占位。
                // 原来是 if (isResolving) 条件渲染——切歌时这行凭空出现 / 消失，
                // 会改掉主体 Column 的高度分配，把封面区 weight(1f) 的高度和画心边长一起带偏。
                Box(Modifier.fillMaxWidth().height(20.dp), contentAlignment = Alignment.Center) {
                    if (isResolving) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = p.accent, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("正在解析音源…", color = p.text3, fontSize = 12.sp)
                        }
                    } else if (resolveErr != null) {
                        Text(resolveErr, color = Color(0xFFC0392B), fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth())
                    } else if (playerErrorFlow != null) {
                        Text(playerErrorFlow!!, color = Color(0xFFC0392B), fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth())
                    }
                }

                // v2.1.7：音源来源提示条（来源/音质/格式/身份链路）——播放时可见真实音源；
                // 仅展示当前正在播放的这首（currentSourceSongKey 防错歌）
                // v2.1.47：改成固定占位——没有音源时留空字符串但高度照占，
                // 否则切歌瞬间这一行连同 srcTop / srcBottom 一起塌陷（平板档合计约 166dp）。
                val curSrc = if (AppState.currentSourceSongKey.value == songKey) AppState.currentSource.value else null
                Text(
                    text = if (curSrc == null) "" else
                        "音源：${curSrc.backendName} · ${curSrc.quality.displayName} · ${curSrc.format}" +
                            (if (curSrc.directId) " · ID 直连" else " · 搜索式已校验"),
                    color = p.text3,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 24.dp, top = tier.srcTop, bottom = tier.srcBottom)
                        .heightIn(min = 16.dp)
                )

            }   // 主体 Column 闭合
        }   // 内容列闭合
        }   // 主内容 Box（背景+避让）闭合

        // 下载弹层
        // v2.1.38：不再凭空出现——淡入 + 自下半屏上滑 260ms，退出 180ms 收走
        // （Modal 类规范 200–500ms；这里取 260 是为了与既有"丝滑慢速"手感同档）
        AnimatedVisibility(
            visible = showSheet,
            enter = fadeIn(tween(160)) + slideInVertically(tween(260, easing = InkEaseOut)) { it / 2 },
            exit = fadeOut(tween(150)) + slideOutVertically(tween(180, easing = InkEaseOut)) { it / 2 },
            label = "downloadSheet"
        ) {
            DownloadSheet(
                song = song,
                isDownloading = isDownloading,
                onCancel = { showSheet = false },
                onConfirm = { q ->
                    scope.launch {
                        isDownloading = true
                        // v2.1.48：不再"本平台随便拿一个凑合"。走 DownloadResolver——
                        // 本平台后端 → 跨平台换源（同歌名同歌手、排掉 live/综艺版）→ 仍然没有才降级，
                        // 并把"是否真的达到了目标档"带回来，让提示说得跟实际一致
                        val p = runCatching { DownloadResolver.resolve(song, q) }.getOrNull()
                        val s = p?.source
                        if (p != null && s != null) {
                            DownloadManager.startDownload(song, s)
                            val note = when {
                                p.exact && p.switched -> "（已换源：${s.platform.shortName}·${s.backendName}）"
                                p.exact -> ""
                                else -> "（该曲最高只有${s.quality.displayName}，已按此下载）"
                            }
                            toast("开始下载《${song.name}》${s.quality.displayName}${note}")
                        } else {
                            toast("暂无可用音源，请稍后重试")
                        }
                        isDownloading = false
                        showSheet = false
                    }
                }
            )
        }
    }
}

// ===== 封面区（白框装裱 + 方幅画心 + 横排题名/歌手 + 爱心；双击切大歌词）=====
// ===== v2.1.44：尺寸/间距全部走 tier 档位（该版「歌手行后留 weight 弹性」的做法已在 v2.1.46 移除）=====
// ===== v2.1.45：高度自适应（方案A）——已废弃：按常量估文字高、缺口超出上限即截断，iPad 上仍溢出压穿歌手行 =====
@Composable
private fun PlayerCoverBlock(
    song: Song,
    tier: PlayerTier,
    showLyrics: Boolean,
    onToggle: () -> Unit
) {
    val p = LocalPalette.current
    // ===== v2.1.46 布局重构（F1）：文字先占位、画心吃剩余 =====
    // v2.1.45 是「先按常量估文字高度，再把缺口压给画心」；缺口一旦超过可压缩上限就被截断，
    // 残余溢出因为 Column 不裁剪，直接画到进度条那条线上，把歌手行压穿（iPad 横屏实测约 16dp）。
    // v2.1.46 改成结构性保证：提示/题名/歌手在 Column 里是非 weight 子项，按自身真实高度测量、
    // 永不参与压缩；画心放进 weight(1f) 的剩余区，按当前可用高反算边长 —— 结构上不再存在溢出。
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val framePadV = 18.dp                 // 白框上下留白（单边）
        val framePadH = 14.dp                 // 白框左右留白（单边）
        val frameExtraV = framePadV * 2       // 上下内衬合计 36
        val frameExtraH = framePadH * 2       // 左右内衬合计 28

        // 高度越紧，三处文字间距越收（下限 6 / 6 / 2）；收的只是间距，文字本身不缩、不裁
        val tight = maxHeight < 460.dp
        val hintGap = if (tight) 6.dp else tier.hintGap
        val titleGap = if (tight) 6.dp else tier.titleGap
        val artistGap = if (tight) 2.dp else tier.artistGap
        // 顶部留白跟着可用高走（不超过可用高的 10%），不再固定吃掉 120dp
        val topGap = minOf(tier.topGap, maxHeight * 0.10f)

        Column(
            modifier = Modifier.fillMaxSize().clipToBounds(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // 画心区：吃掉「文字区之外」的全部高度
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = topGap),
                contentAlignment = Alignment.Center
            ) {
                BoxWithConstraints {
                    // 三处约束取最小：档位期望 / 白框宽上限 / 当前可用高（第三项保证永不越界）
                    val art = minOf(tier.art, tier.frameW - frameExtraH, maxHeight - frameExtraV)
                        .coerceAtLeast(0.dp)

                    // 白框：宽度随画心等比（左右各 14 内衬），1dp 界栏，四角方正（照片裱框语汇）
                    Box(
                        modifier = Modifier
                            .width(art + frameExtraH)
                            .background(p.surface)
                            .border(1.dp, Color(0xFFDED7C8))
                            .padding(vertical = framePadV, horizontal = framePadH),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(art)
                                .pointerInput(Unit) {
                                    // 约定交互：仅双击封面切换大歌词；单击不响应
                                    detectTapGestures(onDoubleTap = { onToggle() })
                                }
                        ) {
                            SongCover(song = song, size = art, corner = 0.dp)
                            // 内阴影（纸色向内渗）+ 1px 墨线：让封面陷进纸里，而不是贴上去
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .drawBehind {
                                        drawRect(
                                            brush = Brush.radialGradient(
                                                colors = listOf(Color.Transparent, Color(0x5CFAF8F3)),
                                                center = center,
                                                radius = size.maxDimension * 0.72f
                                            )
                                        )
                                        drawRect(color = Color(0x172E2A24), style = Stroke(1f))
                                    }
                            )
                        }
                    }
                }
            }

            // 封面提示：白框下方一行小字（始终保留——它是歌词入口的唯一说明，矮屏也不藏）
            Text(
                "双击封面看歌词",
                color = Color(0xFF8A8172),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = hintGap)
            )

            // 题名：tier 字号马善政左起，右端收藏
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = titleGap),
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    song.name,
                    color = p.text,
                    fontSize = tier.titleSp,
                    lineHeight = tier.titleLh,
                    letterSpacing = 2.sp,
                    fontFamily = InkTitleFont,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                PlayerFavBtn(song)
            }

            // 歌手 · 专辑：单行省略，不换行、不挤占下方；底部留 6dp 呼吸，与进度条分家
            Text(
                song.singer + (if (song.album.isNotBlank()) " · " + song.album else ""),
                color = p.text2,
                fontSize = tier.artistSp,
                letterSpacing = 0.8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 24.dp, top = artistGap, bottom = 6.dp)
            )
        }
    }
}

// ===== 大歌词视图（占播放控制栏上方全部空间；当前行滚动高亮；双击/单击切回封面）=====
@Composable
private fun LyricsLargeView(
    lines: List<LyricLine>,
    source: String?,
    loading: Boolean,
    position: Long,
    onToggle: () -> Unit
) {
    val p = LocalPalette.current
    val listState = rememberLazyListState()
    val hl = LyricsService.indexAt(lines, position)

    // 跟唱滚动（网易云同款实现）：歌词列表上下各加“半个视口高度”的空白占位，
    // 滚动到当前行 index（顶部对齐）后，当前行恰好出现在视口正中间。
    // 旧实现依赖 layoutInfo 计算偏移，歌词不足一屏时无法滚动导致当前行停留在顶部。
    LaunchedEffect(hl) {
        if (hl >= 0) {
            // 等一帧确保列表完成首次布局，再平滑滚动到当前行
            withFrameNanos { }
            listState.animateScrollToItem(hl)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .pointerInput(Unit) {
                // 约定交互：仅双击歌词切回封面；单击不响应
                detectTapGestures(
                    onDoubleTap = { onToggle() }
                )
            }
    ) {
        if (lines.isNotEmpty()) {
            val halfVh = maxHeight / 2
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(vertical = halfVh)
            ) {
                items(lines.size) { i ->
                    val line = lines[i]
                    val active = i == hl
                    // 当前行：明显变大+变色（tween 320ms 平滑）；唱过后恢复原样
                    val fontSize by animateFloatAsState(
                        targetValue = if (active) 22f else 14f,
                        animationSpec = tween(320),
                        label = "lyricSize"
                    )
                    val textColor by animateColorAsState(
                        targetValue = if (active) p.accent2 else p.text3.copy(alpha = 0.45f),
                        animationSpec = tween(320),
                        label = "lyricColor"
                    )
                    Text(
                        line.text.ifBlank { " " },
                        color = textColor,
                        fontSize = fontSize.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = if (active) 9.dp else 6.dp)
                    )
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        loading -> "歌词加载中…"
                        source != null -> "暂无歌词（$source）"
                        else -> "暂无歌词"
                    },
                    color = p.text3,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ===== 播放页爱心（右侧进度条上方；空心↔实心，直接读响应式事实源，与悬浮栏/列表全联动）=====
@Composable
private fun PlayerFavBtn(song: Song) {
    val p = LocalPalette.current
    val fav = HistoryStore.isFavorite(song)
    Box(
        modifier = Modifier
            .size(44.dp)
            .clickable { HistoryStore.toggleFavorite(song) },
        contentAlignment = Alignment.Center
    ) {
        // v2.1.38：与列表行共用 InkHeart（溶形 + 弹出），三处心形语言统一
        InkHeart(
            fav = fav,
            size = 26.dp,
            tintOn = p.heartOn,
            tintOff = p.text3.copy(alpha = 0.9f)
        )
    }
}

// ===== 下载弹层：三档音质 + 单个开始下载按钮（隐藏来源，内部按音质自动匹配）=====
@Composable
private fun DownloadSheet(
    song: Song,
    isDownloading: Boolean,
    onCancel: () -> Unit,
    onConfirm: (QualityLevel) -> Unit
) {
    val p = LocalPalette.current
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }
    // v2.1.48：去掉下载前的三档预检（用户口径：没必要）。
    // 原来那套预检只判断"有没有源"、从不看源的音质，所以必然出现"无损档亮着、点下去却降级"；
    // 现在三档一律可点，由 DownloadResolver 在真正下载时解析——拿不到目标档就跨源换源，
    // 全部拿不到再降级，并把实际下到的档位如实告诉用户。

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(enabled = !isDownloading, onClick = onCancel),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .padding(horizontal = 22.dp, vertical = 18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("下载歌曲", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = InkTitleFont, modifier = Modifier.weight(1f))
                // v2.1.40：热区 32→44dp 并补墨色按压——这是下载弹层里唯一没有反馈的钮
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .inkClickable(enabled = !isDownloading) { onCancel() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "取消",
                        tint = p.text3,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(song.name + " · " + song.singer, color = p.text2, fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QualityLevel.entries.forEach { q ->
                    val selected = quality == q
                    // v2.1.48：三档不再按"有没有源"置灰——预检已移除，可点性只取决于是否正在下载
                    val colColor by animateColorAsState(
                        targetValue = if (selected) p.accent.copy(alpha = 0.16f) else p.surface2,
                        animationSpec = tween(180, easing = FastOutSlowInEasing),
                        label = "qualityBg"
                    )
                    val colText by animateColorAsState(
                        targetValue = if (selected) p.accent2 else p.text2,
                        animationSpec = tween(180, easing = FastOutSlowInEasing),
                        label = "qualityText"
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(colColor, RoundedCornerShape(12.dp))
                            .clickable(enabled = !isDownloading) { quality = q }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            q.displayName,
                            color = colText,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            // v2.1.48：预检移除后不再有"检测中 / 请选择可用音质"这两种状态。
            // 这一行只负责在动手之前把规则讲清楚，取代原先"先亮后降级"的欺骗感
            Text(
                "拿不到所选音质会自动换源，仍然没有就按可得的最高档下载",
                color = p.text3,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(14.dp))

            // v2.1.40：按钮底色从灰到朱砂走 180ms 过渡；内部"开始下载 ↔ 转圈"用 160ms 交叉——
            // 原先这两次硬切都落在同一处，按下瞬间最刺眼
            // v2.1.48：可点性只取决于"是否正在下载"——预检去掉后不存在"某档不可用"这种状态
            val btnReady = !isDownloading
            val btnBg by animateColorAsState(
                targetValue = if (btnReady) p.accent else p.surface2,
                animationSpec = tween(180, easing = FastOutSlowInEasing),
                label = "confirmBg"
            )
            val btnText = Color(0xFFF7F5F0)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(btnBg, RoundedCornerShape(14.dp))
                    .clickable(enabled = btnReady) { onConfirm(quality) }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Crossfade(
                    targetState = isDownloading,
                    animationSpec = tween(160, easing = FastOutSlowInEasing),
                    label = "confirmContent"
                ) { downloading ->
                    if (downloading) {
                        // 跨源换源可能要跑十几秒，必须让用户看见"在做事情"而不是一个无字的转圈
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFFF7F5F0), strokeWidth = 2.dp)
                            Text("正在解析音源…", color = Color(0xFFF7F5F0), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Text(
                            "开始下载",
                            color = btnText,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

// ===== 通用小组件（#7：统一水墨按压反馈）=====
@Composable
private fun IconButtonCompat(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(40.dp)
            .inkClickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = p.text2, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun IconBtnLarge(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(48.dp)
            .inkClickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = p.text2, modifier = Modifier.size(32.dp))
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = ms / 1000
    return String.format("%02d:%02d", totalSec / 60, totalSec % 60)
}

// 简易 toast（不依赖系统 Toast 也能在 Compose 内提示）
private var toastText = mutableStateOf<String?>(null)
private var toastJob: kotlinx.coroutines.Job? = null
fun toast(msg: String) {
    toastText.value = msg
    toastJob?.cancel()
    toastJob = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
        kotlinx.coroutines.delay(1800)
        toastText.value = null
    }
}

// v2.1.38：与 App.kt 山水 wipe 同源的 strong ease-out（cubic-bezier(.23,1,.32,1)）
// （App.kt 里的同名常量是 private，跨文件不可见，此处独立声明）
private val InkEaseOut = CubicBezierEasing(0.23f, 1f, 0.32f, 1f)

@Composable
fun ToastHost() {
    val p = LocalPalette.current
    val msg = toastText.value
    // 退出动画期间内容不能瞬间变空，否则 exit 在空容器上空跑、观感等于"没有退出"
    var lastMsg by remember { mutableStateOf("") }
    LaunchedEffect(msg) { if (msg != null) lastMsg = msg }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        // v2.1.38：TOAST 不再凭空出现/消失——进入从下方 1/3 处浮起 220ms，退出 140ms 收走
        // （系统响应快于主动呈现：出比进短，符合非对称时长）
        AnimatedVisibility(
            visible = msg != null,
            enter = fadeIn(tween(180)) + slideInVertically(tween(220, easing = InkEaseOut)) { it / 3 },
            exit = fadeOut(tween(130)) + slideOutVertically(tween(140, easing = InkEaseOut)) { -it / 4 },
            label = "toast"
        ) {
            Text(
                lastMsg,
                color = Color(0xFFF7F5F0),
                fontSize = 13.sp,
                modifier = Modifier
                    .background(Color(0xE62E2A24), RoundedCornerShape(percent = 50))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }
    }
}

// ===== 播放页进度：墨线（干墨 1dp / 湿墨 3dp / 朱砂点 8dp），点按定位 + 拖拽 =====
@Composable
private fun InkProgress(position: Long, duration: Long, onSeek: (Long) -> Unit) {
    val p = LocalPalette.current
    // 拖拽中只更新本地预览比例，松手才真正 seek —— 避免拖动过程反复跳音
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    val frac = dragFrac
        ?: if (duration > 0) (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f

    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(9.dp)
                .pointerInput(duration) {
                    if (duration <= 0) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        dragFrac = (down.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        down.consume()
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) break
                            dragFrac = (ch.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                            ch.consume()
                        }
                        dragFrac?.let { f -> onSeek((f * duration).toLong()) }
                        dragFrac = null
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cy = size.height / 2f
                drawLine(
                    color = Color(0xFFC9C2B2),
                    start = Offset(0f, cy),
                    end = Offset(size.width, cy),
                    strokeWidth = 1.dp.toPx()
                )
                if (frac > 0f) {
                    val w = size.width * frac
                    drawRoundRect(
                        color = Color(0xFF2E2A24),
                        topLeft = Offset(0f, cy - 1.5.dp.toPx()),
                        size = Size(w, 3.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFFB03A2E),
                        radius = 4.dp.toPx(),
                        center = Offset(w, cy)
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 11.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(position), color = p.text3, fontSize = 11.sp, letterSpacing = 0.5.sp)
            Text(formatTime(duration), color = p.text3, fontSize = 11.sp, letterSpacing = 0.5.sp)
        }
    }
}

// ===== 播放页暂停/播放：56dp 朱砂方印（v2.1.46 圆角 3→14，方印骨相保留、四角收圆），暂停为双杠、播放为三角 =====
@Composable
private fun PlaySeal(isPlaying: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFB03A2E))
            .inkClickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        // v2.1.38：两态不硬替换——0.82 起缩 + 交叉淡入（不从 scale(0) 起）
        AnimatedContent(
            targetState = isPlaying,
            transitionSpec = {
                (scaleIn(initialScale = 0.82f) + fadeIn(tween(160, easing = InkEaseOut)))
                    .togetherWith(scaleOut(targetScale = 0.82f) + fadeOut(tween(120)))
            },
            label = "playPause"
        ) { playing ->
            if (playing) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.width(3.dp).height(18.dp).background(Color(0xFFFDFCF9)))
                    Box(Modifier.width(3.dp).height(18.dp).background(Color(0xFFFDFCF9)))
                }
            } else {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "播放",
                    tint = Color(0xFFFDFCF9),
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}
