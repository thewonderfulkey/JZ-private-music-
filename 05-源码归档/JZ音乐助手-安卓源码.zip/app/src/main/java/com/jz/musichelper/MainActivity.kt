package com.jz.musichelper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.ui.App

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadManager.init(this)
        PlayerManager.init(this)
        enableEdgeToEdge()
        setContent {
            App()
        }
    }
}
