package com.jz.musichelper

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.ui.App
import java.io.File
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 全局兜底：任何未预期异常写入 crash.log 与偏好（设置页可查诊断），不弹窗、不杀进程
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val f = File(filesDir, "crash.log")
                f.appendText("===== ${Date()} [${thread.name}] =====\n$throwable\n")
                throwable.stackTrace?.forEach { f.appendText("    at $it\n") }
                f.appendText("\n")
                // 同步到偏好，供设置页"异常诊断"直接展示
                val stack = throwable.stackTrace?.take(10)?.joinToString("\n") { "    at $it" } ?: ""
                getSharedPreferences("jz_music_prefs", MODE_PRIVATE)
                    .edit()
                    .putString("last_error", "$throwable\n$stack")
                    .putLong("last_error_time", System.currentTimeMillis())
                    .apply()
            } catch (_: Exception) {
            }
        }
        DownloadManager.init(this)
        PlayerManager.init(this)
        // v2.1.67：自动连播/换源监听挂到应用级（不依赖 Compose 组合与屏幕帧），息屏后照常切歌
        com.jz.musichelper.ui.AppState.startAutoContinue()
        // v2.1.5 #5：Android 13+ 请求通知权限（前台服务常驻通知需要；拒绝不影响播放与连播保活）
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            runCatching { requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100) }
        }
        enableEdgeToEdge()
        setContent {
            App()
        }
    }
}
