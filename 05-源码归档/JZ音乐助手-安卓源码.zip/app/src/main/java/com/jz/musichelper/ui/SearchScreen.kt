package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.Song
import com.jz.musichelper.network.SearchService
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(modifier: Modifier = Modifier) {
    var keyword by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<SearchService.PlatformResult>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = modifier.fillMaxSize()) {
        // 搜索栏
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = keyword,
                onValueChange = { keyword = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("搜索歌曲（如：晴天 周杰伦）") },
                singleLine = true,
                trailingIcon = {
                    if (keyword.isNotEmpty()) {
                        IconButton(onClick = { keyword = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "清空")
                        }
                    }
                }
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    val kw = keyword.trim()
                    if (kw.isEmpty()) return@Button
                    isSearching = true
                    searched = true
                    HistoryStore.recordSearch(kw)
                    scope.launch {
                        results = SearchService.searchAll(kw)
                        isSearching = false
                    }
                },
                enabled = keyword.isNotBlank() && !isSearching
            ) {
                if (isSearching) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("搜索")
                }
            }
        }

        // 平台状态行
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MusicPlatform.entries.forEach { p ->
                val pr = results.firstOrNull { it.platform == p }
                val color = when {
                    isSearching -> Color(0xFFF59E0B)
                    pr == null -> Color(0x66000000)
                    pr.songs.isNotEmpty() -> Color(0xFF22C55E)
                    pr.error != null -> Color(0xFFEF4444)
                    else -> Color(0xFF9CA3AF)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .background(color, CircleShape)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(p.shortName, fontSize = 12.sp, color = Color(0xFF666666))
                }
            }
            Spacer(Modifier.weight(1f))
        }

        // 结果列表
        when {
            searched && !isSearching && results.all { it.songs.isEmpty() } -> {
                EmptyState("没有找到结果", "换个关键词试试")
            }
            results.isEmpty() && !isSearching -> {
                EmptyState("输入关键词开始搜索", "支持 QQ / 网易 / 酷我 / 酷狗")
            }
            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    results.forEach { pr ->
                        if (pr.songs.isNotEmpty()) {
                            item(key = "header_${pr.platform.name}") {
                                Text(
                                    "${pr.platform.displayName}（${pr.songs.size}）",
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 2.dp),
                                    color = Color(0xFF444444)
                                )
                            }
                            items(pr.songs, key = { "${pr.platform.name}_${it.platformID}" }) { song ->
                                SongRow(song) { AppState.currentSong.value = it }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SongRow(song: Song, onClick: (Song) -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick(song) },
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFEEEEEE),
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    modifier = Modifier.padding(10.dp),
                    tint = Color(0xFF888888)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(song.name, fontWeight = FontWeight.Medium, maxLines = 1)
                Text(
                    song.singer,
                    fontSize = 13.sp,
                    color = Color(0xFF888888),
                    maxLines = 1
                )
            }
            Text(
                song.platform.shortName,
                fontSize = 11.sp,
                color = Color(0xFF1E88E5),
                modifier = Modifier
                    .background(
                        Color(0xFF1E88E5).copy(alpha = 0.12f),
                        RoundedCornerShape(50)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(song.durationText, fontSize = 12.sp, color = Color(0xFF999999))
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.MusicNote,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = Color(0xFFBBBBBB)
        )
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Color(0xFF888888))
    }
}
