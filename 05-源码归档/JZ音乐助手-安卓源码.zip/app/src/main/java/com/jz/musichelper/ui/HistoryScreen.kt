package com.jz.musichelper.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore

@Composable
fun HistoryScreen(modifier: Modifier = Modifier) {
    // 每次进入本页时重新读取（tab 切换会重组）
    val searchHistory = HistoryStore.loadSearchHistory()
    val recentSongs = HistoryStore.loadRecentSongs()

    LazyColumn(modifier = modifier.fillMaxSize()) {
        if (searchHistory.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("搜索历史", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { HistoryStore.clearSearchHistory() }) {
                        Text("清空")
                    }
                }
            }
            items(searchHistory, key = { it.keyword }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF999999))
                    Spacer(Modifier.width(8.dp))
                    Text(item.keyword)
                }
            }
        }

        if (recentSongs.isNotEmpty()) {
            item {
                Text(
                    "最近查看",
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
            items(recentSongs, key = { "${it.platform.name}_${it.platformID}" }) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { AppState.currentSong.value = song }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp),
                        color = Color(0xFFEEEEEE),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.padding(8.dp), tint = Color(0xFF888888))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.name, maxLines = 1)
                        Text(song.singer, fontSize = 12.sp, color = Color(0xFF888888), maxLines = 1)
                    }
                    Text(song.platform.shortName, fontSize = 11.sp, color = Color(0xFF1E88E5))
                }
            }
        }

        if (searchHistory.isEmpty() && recentSongs.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 80.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(56.dp), tint = Color(0xFFBBBBBB))
                    Spacer(Modifier.height(12.dp))
                    Text("暂无历史记录", color = Color(0xFF888888))
                }
            }
        }
    }
}
