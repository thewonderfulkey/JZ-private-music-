package com.jz.musichelper.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// 统一 HTTP GET 客户端：移动 UA + Referer + 超时
object ApiClient {

    const val MOBILE_UA =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** GET 返回原始文本 */
    fun get(url: String, headers: Map<String, String> = emptyMap(), timeoutSec: Long = 15): String {
        val builder = Request.Builder().url(url)
            .header("User-Agent", MOBILE_UA)
            .header("Accept", "application/json, text/javascript, */*; q=0.01")
            .header("Referer", "https://music.qq.com/")
            .header("Connection", "close")
        headers.forEach { (k, v) -> builder.header(k, v) }
        val req = builder.build()
        val okClient = if (timeoutSec != 15L) {
            client.newBuilder().readTimeout(timeoutSec, TimeUnit.SECONDS).build()
        } else client
        okClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiError.HTTP(resp.code)
            return resp.body?.string() ?: ""
        }
    }

    /** GET 解析为 JSONObject */
    fun getJson(url: String, headers: Map<String, String> = emptyMap(), timeoutSec: Long = 15): JSONObject {
        return JSONObject(get(url, headers, timeoutSec))
    }

    /** GET 解析为 JSONArray */
    fun getJsonArray(url: String, headers: Map<String, String> = emptyMap(), timeoutSec: Long = 15): JSONArray {
        return JSONArray(get(url, headers, timeoutSec))
    }
}

sealed class ApiError : Exception() {
    class HTTP(val code: Int) : ApiError()
    class Parse(val msg: String) : ApiError()
    object Timeout : ApiError()
}
