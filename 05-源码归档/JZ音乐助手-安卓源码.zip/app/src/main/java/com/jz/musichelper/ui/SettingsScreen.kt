package com.jz.musichelper.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.model.QualityLevel

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }

    Column(modifier = modifier
        .fillMaxSize()
        .padding(16.dp)) {

        Text("下载设置", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text("默认音质", fontSize = 14.sp, color = Color(0xFF444444))
        Spacer(Modifier.height(4.dp))
        QualityLevel.entries.forEach { q ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            ) {
                RadioButton(
                    selected = quality == q,
                    onClick = {
                        quality = q
                        HistoryStore.saveQuality(q)
                    }
                )
                Text(q.displayName, fontSize = 14.sp)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("保存位置", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = Color(0xFFF5F5F5),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("下载的音乐保存在系统媒体库：", fontSize = 13.sp, color = Color(0xFF666666))
                Text("Music / JZ音乐助手", fontSize = 13.sp, color = Color(0xFF1E88E5), fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("可在「音乐」或「文件」App 中查看，支持导入其他播放器。", fontSize = 12.sp, color = Color(0xFF999999))
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("数据管理", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = Color(0xFFF5F5F5),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "清空搜索历史",
                    fontSize = 14.sp,
                    color = Color(0xFFD32F2F),
                    modifier = Modifier
                        .clickable { HistoryStore.clearSearchHistory() }
                        .padding(vertical = 6.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("关于", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = Color(0xFFF5F5F5),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("JZ的音乐助手 v1.0", fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "音乐源为第三方接口聚合（酷我/QQ/网易/酷狗系），仅供个人学习测试，请支持正版音乐。接口为实测可用状态，随时可能失效。",
                    fontSize = 12.sp,
                    color = Color(0xFF999999)
                )
            }
        }
    }
}
