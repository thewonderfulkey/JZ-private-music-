package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.ui.theme.InkTitleFont
import com.jz.musichelper.ui.theme.LocalPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ===== 设置页：音质 + 主题（水墨单主题展示）+ 数据管理 + 关于 =====
@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        // 左上角返回按钮 + 标题
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(p.accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                    .inkClickable { AppState.tab.value = MainTab.HOME },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "返回",
                    tint = p.accent2,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                "设置",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = InkTitleFont,
                color = p.text,
                modifier = Modifier.padding(start = 8.dp, top = 6.dp)
            )
        }

        // 主题（水墨 · 简约山水：全 App 统一水墨风格，无切换）
        Text("主题外观", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0x2E2E2A24), Color(0x002E2A24)),
                            radius = 500f
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(12.dp).background(p.accent, CircleShape))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("水墨 · 简约山水", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("米白纸底 · 墨色点缀（参考概念图 v2 第 5 格）", color = p.text3, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(20.dp))

        // 下载设置
        Text("下载设置", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(6.dp))
        Text("默认音质", color = p.text2, fontSize = 13.sp)
        QualityLevel.entries.forEach { q ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                RadioButton(
                    selected = quality == q,
                    onClick = {
                        quality = q
                        HistoryStore.saveQuality(q)
                    },
                    colors = RadioButtonDefaults.colors(selectedColor = p.accent, unselectedColor = p.text3)
                )
                Text(q.displayName, color = p.text, fontSize = 14.sp)
                if (q == QualityLevel.HIGH || q == QualityLevel.LOSSLESS) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (q == QualityLevel.HIGH) "320k" else "FLAC",
                        color = p.text3,
                        fontSize = 11.sp
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))

        // 保存位置
        Text("保存位置", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("下载的音乐保存在系统媒体库：", color = p.text2, fontSize = 13.sp)
            Text("Music / JZ音乐助手", color = p.accent2, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text("可在「音乐」或「文件」App 中查看，支持导入其他播放器。", color = p.text3, fontSize = 12.sp)
        }
        Spacer(Modifier.height(20.dp))

        // 数据管理
        Text("数据管理", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text(
                "清空搜索历史",
                fontSize = 14.sp,
                color = Color(0xFFC0392B),
                modifier = Modifier
                    .inkClickable {
                        HistoryStore.clearSearchHistory()
                        toast("已清空搜索历史")
                    }
                    .padding(vertical = 12.dp)
            )
        }
        Spacer(Modifier.height(20.dp))

        // 异常诊断（全局未捕获异常在此展示，方便反馈根因）
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val lastError = remember {
            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                .getString("last_error", null)
        }
        val lastErrorTime = remember {
            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                .getLong("last_error_time", 0L)
        }
        if (lastError != null) {
            Text("异常诊断", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
            Spacer(Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(p.surface2, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Text(
                    "最近一次未捕获异常：" + if (lastErrorTime > 0)
                        SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(lastErrorTime))
                    else "时间未知",
                    fontSize = 12.sp,
                    color = p.text,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    lastError,
                    fontSize = 10.sp,
                    color = p.text2,
                    maxLines = 14
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "将以上内容发给开发者即可定位问题；点击下方按钮可清空。",
                    fontSize = 11.sp,
                    color = p.text3
                )
                Text(
                    "清空诊断",
                    fontSize = 13.sp,
                    color = Color(0xFFC0392B),
                    modifier = Modifier
                        .inkClickable {
                            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                                .edit().remove("last_error").apply()
                        }
                        .padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
        }

        // 关于
        Text("关于", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("JZ的音乐助手 v2.1.62", fontSize = 14.sp, color = p.text)
            Spacer(Modifier.height(6.dp))
            Text(
                "v2.1.62：首页板块顺序调整，自上而下改为 编辑精选 → 最近播放 → 猜你喜欢 → 热门音乐（热门音乐整块移到最后）。热门音乐的分页不变：一页 3 首、左右滑动、共 7 页 21 首。v2.1.61：热门音乐改成和「猜你喜欢」完全一样的分页——一页 3 首、左右滑动翻页，共 7 页 21 首（取歌曲数 20→21）；切底部 Tab 时新旧两页叠印已修，每页铺不透明纸底。v2.1.60：热门音乐行去掉序号列，封面 44→48dp、圆角 8→10，行高与「猜你喜欢」对齐。v2.1.59：首页改版——封面原色直出（撤掉饱和 72% + 暖偏 + 16% 纸色蒙版）；首页 0 处具象山水（品牌区山水背景、搜索框水墨横幅、精选卡海报、全局底图全部撤下），山水只在播放页保留一幅；书法体只留品牌题字一处，歌名/列表/按钮改无衬线；搜索栏改白底真输入框；弱文字对比度压深到 4.8:1。v2.1.58：「跳过」下移 40dp，与「高山流水」四字同一水平线（原来整整高出一行标题）。v2.1.57：远山雾带那一条（中部偏右的山脊）改成跟山体同一道墨前推进，不再提前浮出；「跳过」加大加深（26→34dp 高、字 10.5→13sp、纸底与墨字提高对比，外面加 44dp 点击热区）。v2.1.56：收尾改成音符缩小 + 音符放大两段；v2.1.55：收尾提速、去掉长时间黑屏；v2.1.54：首帧改整屏空白纸、收尾由整屏渐变改为音符开口。",
                fontSize = 12.sp,
                color = p.text2
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "音乐源为第三方接口聚合（酷我/QQ/网易系），仅供个人学习测试，请支持正版音乐。接口为实测可用状态，随时可能失效。",
                fontSize = 12.sp,
                color = p.text3
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
