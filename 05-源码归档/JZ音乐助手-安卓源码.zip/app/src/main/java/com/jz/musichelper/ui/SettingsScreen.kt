package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.ui.theme.InkTitleFont
import com.jz.musichelper.ui.theme.LocalPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ===== 设置页：音质 + 主题（水墨单主题展示）+ 数据管理 + 关于 =====
@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }

    // v2.1.66：底部留白与播放悬浮栏同一口径——悬浮栏高度 = 屏宽 1/5（约 82dp），
    // 出现时留 96dp（栏高 + 14dp 呼吸），未出现时留 60dp（与其他列表页一致），末行不再被压住
    val playerShown = AppState.lastSong.value != null
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, bottom = if (playerShown) 96.dp else 60.dp)
    ) {
        // 左上角返回按钮 + 标题
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(p.accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                    .inkClickable { AppState.tab.value = MainTab.HOME },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "返回",
                    tint = p.accent2,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                "设置",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = InkTitleFont,
                color = p.text,
                modifier = Modifier.padding(start = 8.dp, top = 6.dp)
            )
        }

        // 主题（水墨 · 简约山水：全 App 统一水墨风格，无切换）
        Text("主题外观", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0x2E2E2A24), Color(0x002E2A24)),
                            radius = 500f
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(12.dp).background(p.accent, CircleShape))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("水墨 · 简约山水", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("米白纸底 · 墨色点缀（参考概念图 v2 第 5 格）", color = p.text3, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(20.dp))

        // 下载设置
        Text("下载设置", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(6.dp))
        Text("默认音质", color = p.text2, fontSize = 13.sp)
        QualityLevel.entries.forEach { q ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                RadioButton(
                    selected = quality == q,
                    onClick = {
                        quality = q
                        HistoryStore.saveQuality(q)
                    },
                    colors = RadioButtonDefaults.colors(selectedColor = p.accent, unselectedColor = p.text3)
                )
                Text(q.displayName, color = p.text, fontSize = 14.sp)
                if (q == QualityLevel.HIGH || q == QualityLevel.LOSSLESS) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (q == QualityLevel.HIGH) "320k" else "FLAC",
                        color = p.text3,
                        fontSize = 11.sp
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))

        // 保存位置
        Text("保存位置", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("下载的音乐保存在系统媒体库：", color = p.text2, fontSize = 13.sp)
            Text("Music / JZ音乐助手", color = p.accent2, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text("可在「音乐」或「文件」App 中查看，支持导入其他播放器。", color = p.text3, fontSize = 12.sp)
        }
        Spacer(Modifier.height(20.dp))

        // 数据管理
        Text("数据管理", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text(
                "清空搜索历史",
                fontSize = 14.sp,
                color = Color(0xFFC0392B),
                modifier = Modifier
                    .inkClickable {
                        HistoryStore.clearSearchHistory()
                        toast("已清空搜索历史")
                    }
                    .padding(vertical = 12.dp)
            )
        }
        Spacer(Modifier.height(20.dp))

        // 异常诊断（全局未捕获异常在此展示，方便反馈根因）
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val lastError = remember {
            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                .getString("last_error", null)
        }
        val lastErrorTime = remember {
            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                .getLong("last_error_time", 0L)
        }
        if (lastError != null) {
            Text("异常诊断", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
            Spacer(Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(p.surface2, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Text(
                    "最近一次未捕获异常：" + if (lastErrorTime > 0)
                        SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(lastErrorTime))
                    else "时间未知",
                    fontSize = 12.sp,
                    color = p.text,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    lastError,
                    fontSize = 10.sp,
                    color = p.text2,
                    maxLines = 14
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "将以上内容发给开发者即可定位问题；点击下方按钮可清空。",
                    fontSize = 11.sp,
                    color = p.text3
                )
                Text(
                    "清空诊断",
                    fontSize = 13.sp,
                    color = Color(0xFFC0392B),
                    modifier = Modifier
                        .inkClickable {
                            ctx.getSharedPreferences("jz_music_prefs", android.content.Context.MODE_PRIVATE)
                                .edit().remove("last_error").apply()
                        }
                        .padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
        }

        // 关于
        Text("关于", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface2, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text("JZ的音乐助手 v2.1.67", fontSize = 14.sp, color = p.text)
            Spacer(Modifier.height(6.dp))
            Text("本版更新", fontSize = 12.sp, color = p.text3)
            Spacer(Modifier.height(3.dp))
            Text(
                "修息屏后播完不自动切歌：自动连播的监听从界面动画线程搬到应用级，并给前台播放服务加 CPU 保活锁；" +
                    "上版改动：下载列表只留档位标签、关于页换成声明。",
                fontSize = 12.sp,
                color = p.text2
            )
            Spacer(Modifier.height(10.dp))
            Text("声明", fontSize = 12.sp, color = p.text3)
            Spacer(Modifier.height(3.dp))
            Text(
                "1. 音乐源为酷我 / QQ / 网易等第三方接口的聚合结果，仅供个人学习与测试，请支持正版音乐。\n" +
                    "2. 本应用不存储、不传播任何音频文件，仅提供检索、试听与本地缓存。\n" +
                    "3. 曲库版权与接口可用性随时变化，个别歌曲缺少某档音质属正常现象。",
                fontSize = 12.sp,
                color = p.text2,
                lineHeight = 18.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
