package com.jz.musichelper.network

import com.jz.musichelper.model.MusicPlatform
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import okhttp3.Request
import org.json.JSONObject
import java.util.Random

// 轻量校验：Range GET 检查候选 URL 返回的是音频而非 HTML 落地页
object StreamVerifier {
    fun isAudioUrl(urlString: String, timeoutSec: Long = 8): Boolean {
        return try {
            val req = Request.Builder()
                .url(urlString)
                .header("Range", "bytes=0-4095")
                .header("User-Agent", ApiClient.MOBILE_UA)
                .header("Referer", "https://music.qq.com/")
                .build()
            ApiClient.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful && resp.code != 206) return false
                val ct = resp.header("Content-Type") ?: ""
                !ct.lowercase().contains("text/html")
            }
        } catch (_: Exception) {
            false
        }
    }
}

// 取流后端：给定歌曲与音质，返回可用流地址
interface StreamSourceAdapter {
    val name: String
    val platform: MusicPlatform
    suspend fun resolve(song: Song, quality: QualityLevel): StreamSource
}

// ---------- 酷我系 ----------

// haitangw 酷我直链
class HaitangKuwoAdapter : StreamSourceAdapter {
    override val name = "haitangw 酷我"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val level = quality.levelName()
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://musicapi.haitangw.net/music/kw.php?type=mp3&id=${song.platformID}&level=$level"
        if (!StreamVerifier.isAudioUrl(url)) throw ApiError.HTTP(0)
        return StreamSource(url, name, platform, quality, format, "320k MP3 全量")
    }
}

// nxinxz 酷我直链
class NxinxzKuwoAdapter : StreamSourceAdapter {
    override val name = "nxinxz 酷我"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val level = quality.levelName()
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://music.nxinxz.com/kw.php?id=${song.platformID}&level=$level&type=mp3"
        if (!StreamVerifier.isAudioUrl(url)) throw ApiError.HTTP(0)
        return StreamSource(url, name, platform, quality, format, "320k MP3 全量")
    }
}

// oiapi 酷我（搜索式）
class OiapiKuwoAdapter : StreamSourceAdapter {
    override val name = "oiapi 酷我"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val br = when (quality) {
            QualityLevel.STANDARD -> "7"
            QualityLevel.HIGH -> "5"
            QualityLevel.LOSSLESS -> "1"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://oiapi.net/api/Kuwo?msg=${urlEncode(song.searchKeyword)}&n=1&br=$br"
        val json = ApiClient.getJson(url, timeoutSec = 10)
        var stream = json.optJSONObject("data")?.optString("url", "")
        if (stream.isNullOrEmpty()) stream = json.optString("url", "")
        if (stream.isNullOrEmpty()) throw ApiError.Parse("oiapi 酷我未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "搜索式取流")
    }
}

// KuwoDES 官方签名链
class KuwoDESAdapter : StreamSourceAdapter {
    override val name = "KuwoDES 官方"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val (br, format) = when (quality) {
            QualityLevel.STANDARD -> "128kmp3" to "mp3"
            QualityLevel.HIGH -> "320kmp3" to "mp3"
            QualityLevel.LOSSLESS -> "2000kflac" to "flac"
        }
        val url = "https://mobi.kuwo.cn/mobi.s?f=web&source=kwplayer_ar_8.5.5.0_apk_keluze.apk&type=convert_url_with_sign&br=$br&format=$format&sig=0&rid=${song.platformID}&network=WIFI&user=0"
        val json = ApiClient.getJson(url, headers = mapOf("User-Agent" to "okhttp/3.10.0"), timeoutSec = 12)
        if (json.optInt("code") != 200) throw ApiError.Parse("KuwoDES code != 200")
        val stream = json.optJSONObject("data")?.optString("url", "")
        if (stream.isNullOrEmpty()) throw ApiError.Parse("KuwoDES 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "官方签名链")
    }
}

// zddyr 自建后端（需 X-Token）
class ZddyrKuwoAdapter : StreamSourceAdapter {
    override val name = "zddyr 酷我"
    override val platform = MusicPlatform.KUWO

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val q = when (quality) {
            QualityLevel.STANDARD -> "128k"
            QualityLevel.HIGH -> "320k"
            QualityLevel.LOSSLESS -> "flac"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://yy.zddyr.top/lx/api/?source=kw&name=${urlEncode(song.name)}&singer=${urlEncode(song.singer)}&songmid=${song.platformID}&quality=$q"
        val json = ApiClient.getJson(url, headers = mapOf("X-Token" to makeToken(), "X-Client" to "JZMusicHelper/1.0 (Android)"), timeoutSec = 10)
        if (json.optInt("code") != 200) throw ApiError.Parse("zddyr code != 200")
        val stream = json.optString("url", "")
        if (stream.isEmpty()) throw ApiError.Parse("zddyr 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "自建后端")
    }

    private fun makeToken(): String {
        val payload = JSONObject()
            .put("device_id", "android-" + Integer.toHexString(Random().nextInt(0xFFFFFF)))
            .put("ip", "0.0.0.0")
            .put("timestamp", System.currentTimeMillis() / 1000)
            .put("random", Integer.toHexString(Random().nextInt(0xFFFFFFFF.toInt())))
        return android.util.Base64.encodeToString(payload.toString().toByteArray(), android.util.Base64.NO_WRAP)
    }
}

// ---------- QQ 系 ----------

// cyapi.top QQ 直链
class CyapiQQAdapter : StreamSourceAdapter {
    override val name = "cyapi QQ"
    override val platform = MusicPlatform.QQ

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val url = "https://cyapi.top/API/qq_music.php?apikey=1ffdf5733f5d538760e63d7e46ba17438d9f7b9dfc18c51be1109386fd74c3a1&type=json&mid=${song.platformID}"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://y.qq.com/"), timeoutSec = 12)
        val stream = json.optString("url", "")
        if (stream.isEmpty()) throw ApiError.Parse("cyapi 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, "m4a", "VIP 全量 m4a")
    }
}

// a.aa.cab QQ（搜索式）
class AacabQQAdapter : StreamSourceAdapter {
    override val name = "a.aa.cab QQ"
    override val platform = MusicPlatform.QQ

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val type = when (quality) {
            QualityLevel.STANDARD -> "0"
            QualityLevel.HIGH -> "1"
            QualityLevel.LOSSLESS -> "4"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://a.aa.cab/qq.music?msg=${urlEncode(song.searchKeyword)}&n=1&type=$type"
        val json = ApiClient.getJson(url, headers = mapOf("Referer" to "https://y.qq.com/"), timeoutSec = 12)
        var stream = json.optJSONObject("data")?.optString("music", "")
        if (stream.isNullOrEmpty()) stream = json.optString("url", "")
        if (stream.isNullOrEmpty()) throw ApiError.Parse("a.aa.cab 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "搜索式取流")
    }
}

// ---------- 网易云系 ----------

// gdstudio 网易
class GdstudioNeteaseAdapter : StreamSourceAdapter {
    override val name = "gdstudio 网易"
    override val platform = MusicPlatform.NETEASE

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val br = when (quality) {
            QualityLevel.STANDARD -> "128"
            QualityLevel.HIGH -> "320"
            QualityLevel.LOSSLESS -> "740"
        }
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://music-api.gdstudio.xyz/api.php?use_xbridge3=true&loader_name=forest&need_sec_link=1&sec_link_scene=im&theme=light&types=url&source=netease&id=${song.platformID}&br=$br"
        val json = ApiClient.getJson(url, headers = mapOf("User-Agent" to "LX-Music-Mobile"), timeoutSec = 12)
        val stream = json.optString("url", "")
        if (stream.isEmpty()) throw ApiError.Parse("gdstudio 未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, format, "VIP 全量 mp3/FLAC")
    }
}

// oiapi Music_163
class OiapiNeteaseAdapter : StreamSourceAdapter {
    override val name = "oiapi 网易"
    override val platform = MusicPlatform.NETEASE

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val url = "https://oiapi.net/api/Music_163?id=${song.platformID}"
        val json = ApiClient.getJson(url, timeoutSec = 12)
        if (json.optInt("code") != 0) throw ApiError.Parse("oiapi 网易 code != 0")
        var stream: String? = null
        val data = json.optJSONArray("data")
        if (data != null && data.length() > 0) {
            stream = data.optJSONObject(0)?.optString("url", "")
        }
        if (stream.isNullOrEmpty()) stream = json.optString("url", "")
        if (stream.isNullOrEmpty()) throw ApiError.Parse("oiapi 网易未返回 URL")
        if (!StreamVerifier.isAudioUrl(stream)) throw ApiError.HTTP(0)
        return StreamSource(stream, name, platform, quality, "mp3", "ID 直查")
    }
}

// ---------- 酷狗系 ----------

// haitangw 酷狗直链
class HaitangKugouAdapter : StreamSourceAdapter {
    override val name = "haitangw 酷狗"
    override val platform = MusicPlatform.KUGOU

    override suspend fun resolve(song: Song, quality: QualityLevel): StreamSource {
        val level = quality.levelName()
        val format = if (quality == QualityLevel.LOSSLESS) "flac" else "mp3"
        val url = "https://music.haitangw.cc/kgqq/kg.php?type=mp3&id=${song.platformID}&level=$level"
        if (!StreamVerifier.isAudioUrl(url)) throw ApiError.HTTP(0)
        return StreamSource(url, name, platform, quality, format, "hash 直查")
    }
}

// ---------- 后端注册表 ----------
object SourceRegistry {

    val all: List<StreamSourceAdapter> = listOf(
        HaitangKuwoAdapter(),
        NxinxzKuwoAdapter(),
        OiapiKuwoAdapter(),
        KuwoDESAdapter(),
        ZddyrKuwoAdapter(),
        CyapiQQAdapter(),
        AacabQQAdapter(),
        GdstudioNeteaseAdapter(),
        OiapiNeteaseAdapter(),
        HaitangKugouAdapter()
    )

    // 某首歌可用的后端：同平台后端 + 跨平台搜索式后端
    fun adaptersFor(song: Song): List<StreamSourceAdapter> {
        val cross = listOf<StreamSourceAdapter>(OiapiKuwoAdapter(), AacabQQAdapter())
        val result = mutableListOf<StreamSourceAdapter>()
        val seen = mutableSetOf<String>()
        for (a in all.filter { it.platform == song.platform } + cross) {
            if (seen.add(a.name)) result.add(a)
        }
        return result
    }
}

internal fun QualityLevel.levelName(): String = when (this) {
    QualityLevel.STANDARD -> "standard"
    QualityLevel.HIGH -> "exhigh"
    QualityLevel.LOSSLESS -> "lossless"
}
