package com.jz.musichelper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jz.musichelper.data.DownloadManager
import com.jz.musichelper.data.HistoryStore
import com.jz.musichelper.data.PlayerManager
import com.jz.musichelper.model.QualityLevel
import com.jz.musichelper.model.Song
import com.jz.musichelper.model.StreamSource
import com.jz.musichelper.network.UrlResolver
import kotlinx.coroutines.launch

@Composable
fun SongDetailScreen(song: Song, onBack: () -> Unit) {
    var quality by remember { mutableStateOf(HistoryStore.loadQuality()) }
    var isResolving by remember { mutableStateOf(false) }
    var sources by remember { mutableStateOf<List<StreamSource>>(emptyList()) }
    var failedCount by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // 顶部栏
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
            }
            Text(song.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        }

        // 歌曲信息
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFEEEEEE),
                modifier = Modifier.width(84.dp).height(84.dp)
            ) {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    modifier = Modifier.padding(20.dp),
                    tint = Color(0xFF888888)
                )
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(song.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text(song.singer, color = Color(0xFF666666))
                Spacer(Modifier.height(2.dp))
                Text(song.album, fontSize = 13.sp, color = Color(0xFF999999), maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text("来源：${song.platform.displayName}", fontSize = 12.sp, color = Color(0xFF1E88E5))
            }
        }

        // 音质选择
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("音质", fontSize = 13.sp, color = Color(0xFF888888))
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QualityLevel.entries.forEach { q ->
                    val selected = quality == q
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selected) Color(0xFF1E88E5) else Color(0xFFEEEEEE),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { quality = q }
                    ) {
                        Text(
                            q.displayName,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = if (selected) Color.White else Color(0xFF444444),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 解析按钮
        Button(
            onClick = {
                sources = emptyList()
                failedCount = 0
                isResolving = true
                scope.launch {
                    val r = UrlResolver.resolveAll(song, quality)
                    sources = r.sources
                    failedCount = r.failed.size
                    isResolving = false
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            enabled = !isResolving
        ) {
            if (isResolving) {
                CircularProgressIndicator(
                    modifier = Modifier.width(18.dp).height(18.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(8.dp))
                Text("解析中…")
            } else {
                Text(if (sources.isEmpty()) "获取播放/下载链接" else "重新解析")
            }
        }

        // 源列表
        if (sources.isNotEmpty()) {
            Text(
                "可用链接（${sources.size} 条）",
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            sources.forEach { source ->
                SourceCard(song = song, source = source)
            }
        }
        if (failedCount > 0) {
            Text(
                "$failedCount 个后端失败或超时，已自动忽略",
                fontSize = 12.sp,
                color = Color(0xFF999999),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SourceCard(song: Song, source: StreamSource) {
    val playingUrl by PlayerManager.currentUrl.collectAsState()
    val isPlaying by PlayerManager.isPlaying.collectAsState()

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF5F5F5),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(source.backendName, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${source.quality.displayName} · ${source.format.uppercase()}",
                        fontSize = 12.sp,
                        color = Color(0xFF888888)
                    )
                }
                Text(
                    source.platform.shortName,
                    fontSize = 11.sp,
                    color = Color(0xFF1E88E5),
                    modifier = Modifier
                        .background(Color(0xFF1E88E5).copy(alpha = 0.12f), RoundedCornerShape(50))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val isThisPlaying = playingUrl == source.url && isPlaying
                OutlinedButton(onClick = {
                    if (isThisPlaying) {
                        PlayerManager.toggle()
                    } else {
                        PlayerManager.play(source.url)
                    }
                }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.width(18.dp).height(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isThisPlaying) "暂停" else "试听")
                }
                Button(onClick = {
                    DownloadManager.startDownload(song, source)
                }) {
                    Icon(Icons.Filled.ArrowDownward, contentDescription = null, modifier = Modifier.width(16.dp).height(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("下载")
                }
            }
        }
    }
}
