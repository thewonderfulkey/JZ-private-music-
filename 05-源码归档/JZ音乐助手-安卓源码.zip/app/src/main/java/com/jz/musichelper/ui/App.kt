package com.jz.musichelper.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import com.jz.musichelper.model.Song

// 全局导航状态：当前选中的歌曲（详情页覆盖显示）
object AppState {
    val currentSong = androidx.compose.runtime.mutableStateOf<Song?>(null)
}

enum class MainTab(val label: String, val icon: ImageVector) {
    SEARCH("搜索", Icons.Filled.Search),
    DOWNLOADS("下载", Icons.Filled.ArrowDownward),
    HISTORY("历史", Icons.Filled.History),
    SETTINGS("设置", Icons.Filled.Settings)
}

@Composable
fun App() {
    MaterialTheme {
        val song = AppState.currentSong.value
        if (song != null) {
            SongDetailScreen(song = song, onBack = { AppState.currentSong.value = null })
        } else {
            MainScaffold()
        }
    }
}

@Composable
private fun MainScaffold() {
    var tab by rememberSaveable { mutableStateOf(MainTab.SEARCH) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                MainTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        val mod = Modifier.padding(innerPadding)
        when (tab) {
            MainTab.SEARCH -> SearchScreen(mod)
            MainTab.DOWNLOADS -> DownloadsScreen(mod)
            MainTab.HISTORY -> HistoryScreen(mod)
            MainTab.SETTINGS -> SettingsScreen(mod)
        }
    }
}
